# Task 0363：完成 Talklet / Click 高级演出设计器

状态：实现完成 — 2026-11-06；独立验收通过，最后整体集成复验受并行 0365 StoryEntry 迁移影响，具体证据与限制见下文。

## 目标与范围

- 目标：让 Talklet / Click 自身表达局部外观与定位演出，编辑器提供“基础｜演出”Switch；作者可直接选中屏幕上的内容对应节点进行编辑。
- 基础任务 0362 已完成并压缩归档；复用 `property-fields.ts` 导出的 `renderStoryNodeBasicProperties()` 基础属性区域（当前机制见 [[runtime-editor-and-project-checks]]）；向 [[ai/plan/task-0364-story-operation-display-content-migration]] 提供可正式保存、播放及清理的新节点表达。
- 范围包含契约、草稿、投影 / 校验、Runtime、共享渲染、编辑预览与 Schema 的必要配套；只扩展现有演出能力，不新建通用舞台引擎。
- Operation 保留全局主题、场景级演出与清理职责；Click 继续负责输入，不恢复内嵌动作结果。业务状态、移动、Transfer 仍按既有节点职责执行。
- 不包含语音、逐字正文动画、任意 HTML / CSS / JavaScript、通用时间轴或地图 Flow 专用卡牌的作者化。

## 用户已接受的组织方式

- 同一个 Talklet / Click 只拥有一份正文 / 交互内容；“基础｜演出”切换只改变编辑页，不启停能力，不清空参数，不推进剧情。
- 演出页提供“随流排列｜定位展示”的实际展示方式选择；仅定位模式展开坐标 / 锚点。字体和颜色等样式也可用于流内内容。
- Talklet 可承担标题、注记、普通文字及定位消息；Click 可承担定位按钮、Choice 与入口卡。模板与样式归节点，具体正式字段名在实现前核实后确定。
- 已配置演出时提供简洁的存在标记及明确的恢复默认操作，避免隐藏配置被忽略；不在基础页重复堆放高级表单。

## 已落实的数据、DOM 与生命周期设计

- 正式字段：Talklet / Click `performance`；有限 `style`、`layout`（`flow` 或 `positioned`，坐标与横向锚点），Talklet 另有 `template`。沿用唯一 content / interaction，不把旧 Overlay 操作对象嵌回节点。
- 位置与默认：坐标为 0..1、左下原点、纵向中心锚定，沿用旧覆盖层；首次选择定位从中心开始。layout 的 mode 分支缓存保留坐标原文，流模式仅发布 mode；无效草稿不变成默认值。字型与尺寸 / 颜色是有限字段，复用引擎颜色解析器，拒绝任意 CSS / HTML。
- 展示身份：Runtime 输出保存 `{storyId,nodeId}`，条目外层 historyId 隔离逻辑运行；恢复使用新 runId / token 但保留 historyId，旧输入凭据失效。流内每次到达追加，定位再次到达同一节点替换；新的定位 Choice 等待点移除其旧完成卡，避免叠出第二个候选输入。
- 清理：Operation 新增 `clearNode`（storyId / nodeId），仅清除发起运行的目标节点全部现存输出；不修改 Player 进度、标记、已读或效果。未展示的有效目标是无操作。旧 clearFlow 清除全部输出并沿用待投递抑制；clearAllTexts 同时清除该运行的定位输出。清理后快照只保存剩余输出，无 UI 重新投递路径。
- 生命周期：流内正文与完成 Choice 留历史；定位正文 / 完成 Choice 在运行完成、取消、失败、替换、换场时清理。Button / EntryCard 只由当前输入 DTO 渲染，完成即退出；定位不赋予任意 Entry 启动能力。外部清流保留当前等待点的输入，不改变执行状态。
- 状态归属：Coordinator 继续持有输出，Player 继续独占推进和输入；没有 UI 私有展示状态或额外计时器。保存、正式 / 重播使用已有输出快照与隔离通道，内容不匹配仍按 Entry 重启策略处理，无存档迁移层。
- DOM 草图：原节点类型 Switch / 通用字段 → 设计页 Tabs → 已配置标记 / 恢复默认 → 两个常驻 page（基础区、演出区）→ 原诊断与节点操作。只为设计页显隐增加两个语义容器；无新滚动宿主。中栏选中定位节点复用原有画布容器、pointer 委托、六点预设及稳定 node.id；共用 `projectStoryContent()` 与实际渲染函数。
- 更新：页签仅修改会话 UI 状态，经 `workspace.story-editor` region / `patchEditorDOM` 更新 hidden / 激活态；输入、预设与拖拽只协调实际消费者，保留基础表单、节点身份和无关栏滚动；真正改变节点分支时替换该字段范围，失效浮层沿原 Controller 清理。
- 配套范围：作者投影 / 结构校验 / 引用与身份改名、Runtime 输出与快照、聊天 / 通讯录 / 隔离试播、编辑画布与属性页、Schema 生成与补充说明；0364 的旧 show 路径和正式样例保持后续迁出范围。

## 交付内容与验收

- [x] 先形成紧凑的数据与 DOM 草图：内容 / 呈现边界、可选字段、编辑页状态归属、稳定 key、更新范围、播放与历史生命周期；落实下表待决问题后开始相关实现。
- [x] 直接编辑节点的定位、对齐、模板与现有样式能力：字型、字号、文字色、背景色 / 透明背景。基础 side / narration align 与定位锚点不混用。
- [x] 复用当前归一化聊天窗格坐标和左下原点约定；拖拽与六点定位快捷方式写入同一组正式值，数值和资源引用在作者边界校验。
- [x] Runtime 与编辑器共用节点呈现投影，基础 / 高级预览完整传递 side、align、avatarMode、身份与图片；修正现有覆盖层编辑预览的映射缺口，不只复用外层 CSS。
- [x] 定位 Click 仍遵循唯一当前输入、token、Choice 条件与 marks、入口卡续接规则；已完成或历史内容不能重新提交，不得因定位而远程启动任意 Entry。
- [x] 完成最小“清除指定节点展示”能力，目标引用真实节点身份并有只读候选 / 定位入口；清理不回退执行、不撤销标记或业务效果、不重新投递已清内容。
- [x] 运行态拥有展示的停留 / 隐藏状态，支持保存恢复、正式播放 / 重播、换场与退出清理；多个 UI 显示不能创建多个推进器或计时器。
- [x] 未配置高级参数时，现有流内正文和交互保持现行行为；分支 / 编辑页切换不丢输入，局部更新保留无关节点和滚动，受影响 Schema 通过生成及同步验证。

## 事实、建议与待决问题

| 问题 | 已知事实 / 候选方案 | 实施决定（已落实） |
| --- | --- | --- |
| 当前高级能力 | `StoryOverlayContent` 支持 text / message / entryCard，`ChatTextStyle` 提供有限样式；目前由 Operation.overlay.show 产生 | performance 只声明模板 / 有限 style / layout，不嵌套旧操作对象 |
| 运行身份 | 现有 Runtime 输出、StoryNode ID、run / owner 身份各有用途 | historyId 隔离逻辑运行，输出另记 storyId / nodeId；恢复换 runId / token，保持逻辑身份 |
| 重复到达 | insert / goto 与重播可能再次到达同一节点 | 流内追加；定位替换同运行 / Story / nodeId 的旧展示，clearNode 清除该目标在发起运行内的全部现存输出 |
| 停留与完成 | 当前流内历史与临时覆盖层的生命周期不同 | 候选：流内正文留历史，定位内容本轮演出结束清理；普通按钮完成后退出输入，Choice 留禁用记录。现已按下列生命周期实现，EntryCard 同 Button 仅保留当前输入 |
| clearFlow | 现有清流、清覆盖层是不同操作，Runtime 有输出 epoch 与抑制逻辑 | clearFlow 清输出并抑制未投递正文；clearAllTexts 清本运行定位输出；当前输入等待点保留，快照不补投已清内容 |
| 播放节奏 | 当前 typing 是输入提示等待后整条投递，Runtime 管理打字 / 思考 / banner 阶段 | 沿用现行节奏与送达确认，不使用渲染动画推进，不引入逐字正文 |

## 当前进度

- [x] 记录用户已接受的实体与属性页方向，区分候选生命周期规则。
- [x] 以 0362 基础页接入 Switch，落定契约 / 生命周期和关键回归。
- [x] 完成节点演出、共用预览与定点清理闭环。
- 实施结果：基础 / 演出双页、有限模板 / 样式、定位 / 画布拖拽、真实节点清理、输出生命周期、快照与预览安全已完成。
- 下一步：归档当前实现与验收记录；并行 StoryEntry 迁移稳定后，统一重跑共享 Story / Entry 集成与全项目类型检查，0364 迁出前复核。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-node.ts`、`story-node-actions.ts`、`src/engine/contracts/chat-presentation.ts` | 节点、旧覆盖层与有限样式契约 | 已修改；新增 performance、有限样式 / 布局与 clearNode |
| `src/data-services/authoring/story-definition-projection.ts`、`src/data-services/validation/story-node-structure.ts`、`src/data-services/registry/runtime-content-reference-rules.ts` | 正式投影、形状与定点清理引用 | 已修改；补充正式投影、有限字段校验、头像资源与清理引用 |
| `src/arona-clicker/services/story/story-node-presentation-host.ts`、`story-service.ts`、`story-playback-coordinator.ts`、`story-playback-snapshot.ts` | 展示归属、阶段与快照 | 已修改；唯一输出归属、清理 / 生命周期与快照校验 |
| `src/engine/contracts/story-playback-state.ts`、`story-presentation-snapshot.ts` | 输出与临时表现快照 | story-playback-state 已修改；临时 overlay 快照合同复核后保持不变 |
| `src/ui/components/story/story.ts`、`src/ui/story-editor/property-fields.ts`、`view.ts`、`controller.ts` | 共用渲染、编辑页、定位与预览 | 已修改；常驻双页、共用内容映射、局部样式 / 定位与无启动绑定的作者预览 |
| `tests/ui/components/chat-text.test.ts`、`tests/ui/story-editor-properties.test.ts`、`tests/engine/story-playback-coordinator.test.ts`、`story-playback-snapshot.test.ts` | 样式、编辑、阶段与恢复回归入口 | 已修改 / 新增针对性行为测试，结果见下表 |
| `scripts/gen-engine-schema.mjs`、`tools/datapack-editor/schema/editor-extras.ts` | 作者协议生成与说明 | 已补关键子结构生成、说明与同步用例；运行 gen:schema，未手改生成文件 |
| [[story-chat-and-theme-presentation]]、[[story-and-effects]]、[[ai/plan/task-0355-story-editor-theme-position-and-flow-tools]] | 现有机制与可复用设计工具 | 机制说明与 ui-style/patterns 已同步；旧 overlay.show 保留供 0364 迁出 |

## 验证与结果

| 对象 | 实际结果 | 证据 / 限制 |
| --- | --- | --- |
| 播放、快照与数据边界 | `npm test -- tests/engine/story tests/data/story tests/data/runtime-content-reference-rules.test.ts --maxWorkers=1 --minWorkers=1`：35 文件 / 327 项通过 | `.test-artifacts/0363-core-final-full.log`；含真实节点清理、重复到达、位置清理、Choice 过期输入 / marks、保存恢复、抑制投递、重播隔离及非法快照 |
| 编辑器与共享渲染 | 12 文件 / 175 项通过；后续有针对性的 6 文件 / 87 项及 3 文件 / 41 项通过（不是可累加的不同测试） | `0363-ui-final-full.log`、`0363-followup-ui-full.log`、`0363-interaction-final-full.log`；含页签不改草稿、DOM / 光标、数值原文、拖拽 / 六点预设、缓存与改名 / 复制 |
| 最终独立复核 | `npm test -- tests/ui/story-node-input.test.ts tests/ui/story-performance.test.ts tests/data/story-performance.test.ts --maxWorkers=1 --minWorkers=1`：3 文件 / 34 项通过 | `.test-artifacts/0363-pure-final-full.log`；纯渲染用最小上下文，不加载无关内容工厂；作者预览不产生 detached Entry 启动绑定 |
| Schema | 已重新生成；Story 演出字段与生成文件一致性定向 2 项通过；最终完整同步 16 / 17 通过 | `0363-schema-check-full.log`、`0363-schema-final-full.log`；剩余为并行 Area Reveal 的 `areaMaps.revealTriggers` 覆盖旧字段，不属于本 Task |
| 类型 | 曾仅剩原有 infinite-board 测试 8 错误；最新整体检查又受到并行 StoryEntry 迁移的类型 / 接线错误影响 | `.test-artifacts/0363-types.log`；不将全项目类型检查记录为通过 |
| 最新整体复验 | 0365 开始修改共享 Entry 合同后，后续 GameInstance 组遇到暂时构造器语法错误，以及旧 Passive Entry weight / pool 用例不匹配 | `.test-artifacts/0363-preview-final-full.log`；保留上述此前完整通过记录，未修改 0365 业务模型或改旧用例冒充通过 |
| 架构 / 文档 / 差异 | 架构边界通过；文档 128 页 / 0 错误通过；任务范围差异检查通过 | 最终归档路径再次校验；无新增依赖，无 UI 第二份业务状态 |
| 地图 | 集中只读检查 49 路径：22 条已映射路径的旧依据变化，27 条未关联；相关 owner 分页完整 | 未改图、刷新或写 freshness |
| 浏览器 | 按现有许可跳过人工浏览器验收 | 自动化覆盖 DOM / 交互，不声称视觉已人工确认 |

新增 / 配套文件：`src/data-services/validation/story-performance.ts`、`src/data-services/authoring/story-content-display.ts`；`StoryNodePerformance` / `StoryDisplayTarget` 在引擎有限表现合同中；`results.ts` / `story-node-session.ts` 增补只读演出及按击进度投影。聊天 / 通讯录 / Flow / 隔离试播统一使用现有输出；`model.ts`、`identity.ts`、`authoring-model.ts` 维护清理引用在节点改名、Story 改名和副本中的对应关系。新增数据 / 纯渲染用例为 `tests/data/story-performance.test.ts`、`tests/ui/story-performance.test.ts`。

## 剩余工作与交接

- 本 Task 未迁出或移除旧 show 路径、未批量改正式样例；0364 可按新节点表达实施，但正式迁出前需在并行迁移稳定后复跑 Story / Entry 集成、Schema 与类型检查。
- 当前没有本 Task 未实现的功能项；整体校验的外部限制和未执行的浏览器验收已明确记录。输出仍由 Runtime 单独持有，旧内容 / 游标按既有 Entry 重启策略处理，无迁移兼容层。
