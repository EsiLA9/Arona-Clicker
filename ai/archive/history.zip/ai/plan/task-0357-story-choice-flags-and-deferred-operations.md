# Task 0357：Choice 收敛为条件与局部 flags，业务效果迁至后续节点

状态：完成 — 主 Agent 已整合三个 Luna 的内容、编辑器与运行时回归交付；内置 Choice 已收敛，旧包合同兼容保留，自动化验收与文档检查完成

## 目标与范围

- 目标：大量撤离多选 Choice 内的效果内容。Choice 负责展示选项、按需判断选项是否可行，以及为所选分支提供 Entry 局部 flags；后续 Operation 根据 flags 承担业务效果与演出。
- 范围：盘点并迁移内置 Story 的 Choice `sharedActions` / `options[].result`；同步游戏内 Story 编辑器的作者入口、投影与校验、运行时相关调用方、内容样例和测试。是否收紧正式合同另见下方待裁定项。
- 迁移后的作者规则：选项保留身份、文案和可选 `condition`；选项结果仅保留 `localFlag` 写入 / 移除，共享动作仅承担必要的局部标记维护。资源、物品、持久 flag、旅行、表现、Entry 请求等实际行为从 Choice 中撤出。
- 非目标：不扩大到单按钮 Button、入口卡或 Entry 完成奖励的全面重构；不新增全局分支状态、不改成按 flag 值比较、不设计通用条件执行语言。

## 已核对事实与约束

| 事实 | 依据与实施含义 |
| --- | --- |
| 当前 Choice 可直接携带任意 StoryAction 和 transfer | `src/data-services/contracts/story-node.ts` 的 `StoryChoiceInteraction`、`StoryChoiceOption`、`StoryNodeResult`；播放器先执行 sharedActions，再执行所选结果 actions，之后处理转移。不能只隐藏 UI 或静默丢弃旧字段。 |
| 现有局部标记已足够表达选择到后续节点的门控 | `StoryNodePlayer` 使用 Entry 运行中的 `localFlags`；`requiresFlag` 只检查键存在。false、0 等值仍会通过，迁移默认写入 `true`，未选择分支必须缺键。 |
| flags 生命周期与持久 flag 不同 | `goto` / `insert` 共用本次局部表；新 Entry 不自动继承，明确子调用的返回白名单除外。`state.effects[].setFlag` 写持久状态，必须迁到后续 Operation，不能直接替换为 localFlag。 |
| 编辑器已有绑定与清理能力 | `bindStoryNodeToChoiceOption()`、`choiceOptionFlagBindings()`、局部标记级联改名等位于 `src/ui/story-editor/model.ts`；Task 0341 已有配对标记、重复 Choice 清理和拖放复用。优先复用，不另建绑定存储。 |
| Operation 与 Transfer 职责分开 | Operation 携带一个 StoryAction；其 state 动作可保留有序 effects 批次。goto / insert 需移为后续带 `requiresFlag` 的顶层 Transfer；移动可使用已有移动节点，不把转移塞入 Operation。 |
| 拆出 Operation 会改变等待点与错误边界 | 当前 Choice 提交预检所选结果，Operation 到达时独立预检 / 执行并呈现。迁移须核对副作用顺序、失败时是否部分执行、存读档与重播，不能仅比较最终数值。 |
| 已发现实际迁移样例 | `story-abydos-main.ts` 的 Choice 写持久 `abydos_choice`；`story-millennium-main.ts` 含持久分支标记及选项 goto；`story-schale-main.ts` 含带持久标记的 insert / goto。此为入口样例，尚非完整盘点。 |

机制依据：[[story-and-effects]]；相关既有工作：[[ai/plan/task-0341-story-choice-flag-bindings]]、[[ai/plan/task-0344-story-operation-checkpoints]]。

## 施工步骤与验收条件

### 1. 完整盘点并确定收紧边界

- [x] 列出内置 Choice 的 Story ID、节点 ID、选项 ID、condition、共享 / 结果动作、transfer、flags 写入及消费者，形成逐项迁移清单；区分纯标记、业务效果和混合顺序。
- [x] 查找旧持久分支 flag 的全部读写方；确认迁移后持久写入仍在正确位置，既有条件与外部消费者不失效。
- [x] 核对未应用草稿、包导入、构造器和测试夹具的旧 Choice 形状；决定正式合同是否收紧及旧内容处理方式，再实施相应限制。

### 2. 按分支迁移内容

- [x] 为迁移选项写入无冲突的局部标记；后续 Operation / Talklet / Transfer / 移动节点复用 `requiresFlag`。保留选项 ID、文案、可行性条件与原有用户选择结果。
- [x] 重复进入 Choice 时先清理本 Choice 的旧分支标记，再写入当前分支；不清空其他 Choice、初始投入或明确回传的 flags。
- [x] 业务动作按原顺序迁移，原 state effects 批次尽量保持为一个 Operation；共同业务动作位于选择成功后的正确位置，不能无条件搬到 Choice 前面而提前执行。
- [x] 原选项 transfer 移到对应分支最后的受控 Transfer；insert 仍返回正确后继，goto 不吞掉本应先发生的对白或效果。仅互斥标记命中的分支执行，其余节点无副作用地跳过。
- [x] 对混合 flags / 业务动作、Entry 替换、失败预检等不能直接等价平移的项目逐项说明处理，不静默改变顺序或接受部分结算。
- [x] 同步实际使用的基础包内容产物，并验证 Registry 装载；生成与导出入口施工时核对，不手改生成 Schema 或构建目录。

表达示例（作者结构示意，非新增合同）：

```text
Choice.sharedActions：移除本 Choice 旧分支标记
  选项 A（可选 condition）→ localFlag set route_A = true
  选项 B（可选 condition）→ localFlag set route_B = true
Operation [requiresFlag=route_A] → 原 A 的资源 / 持久 flag / 演出等动作
Operation [requiresFlag=route_B] → 原 B 的动作
Transfer  [requiresFlag=route_A] → 原 A 的 goto / insert（如有）
Transfer  [requiresFlag=route_B] → 原 B 的 goto / insert（如有）
```

具体节点排序以各分支原始动作与转移顺序为准；不要把所有分支动作机械地按类型重新分组。

### 3. 收敛作者入口并贯通验证

- [x] Choice 编辑页优先呈现选项条件与局部 flags，移除普通业务动作 / 内嵌 transfer 的新建入口；保留原有绑定卡、标记改名、复用与反查能力。
- [x] 已有旧字段或本地草稿须可见地诊断 / 迁移；类型切换、加载、保存和正式投影不能静默丢内容，也不能在无提示时把恢复的旧业务字段当作新作者入口产生的内容；恢复后仍显示旧字段诊断，正式旧合同兼容保留。
- [x] 本轮决定保留正式合同与投影 / 校验兼容，未改 Schema；无需生成独立编辑器协议。后续若收紧合同再按 [[ai/guide/conventions/schema-sync]] 同步，不手工编辑生成协议。
- [x] 更新调用关系视图与对应测试：已迁出的 Choice 效果 / transfer 不再作为原选项调用位置，后续 Operation / Transfer 的关系可正确查询和跳转。

### 4. 行为验收与文档

- [x] 两个互斥选项只触发各自 flags 与后续效果；不可用选项拒绝提交，不写 flags、不发生业务效果。补充可重复 Choice 由 A 改选 B 的回归。
- [x] 覆盖多项有序效果、共同效果、持久 flag 消费者、Entry 请求、goto / insert 返回及跨文档局部 flags；不得重复执行或泄漏到其他 Entry。
- [x] 覆盖 Choice 提交前后和 Operation 等待点的存读档、不重复结算、失败预检与重播跳过持久效果。已有运行游标遇到改动后的定义，沿用当前显式失配 / 重启策略，不写旧存档迁移或暗中补状态。
- [x] 验证编辑器输入焦点、滚动、绑定 / 解除、草稿保存再载入和发布。按实际影响运行定向 `npm test -- ...`；输出统一归 `.test-artifacts/`。
- [x] 更新 [[story-and-effects]]、[[runtime-editor-and-project-checks]]，若调整 UI 则同步 `ui-style/patterns.md`；执行文档、类型及必要的 Schema / 架构检查。地图只读复核在完整工作节点收尾集中完成。

## 本轮实施决定

- 保留正式 Story 合同和旧包运行兼容，不收紧 Schema；内置内容与编辑器新建入口采用仅 localFlag 的 Choice 作者规则。
- 旧草稿和旧包中的业务动作 / transfer 保留、显示明确诊断及可见内容，允许显式处理；不自动删除，不制造静默数据迁移。
- 使用既有 Operation 等待点与受控 Transfer，不引入新的批事务。内容盘点若发现混合动作无法保持实际语义，先报告具体样例再裁定。

## 后续严格合同的可选方向（不属于本轮剩余工作）

1. **正式合同收紧程度**：推荐先完成清单和内置内容 / 作者入口迁移，再按覆盖结果决定是否让 Choice 的共享 / 结果动作正式只接受 localFlag、禁止 option transfer。用户目前确认的是撤离方向，不把“大量撤离”自行解释成立即拒绝所有外部旧包。
2. **旧草稿与外部包**：若执行严格拒绝，需确定采用显式迁移工具还是诊断后人工修改；不能自动删掉不再支持的效果。该决定不涉及新增玩家存档兼容层。
3. **难以等价平移的边界**：若拆分等待点或预检确实需要改变失败语义，列出具体样例、影响和最小方案后裁定；不默认引入新批处理或事务框架。

## 内置内容迁移清单

完整扫描 `src/arona-clicker/content/` 并核对当前 Registry 基础内容，共 9 个 Choice：7 个含持久 flag 的 Choice 迁出 14 个分支动作，2 个纯局部标记 Choice 补重入清理；4 个选项转移移为受控 Transfer。选项身份、文案和原始值保留。

| Story / 节点 | 选项 ID 与标记 | 原动作 / 转移 | 持久标记消费者与迁移 |
| --- | --- | --- | --- |
| `base:story:abydos_welcome` / `p5-choice` | `option1` → `abydos-welcome-p5-option1`; `option2` → `abydos-welcome-p5-option2` | 分别写 `abydos_choice=committee/pool` | 内容中未发现读者；保留原持久写入，分支 Operation 门控。 |
| `base:story:millennium_welcome` / `p4-choice` | `option1` → `millennium-welcome-p4-option1`; `option2` → `millennium-welcome-p4-option2` | 分别写 `millennium_choice=yuuka/game` | 内容中未发现读者；持久写入保留在 Operation。 |
| `base:story:millennium_game_crisis_intro` / `p4-choice` | `option1` → `millennium-game-crisis-p4-option1`; `option2` → `millennium-game-crisis-p4-option2` | 写 `game_crisis_route=debug/bribe` 后分别 goto debug/bribe Story | 未发现持久 flag 读者；各分支 Operation 后接各自带 `requiresFlag` 的 goto Transfer，保持先写标记再离开。 |
| `base:story:schale_welcome` / `p6-choice` | `option1` → `schale-welcome-p6-option1`; `option2` → `schale-welcome-p6-option2` | 分别写 `welcome_choice=office/production` | `tests/engine/game-instance.test.ts` 断言 production 写入；两种原值仍保留于受控 Operation。 |
| `base:story:schale_theme_lite_test` / `p7-choice` | `option1` → `schale-theme-lite-p7-option1`; `option2` → `schale-theme-lite-p7-option2` | 写 `theme_test_route=insert/goto` 后分别 insert / goto | 内容中未发现持久 flag 读者；Operation 保留持久写入，之后按选项执行 insert / goto。insert 返回后不会命中另一互斥 Transfer。 |
| `base:story:bond_hoshino_1` / `p4-choice` | `option1` → `bond-hoshino-p4-option1` + `hoshino-remembers`; `option2` → `bond-hoshino-p4-option2` + `hoshino-new-memories` | 分别写 `bond_hoshino_choice=committee/forget`，并写被父 Entry 回传的 localFlag | localFlag 通过 `affection-content.ts` Entry `returnFlags` 回传并控制 `remembered` / `new-memories` Talklet；该语义保留。持久 flag 原值保留在门控 Operation；两类 Choice 标记都会重入清理。 |
| `base:story:bond_hoshino_evening` / `p3-choice` | `option1` → `bond-hoshino-evening-p3-option1`; `option2` → `bond-hoshino-evening-p3-option2` | 分别写 `bond_evening_choice=memory/new` | 内容中未发现读者；持久写入保留在分支 Operation。 |
| `base:story:shiroko_drink` / `choice` | `coffee` → `shiroko-drink-coffee`; `juice` → `shiroko-drink-juice` | 原本仅写 localFlag，后续有互斥 Talklet | 已符合局部标记规则；新增重入清理。局部标记被后续 Talklet 消费，并通过邀请 Entry `returnFlags` 回传父 Story。未新增 Operation。 |
| `base:story:shiroko_rooftop` / `choice` | `photo` → `shiroko-rooftop-photo`; `route` → `shiroko-rooftop-route` | 原本仅写 localFlag，后续有互斥 Talklet | 已符合局部标记规则；新增重入清理。局部标记被后续 Talklet 消费，并通过邀请 Entry `returnFlags` 回传父 Story。未新增 Operation。 |

基础包由 `node scripts/sync-base-datapack-bundle.mjs` 同步，`--check` 核对 46 个 Story 与 TypeScript 源一致。未迁移 Button；这是本轮明确非目标。没有内置 Choice 的混合共同业务动作或 Entry 请求需要额外裁定。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-node.ts`、`story-node-actions.ts` | Choice、结果、局部 flag 与 Operation / Transfer 合同 | 已核对；合同未改 |
| `src/arona-clicker/services/story/story-node-player.ts` | 条件准入、动作顺序、局部 flags、等待点与恢复 | 已核对；运行时未改，新增组合回归通过 |
| `src/data-services/authoring/story-definition-projection.ts`、`src/data-services/validation/story-run-flags.ts` | 正式投影与局部标记验证 | 已核对；保留旧正式内容兼容 |
| `src/ui/story-editor/model.ts`、`property-fields.ts`、`property-model.ts`、`controller.ts` | 配对标记、作者表单、草稿分支与编辑交互 | 已修改属性入口 / 种子及畸形旧值防护；绑定模型复用 |
| `src/ui/story-editor/relations-model.ts`、`relations-view.ts` | Story / Entry 调用关系与来源显示 | 实现未改；迁移后来源位置回归通过 |
| `src/arona-clicker/content/story/`、`src/arona-clicker/content/def-factory/story.ts`、`src/arona-clicker/content/base-pack/content.json` | 内容源、构造器与实际基础包 | 完整清单见上；内容及基础包已同步 |
| `tests/engine/story-node-player.result.test.ts`、`story-run-flags.test.ts`、`story-run-flags.integration.test.ts`、`story-node-save.integration.test.ts` | 选择、标记、运行状态与保存回归 | 本轮相应定向 / 整合回归通过 |
| `tests/data/story-node-authoring.test.ts`、`story-node-structure.test.ts`、`tests/ui/story-editor-*.test.ts` | 投影、形状、绑定与编辑流程 | 本轮相应定向 / 整合回归通过 |
| `docs/docs-830/05-domains/story-and-effects.md`、`docs/docs-830/07-tooling/runtime-editor-and-project-checks.md`、`ui-style/patterns.md` | 当前机制与作者规范 | 已更新作者规则、兼容与等待点边界 |

文件表用于交接，不是修改白名单。本轮开始时工作区干净，基线为 `15f6ab6`（before-choice-depre）；前序 Story 迁移与编辑器改动已在该提交中，未将其归为本 Task 产出。

## 当前进度与验证

- [x] 核对 Choice 结果执行顺序、localFlags / requiresFlag 能力及现有绑定卡。
- [x] 建立迁移范围、待裁定项、实施步骤与验收条件，登记活动索引。
- [x] 完成逐 Story / 节点迁移清单，开始内容与作者入口施工。
- 正在进行：无；实现和必要自动化验收已完成。
- 分工：Luna `choice_content` 独占内置内容和对应内容回归；Luna `choice_editor` 独占编辑器属性入口与模型回归；Luna `choice_runtime_tests` 独占运行时回归。主 Agent 维护关系测试、机制 / 风格 / Task 文档并统一运行验证，不并发覆盖测试日志。
- 下一步：无本轮施工剩余项；按项目流程归档此记录。后续若要求正式合同拒绝旧 Choice，再单独确定旧包与草稿处理方案。
- 整合结果：Luna 内容交付、编辑器交付和运行时回归均已核对并整合；主 Agent 审查修正了畸形旧 result/actions、旧动作删除后的稳定行缓存，以及旧 Choice 右栏转移导航保留。未修改正式运行时、合同或 Schema。
- 基线：7 文件 / 75 项定向测试通过；Luna 自校验为 Runtime 6 项、编辑器 4 文件 / 47 项通过。
- 整合回归：`npm test -- story tests/engine/game-instance.test.ts tests/data/base-datapack-folder-export.test.ts` 共 60 文件 / 569 项，59 文件 / 568 项通过；唯一失败为旧 Choice 右栏转移链接消失。已恢复只读链接而保留禁止新建的作者规则。
- 最终复验：`npm test -- tests/ui/story-editor-workspace.test.ts tests/ui/story-editor-properties.test.ts tests/engine/story-choice-deferred-operations.test.ts tests/data/story-choice-content-migration.test.ts tests/data/story-node-authoring.test.ts tests/ui/story-editor-relations-model.test.ts`，6 文件 / 80 项全部通过，包含失败修复和故障边界新增回归。其余已通过套件未无故重复运行。完整输出 `.test-artifacts/latest.log`。
- 静态核验：文档检查（123 篇、0 错误）、架构检查、基础包源同步检查（46 Story）及 `git diff --check` 通过。`npx tsc --noEmit --pretty false` 仅有 `tests/prototypes/infinite-board.test.ts` 的 8 处既有错误；本 Task 相关文件无新增类型错误，日志 `.test-artifacts/choice-typecheck.log`。
- 浏览器桌面实操未运行；界面输入、稳定行、草稿重载、导航、绑定及滚动容器由相关自动化回归覆盖。
- 地图只读复核：Luna `choice_content` 核对 `acprogram` 身份后检查 18 个直接改动路径。10 个已映射路径的 owner 分页全部 complete（含 6 owner 路径续页），18 条 Evidence 均标为 content_changed；8 个无直接映射 / Evidence 的路径均回到当前文件核实可读。未扩展邻域、未改图、未刷新、未写 freshness；陈旧依据留待获授权的后续集中维护。Task / 索引属于记录，不纳入机制图扩展。
- 剩余限制：未做浏览器实操；全局类型检查的原型测试既有错误保留。后续独立 Operation 失败不会自动回滚此前已结算的效果，已有故障回归固定此边界。旧包仍能使用原 Choice 结果合同，这不是正式 Schema 禁令。
