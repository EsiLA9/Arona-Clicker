# Task 0359：Story 身份与编辑态 Mod

状态：完成 — 新建强制 Mod 确认、序号 ID 与同 Mod 安全改名已实施；身份功能验收通过，另记并行 Operation 属性测试 1 项失败。

## 目标与范围

- 每次新建均先选择并确认编辑态 Mod；取消不创建，无编辑态包时明确引导。
- 新 ID 为 `mod:story:story_number`，查询目标包、注册内容与未保存草稿避重；草稿绑定具体目标包。
- 提供同 Mod 更改 StoryId；展示引用影响，更新正式 Story 引用，阻止不可一起保存的外部引用。正文、Extra、Flag、Node / Entry ID 不替换。
- 已存包 Story 改名一次保存新身份、引用与旧身份删除；草稿改名保持内部草稿身份、输入、导航和 Flag 页。取消、过期目标、重名、校验或存储失败不丢原内容。
- 复用现有包读接口、引用规则和作者事务；不增加依赖、跨 Mod 迁移、旧存档迁移或正式 Story 级联删除 UI。现有删除草稿继续只删除本机副本。

## 当前进度

- [x] 核对现有 newStory、复制身份、作者 patch、包保存与引用入口。
- [x] 新建选择框、序号及目标归属持久化。
- [x] 同 Mod 改名计划、引用边界与提交、界面身份协调。
- [x] 定向回归、必要静态检查、机制说明；归档作为最后一步执行。
- 正在进行：无；全程主 Agent 单独执行，未启动子 Agent。
- 下一步：投入压缩归档并移出活动表。

## 相关文件与资料

| 路径 | 用途 | 状态 |
| --- | --- | --- |
| `src/ui/story-editor/model.ts`、`controller.ts`、`persistence.ts`、`view.ts`、`authoring-model.ts` | 新建、身份、草稿与 UI 状态 | 已修改并定向验证 |
| `src/data-services/authoring/story-authoring.ts`、`registry/runtime-content-reference-rules.ts` | 作者事务、正式引用 | 已核对，复用 |
| `src/arona-clicker/runtime/runtime.ts`、Runtime 命令合同 | 编辑态包保存与改名边界 | 已修改并定向验证 |
| `tests/ui/story-editor-*.test.ts`、`tests/engine/story-authoring.test.ts` | Mod 选择、新旧调用、取消、重名、引用与保存失败 | 已修改 / 新增并验证 |
| [[runtime-editor-and-project-checks]]、`ui-style/patterns.md` | 当前机制与交互约定 | 已更新 |

## 事实与决定

- 当前 newStory 使用 local 命名空间与 UUID；targetPackId 仅为编辑器会话字段，必须补足每份草稿的归属。
- 当前 copyStoryIdentity 是复制，不用于隐式改名。包管理 savePack 已在存储失败时恢复原记录，沿用该边界。
- 改名只对合同声明的引用操作；不可写包中的已知引用阻止提交。正式包保存仍需重新载入，不热迁移播放游标。
- 继承工作区已有未提交修改，保持其余功能与测试语义；新建交互变化须同步直接依赖的测试准备。
- 施工中确认 Button 合同 / 属性正在另行变化，且其他测试同时写 latest.log；本任务不回滚该变更，后续验证使用独立 JSON 报告核对归属，避免把共享日志内容当成本次运行结果。

## 验证与结果

- 实际验证：14 个唯一文件 / 158 项定向检查，157 通过、1 失败；身份专用 data / UI 与作者 Runtime 共 26 项全部通过，周边模型 / 属性 / Navi 等回归覆盖，workspace 按 3 个互斥标题组完整验证 39 项。去重明细 `.test-artifacts/0359-validation-summary.json`，逐次 JSON 报告由 npm test 输出。
- 唯一未通过：`tests/ui/story-editor-authoring.test.ts` 的 `exposes localFlag fields and structured values in an independent Operation`，位于并行 Button 收敛后新增的 Operation 属性案例，当前期望名称 selected 与实际不一致；本任务不修改 Operation 字段写入或弱化该断言。共享 latest.log 曾被其他测试覆盖，初期日志副本不作为最终计数依据。
- 静态与构建：`check:architecture`、`check:docs`、范围内 diff --check 与生产构建通过，输出位于 `.test-artifacts/0359-build`，构建 7.47 秒。类型检查仅余 `tests/prototypes/infinite-board.test.ts` 的 8 项既有错误；未运行浏览器或全库测试。日志 `.test-artifacts/0359-types.log`、`0359-architecture.log`、`0359-docs.log`、`0359-build.log`。

## 剩余工作与交接

- 无待实施项。正式包改名仅写包并提示重新载入；未实现跨 Mod 迁移、旧存档迁移或正式内容级联删除。
- 最终局部地图只读核对 30 条直接路径：8 条 content_changed、22 条 unreferenced_path；runtime.ts 补读第二页后所有 owner 分页 complete。保存的 Evidence 基线与当前文件不同，不宣称 fresh；未改图、刷新或写 freshness。
