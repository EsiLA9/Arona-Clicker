# Task：Story 编辑器浏览状态与动作条件收敛

状态：已完成

## 目标与验收

本轮解决两处具体的重复维护：浏览状态的定义、默认值和快照恢复散落在三个位置；经典操作区与高级工具栏分别计算相同动作的禁用条件。交付为下面指定的类型、函数和调用链改造，保留 Controller 作为唯一操作编排入口。

不把完整打开／激活／关闭流程搬入另一个 Controller，不引入会话 Port、事件总线、通用事务框架或通用编辑器基类。布局、CSS、内容合同、包格式与玩家业务不在本轮修改范围。已有未提交的侧栏、来源和 Entry 改动作为当前基线保留。

## 一、浏览状态：由 model 定义契约，session 负责转换

### 1. 调整 model.ts 的类型和初始化

在 `src/ui/story-editor/model.ts` 中新增 `StoryBrowseViewState`，从 `StoryEditorState` 移入以下现有字段，字段类型原样保留：

```ts
sourceSelection, targetPackId, target, visits, visitIndex,
selectedNodeId, insertionBeforeNodeId, inspectorView,
nodeDesignerTab, storyInspectorTab, entryEditorTab, notice, error
```

改为 `StoryEditorState extends StoryBrowseViewState`，删除原接口中的重复声明。现有 `state.target` 等访问路径不改，避免全目录重写访问链，也不增加 getter／Proxy 兼容层。

新增 `createStoryBrowseViewState(): StoryBrowseViewState`，返回上述全部字段：来源和目标包为 undefined，target／节点／插入点为 null，历史为空且索引为 -1，inspectorView 为 story，节点页为 basic，Story 页为 overview，Entry 页为 basic，notice／error 为 null。即使类型是可选字段，也必须在返回对象中显式给出 undefined，保证恢复时能清除上一个实例的值。`createStoryEditorState()` 展开此结果，再初始化草稿、侧栏、composer 等共享字段，删除其重复初始化的浏览字段。

`drafts`、`parkedDrafts`、composers、属性分支缓存和 flagImports 不移入浏览状态；复制浏览实例仍共享同一作者草稿。

### 2. 改造 workspace-session.ts 的快照 API

在现有 `src/ui/story-editor/workspace-session.ts` 内完成，继续使用普通数据结构，不新增会话类：

```ts
captureStoryInstanceState(state: StoryBrowseViewState): StoryBrowseViewState
restoreStoryInstanceState(state: StoryEditorState, saved: StoryBrowseViewState): void
createEmptyStoryBrowseInstance(
  workspace: StoryWorkspaceSession,
  current: StoryBrowseViewState,
  source: string,
): StoryBrowseInstance
findStoryBrowseInstance(
  workspace: StoryWorkspaceSession,
  target: StoryEditorTarget,
  source: string,
  runningPackId?: string,
): StoryBrowseInstance | undefined
```

- 删除当前 `viewFields` 和由它反推的 `StoryInstanceState = Pick<...>`；`StoryBrowseInstance.snapshot` 改用必填的 `StoryBrowseViewState`。`createStoryBrowseInstance` 总是从默认工厂创建完整 snapshot，`createStoryWorkspaceSession` 的第一个空实例也遵守这一约束；不能只初始化后续新开的实例。
- 捕获与恢复使用 `createStoryBrowseViewState()` 返回对象的键作为唯一字段集合，不再独立维护第二份字段名数组。只投影这些键，不能展开整个 StoryEditorState；恢复不得写入草稿、左栏、主题或试播字段。
- target、visits 数组及 visit.target 做轻量副本；不得 JSON 克隆整个 state、文档或编辑缓存。实例切换不应创建另一份作者草稿。
- `createEmptyStoryBrowseInstance` 接收当前工作区以分配 nextId、继承当前右栏可见性；从默认值创建全新浏览状态，不再先复制当前实例再逐项覆盖。仅保留现有 targetPackId 规则：来源相同沿用当前值，切至 pack 来源取对应记录 ID，其他来源清空。中右滚动从 0 开始，各记忆 Map 独立创建。
- `findStoryBrowseInstance` 接收 Controller 已解析的 runningPackId，迁入 `openBrowseTarget` 当前匹配谓词：排除当前实例，比较 target.kind／id、sourceSelection；当前游戏来源还需 packId 相同。此函数不读取 Runtime、不调用 save、不切换 active、不写 DOM。

### 3. Controller 中逐项替换

| 现有代码 | 修改后的具体位置与职责 |
| --- | --- |
| `emptyBrowseInstance` 整个方法 | 删除，调用 `createEmptyStoryBrowseInstance`。 |
| `openBrowseTarget` 内查找后台实例的 `.find(...)` 谓词 | 替换为 `findStoryBrowseInstance`；来源是否载入、owner 与 runningPackId 的读取仍在 Controller。 |
| `activateBrowseInstance` 内 `Object.assign(state, snapshot)` | 替换为显式的 `restoreStoryInstanceState`；新建实例必须已有完整 snapshot，禁止用旧活动状态隐式补洞。 |
| `rememberBrowseInstance` | 保留为 DOM／内容适配：先 rememberVisit 和 rememberInspectorScroll，再调用统一 capture，读取滚动及文档名称。 |
| `syncSource` 中来源失效时直接捕获 snapshot 的分支 | 同样调用 capture；保留 previous 草稿的 draftId／packId 与旧目标，不改用已经切换后的 registry 猜身份。 |
| `workspace.active.inspectorTabs` 等 Map getter | 保留；它们说明当前实例所有权，暂不再拆一个 InspectorSession。 |
| 实例列表 push／splice、关闭后选择右邻再左邻 | 保留在打开／关闭的短流程中，不为几行列表操作新增管理器。 |

Controller 继续持有 `syncSource`、`syncSidebarSource`、`selectDocument`、`selectEntryDocument`、`browseTarget`、DOM 刷新和 GameCommands。session 不反向 import Controller／UIContext，也不获得一组转发这些私有方法的回调。

## 二、切换入口：区分保存门控和已保存后的内部恢复

当前 `openBrowseTarget` 保存后还会调用自带保存的 `browseTarget`；工具栏点击又在事件分支判断 save，真正恢复方法自身不说明是否已保存。将这一约定改成下面的明确调用链，全部放在现有 controller.ts 中。

### 1. 改名并拆出已保存后的操作

- 将现有 `activateBrowseInstance` 的恢复主体改名为 `restoreBrowseInstance`，只供内部已通过保存门控的路径和失败回退使用；删除其开头重复的 inlineText.finish，统一由 save 在门控时结束原位输入。
- 新的 `activateBrowseInstance` 是用户意图入口：同一且可用实例直接返回；调用 `save(false, false)`，失败立即返回；成功后调用 `restoreBrowseInstance`。`bindWorkspace` 删除自身的 save 判断，只调用该入口。
- 将 `browseTarget` 分成带保存门控的现有入口和 `selectBrowseTarget` 内部主体。hasTarget、相同目标早退和 save 在入口；从临时工具收尾、记忆当前位置、选择 Story／Entry 到恢复历史的现有主体移入 `selectBrowseTarget`。普通历史／引用导航继续走入口；新实例创建已保存时直接调用内部主体，避免重复保存。

### 2. openBrowseTarget 按以下顺序改写

```text
来源与目标预检查
  → 当前实例已是目标：沿用原早退处理
  → 命中后台实例：activateBrowseInstance(match)
  → 当前为空且同来源：browseTarget(target)
  → 否则 save，失败即返回
      → 记录旧实例；创建未加入列表的候选
      → restoreBrowseInstance(candidate)
      → 来源核验仍匹配且 hasTarget(target) 时 selectBrowseTarget(target)
      → 成功：加入列表或替换旧空实例
      → 失败：restoreBrowseInstance(previous)，保留失败提示，不插入候选
```

`closeBrowseInstance` 关闭后台项无需保存当前草稿；关闭活动项先保存，成功后恢复右邻／左邻／新空实例，再删除旧项。内部恢复及失败回退不得再次触发保存。候选可以在恢复期间成为 active，但只有成功后才登记到 instances；不把一次尝试变成永久空标签。`selectBrowseTarget` 的直接调用必须在新来源下完成 hasTarget 检查，不能依赖切换前的预检查。

### 3. restoreBrowseInstance 内按职责保留三段

1. 捕获旧实例后，关闭 nodeMenu、SelectionNavi、editorDialog、RequiredFlagDropdown、themeContentEdit；关闭目录管理，再清空它可能写入的 pendingVisit，以及 pendingEntryScroll／pendingInspectorScroll／pendingSidebarReveal／pendingFlagReveal／revealNodeId／pendingFocus／focusName。
2. 设置 active、应用完整浏览快照，暂时清空 target 和 entryPoolContext，再按来源是否变化调用 syncSource。保留现有 cached draftId 查找、parked draft 恢复、运行包身份核验和 Story 改名后的历史身份修正；选中节点和插入点必须对照实际文档过滤。
3. 仅调度中右栏 restoreInstanceScroll，交给下一次 refresh 消费。左栏状态不得随实例恢复。refresh 中现有“布局恢复先执行、实例恢复最后执行”的优先级保留，不能把所有滚动合并成一次无条件恢复。

本轮不抽离 refresh、bindWorkspace 或整个 bind 方法；这些属于下一轮另行判断的范围。`save()` 已负责 inlineText.finish，不额外建立第二条原位编辑提交链路。

## 三、动作条件：一份数据计算，两种 HTML 呈现

在 story-editor 目录新增 `document-actions.ts`，只放纯状态计算。输入为 StoryEditorState 和 `{ entryExists: boolean; hasEditingMod: boolean }`，不接收 UIContext／GameReadModel，不访问 DOM、不发命令。Registry 和编辑包查询由 view.ts 在原位置完成。

```ts
type StoryDocumentAction =
  | 'new' | 'save' | 'preview' | 'check' | 'pack'
  | 'apply' | 'restore' | 'rename' | 'delete';

type StoryDocumentActions = Record<StoryDocumentAction,
  { visible: boolean; disabledReason?: string }>;

storyDocumentActions(state, { entryExists, hasEditingMod }): StoryDocumentActions
```

这里只统一语义动作；apply 在 HTML 中仍映射为 Story 的 editor/save-to-runtime 或 Entry 的 authoring/apply。不把图标、大小、工具组、data 属性或 HTML 放入该模块。

| 条件 | 计算规则 |
| --- | --- |
| save／check／pack／rename／delete | 共用 editReason：storageBlocked 优先，其次 readOnlyReason，再次无作者草稿；pack 还受 sourceOptions 的现有可见性控制，rename／delete 仅适用于 Story。 |
| apply／restore | 在 editReason 后检查 canApplySource === false；restore 仅适用于 Story。 |
| preview | 不因“只读”而禁用；先判断草稿／Entry 是否存在，再沿当前高级工具栏规则检查来源是否仍在 sourceOptions 中。真正启动时 authoringClick 的来源核验保留。 |
| new | storageBlocked 或没有编辑态 Mod 时给出原因；不由当前文档只读状态决定。 |
| delete | 在 editReason 后追加“既未 persisted 也未 dirty 时无可删除草稿”的原因。 |

view.ts 的 `editorDocumentCommands` 和 `storyRibbonTools` 接收此计算结果，删除各自的 locked／editable／storageReason／editReason／applyReason／previewReason／newReason 计算。经典 button 增加可选禁用原因参数并转义后写入 title；高级按钮继续用 renderEditorTool 的 reason。经典操作区仅渲染本来就有的动作，不补齐高级模式独有按钮。

统一后有一项明确的呈现调整：经典模式对来源已不可用的试播按钮也提前禁用并给出原因；当前实际命令本就拒绝该情况。本轮不放宽 Runtime 权限，也不让 UI 计算结果替代 `writeBlocked`、`draftSaveAllowed` 和 Runtime 的执行校验。

## 四、测试与文档的具体落点

- 在 story 测试目录新增 `story-editor-workspace-session.test.ts`，使用普通对象，不启动 GameInstance／DOM。覆盖完整快照清除可选字段、复制实例不继承历史且不复制草稿、同 ID 不同来源不匹配、当前游戏来源更换 packId 不匹配。这里测试状态转换，不为每个导出函数机械建一个用例。
- 新增 `story-editor-document-actions.test.ts`，用小状态表覆盖 Story／Entry、只读可试播、无草稿、存储阻塞、canApplySource=false 与缺失来源，不启动完整 UI。分别断言最有区分度的动作，避免把实现结果复制成预期表。
- 扩展现有 `tests/ui/story/story-editor-workspace.test.ts`：保存失败时不切 active、不插入候选、不关闭当前项；新实例打开只经过一次保存门控；模式切换和实例激活继续保留 frame、滚动与共享草稿。已有覆盖足够的场景不重复补测。
- `tests/ui/story/story-editor-pack-source.test.ts` 覆盖来源卸载后激活保留不可用身份／恢复草稿，重新载入后可恢复；Story 改名复用 `tests/ui/story/story-editor-identity.test.ts`。从这两处验证 syncSource 与实例快照的交界，不能仅依靠纯状态测试。
- 对两个模式实际按钮各补一个缺失来源试播用例，验证共用条件已接线，而不只是新函数自身正确。
- 文档只改现有权威页：`docs/docs-830/04-presentation/workspace-columns-and-layout.md` 写明浏览快照与共享草稿的关系；`docs/docs-830/07-tooling/runtime-editor-and-project-checks.md` 更新维护入口；`docs/docs-830/05-domains/runtime-content-coordination.md` 区分基础 GameInstance 的 Registry 保存能力与产品 Runtime 的编辑态包限制。

### 已知 OOM 的处理范围

前轮 `tests/ui/story/story-editor-authoring.test.ts` 单 Worker 在约 4 GB 堆上限退出，不能当作业务泄漏结论，也不能把整套测试设施重构设为本任务的第一项主工程。

施工时先用 `npm test -- tests/ui/story/story-editor-authoring.test.ts -t <用例名> --maxWorkers=1 --minWorkers=1` 单独运行首个用例，再按组缩小范围。单用例即耗尽时，检查其实际初始化与渲染／结构遍历路径；单用例正常但整组累积时，再比较该文件 afterEach 的局部释放与 workspace 测试中 `game.dispose()`、异步让出一次事件循环的做法。不得未定位就套用清理方式或提高堆上限。只修与本轮验证直接相关且已证实的局部问题；无法解决则留下定位证据和未完成验证，其他独立工作可继续，最终不得报告整轮已通过。

## 实施清单

- [x] model.ts 抽出 StoryBrowseViewState 和默认工厂，StoryEditorState 继承，保留现有字段访问路径。
- [x] workspace-session.ts 删除字段白名单，落实捕获／恢复／空实例／身份匹配 API；替换 Controller 的对应逻辑。
- [x] Controller 分开保存门控与内部恢复，按上述调用链改写 open／activate／close；删除事件分支和嵌套打开中的重复保存。
- [x] 新增 document-actions.ts，两个呈现入口接线并删除重复条件；保留命令端校验。
- [x] 按实际影响补充上述纯状态与集成用例，处理或明确记录 OOM 验证障碍，同步三处机制说明。
- [x] 检查最终依赖和差异：session 与 document-actions 没有 UIController／DOM 依赖；没有遗留旧 emptyBrowseInstance、viewFields 或另一套动作条件。

## 验证命令与协作边界

测试统一通过 `npm test -- <文件或过滤条件>`，分批保留日志和摘要至 `.test-artifacts/`，避免后次覆盖。必验新增状态测试、动作测试及上述 workspace／pack-source／identity；再按改动跑 inspector-tabs、inline-text、reference-navi 和 authoring 的受影响用例。源码移动不得依靠改动测试期望来掩盖行为变化。

收尾运行 `npm run check:architecture`、`npm run check:docs` 与本次差异空白检查；按实际影响执行已有类型检查入口。没有改通用栏实现时不扩大到全部 Workspace 测试。本轮不维护 GALHCG。

工程约定见 [[ai/guide/conventions/architecture-discipline]]、[[ai/guide/conventions/testing]]。与 [[ai/plan/task-0369-story-entry-editor-tabs]] 仅核对 Entry 页签交界，不接管其奖励实现或验收。

## 当前进展

- 已完成：浏览状态契约／默认工厂与快照 API、Controller 保存门控与失败回退、两种模式的统一动作条件、对应测试及机制文档。
- 已完成：按用户追加要求定位内存保留与 UI 销毁缺口，补齐事件退订和排队更新的释放。
- 正在进行：无。
- 下一步：归档本 Task；本轮不维护 GALHCG。

## 施工追加：内存与 UI 生命周期缺口

用户在施工中要求查找疑似内存泄漏，追加以下已复现、已修复的范围：

- `controller-events.ts` 原先丢弃 EventBus 的取消函数，`UIController.destroy()` 没有退订。存活 GameInstance → EventBus handlers → 回调闭包 → 已销毁 Controller → DOM 构成强引用保留链。现在由 `UIController.bindEvents()` 幂等持有释放函数，mount、开发入口和全部直接测试调用方改接；destroy 只取消该 UI 的订阅，保留领域服务与其他 UI 的订阅。
- 订阅内已经排队的播放等微任务、`scheduleRender()` 和 UIUpdateDispatcher 原先会在 destroy 后继续执行。两个事件回归先失败；补充排队渲染回归又复现一次。现在取消排队渲染，释放调度器并阻止销毁后的队列／立即更新。三个 Controller 生命周期用例和一个调度器释放用例覆盖这些边界。
- authoring 测试未 mount，不能用上述订阅泄漏解释其 OOM。完整文件在原清理方式下复现约 4 GB OOM；首例与前 8 例分组均通过。核对 Happy DOM 的 QuerySelector／ParentNodeUtility 查询缓存使用 WeakRef 后，做同组对照：仅微任务让步并强制 GC，8 例堆为 321、483、659、838、1095、1260、1401、1545 MB；去掉诊断 WeakRef、只采堆值仍得到同样增长，排除探针本身造成增长。
- 换成每例 `await setImmediate()` 后，完整 36 例在强制 GC 后为 120–143 MB，所有前例 Controller／Game／root 的弱引用均已清除；普通空对象对照也从保留变为可回收。结合无探针完整运行通过，支持这是同一事件循环任务中弱引用对象延迟释放造成的测试堆累积。正式改动仅在该文件 afterEach 增加一次事件循环让步，未提高堆上限、修改依赖或全局测试设施。临时 GC／弱引用探针已移除。

## 结果与验证

- 分批覆盖 19 个文件、221 个不同用例，均通过；没有未报告文件、用例或 Worker 错误。核心 8 文件 96 例；authoring 36 例；生命周期调用方 10 文件 88 例；最后 Workspace／来源／authoring／dispatcher 联测 4 文件 100 例（包含新增的第 9 个 dispatcher 用例，与前述批次重叠）。
- `npx tsc --noEmit --pretty false`、`npm run check:architecture`、`npm run check:docs`（102 页、0 错误）与差异空白检查通过。
- 核心与联测证据：`.test-artifacts/task-0380-core-final.log`、`task-0380-core-final-summary.json`、`task-0380-lifecycle-final.log`、`task-0380-lifecycle-final-summary.json`、`task-0380-integration-final.log`、`task-0380-integration-final-summary.json`。
- 内存证据：`.test-artifacts/task-0380-authoring-oom.log`、`task-0380-memory-microtask-eight.log`、`task-0380-memory-heap-only.log`、`task-0380-memory-yield-full.log`、`task-0380-memory-summary.json`；修复前事件／队列回归见 `task-0380-event-disposal-before.log`、`task-0380-queued-render-before.log`。
- 未运行仓库全量测试与浏览器长期内存压测；本结论限于已复现的 UI 生命周期缺口和该 authoring 测试的堆累积，不声称项目不存在其他泄漏。保留工作区原有未提交修改，未提交 Git。
