# Task：Init／Area／Spot 三合一编辑器路线图

状态：已完成

## 首版交付

「世界编辑器」使用默认 Init → Area → Spot 三层目录。顶部 `save-actions service-nav-actions` 和高级模式 `editor-workspace__rail` 都能直接打开它。首次进入创建一个「世界内容」浏览实例，同一实例内切换实体，重复点击入口复用该实例。首版用当前 Registry 的定义验证真实关系，右侧提供摘要和可点的父子链接。表单、草稿编辑、应用到运行时、编辑包选择、星图和强化均为后续范围。

## 1. 先交付可点击的默认目录

- 在 `src/ui/runtime-editor/` 新建 `world-browser.ts` 并增加纯投影 `buildDefaultWorldTree`，以 `Area.initId` 和 `Spot.areaId` 连接定义。`defaultAreas`、`defaultSpots` 只做「默认」标记。渲染名与完整 ID 分开。父级缺失时把条目放到「归属缺失」，仍可查看。
- 树行使用展示节点 key 和独立实体引用。节点可携带实体或仅作分组，`children` 可递归，渲染器不按深度推断实体类型。默认投影负责三层规则。未来自定义目录可以重排节点或在不同路径引用同一实体，继续用同一详情解析接口。首版只实现默认投影，不提前实现目录配置、拖拽、持久化或注册机制。

```ts
type WorldEntityRef = { kind: 'init' | 'area' | 'spot'; id: string };
type WorldTreeNode = {
  key: string;
  label: string;
  ref?: WorldEntityRef;
  isDefault?: boolean;
  children: readonly WorldTreeNode[];
};
```

- 左栏展示树，主栏展示选中实体。Init 摘要有 Area 链接，Area 摘要有 Init 和 Spot 链接，Spot 摘要有 Area 链接。所有行点击和摘要链接走同一个 `selectWorldEntity(ref)`，展开祖先并定位树行。两类按钮分开，展开不改变选中。页面首次打开优先选当前 Init，没有时选排序后的首个 Init，空目录显示提示。

验收：点「Init → Area → Spot → 所属 Area」，主栏摘要与左侧选中同步。默认和非默认 Spot 均能打开。同名 Area 按 ID 分开。缺父项仍可点开。

## 2. 接入已有 Workspace 和顶部入口

- 用 `workspace-frame.ts` 的 `renderWorkspaceFrame` 装配目录和详情，用 `editor-workspace.ts` 的 `renderEditorWorkspace` 渲染经典／高级外壳与实例条。复用 Story 侧栏的展开、选中和独立滚动约定。Story 目录投影保留在 Story 域。
- 在 `workspace-router.ts` 增加世界浏览路由，由 `workspace-renderer.ts` 分派。实例状态由世界浏览会话持有，包含稳定实例 ID、选中的实体引用、折叠集合和目录滚动。Inspector 或详情的上下文从引用重新查询。沿用现有 Workspace 返回位置。只在第一次成功进入后创建实例，重复打开复用，显式关闭后允许重新创建。
- 在 `header.ts` 的 `.save-actions.service-nav-actions` 增加「世界编辑器」，用现有 Header 按钮样式；`controller-actions-topbar.ts` 接到统一的 `openWorldBrowser()`。保持现有 Runtime Editor launcher 的入口与用途。原 task 曾选 Codex 内容浏览器作为宿主，因本版需要高级 rail 和实例条，改用与 Story 同一个 EditorWorkspace 外壳，并在现行 Runtime Editor 目录内放世界内容投影与视图。

验收：从游戏顶部打开世界浏览，切入高级模式，看见一条「世界内容」实例。切换多个 Init／Area／Spot，实例条仍是一项。重复打开入口保持选中和折叠。关闭后返回进入编辑器前的页面。

## 3. 接高级 rail，完成两个入口的同实例回路

- 在 `story-editor/view.ts` 和世界编辑器 chrome 中提供 Story／世界工作类型，沿用 `EditorWorkspaceChrome.workTypes` 与 `data-editor-work-type`。Story 的 `bindWorkspace` 当前把所有 work-type 点击当作展开故事目录，改为按工作类型分派。点当前类型展开本目录，点另一类型走它的编辑器入口。
- rail 打开世界时传入高级模式，由同一个 `openWorldBrowser()` 激活已有实例。跨类型切换复用现有 Workspace 的单层返回契约和 Story 的 beforeLeave 保存门控。把进入编辑器前的返回位置保留下来，切类型时替换当前路由，避免 Story 和世界互相变成退出目标。失败保持原工作区，禁止入口先建标签再尝试切换。验证从 Story 进入世界后可以回到 Story 的原文档，并可从 rail 再打开同一个世界实例。切回经典或高级时沿用实例状态。rail 保留既有专注布局的显示规则，验收在 rail 可见的浏览布局执行。
- 首版只要求世界工作类型内部有一条世界实例。Story 原有实例继续由其会话管理，通过 rail 在两类工作区之间切换。

验收：从 Story 高级模式点「世界」→ 选一个 Spot → 点「故事」→ 再点「世界」，检查世界实例 ID、选中项、折叠和滚动均保持，Story 仍在原文档。模拟 Story 草稿保存失败，页面仍停在 Story，世界实例不新增。

## 阶段检查与后续

- 第一段用纯数据用例覆盖默认层级、同名实体和缺父项。第二、三段用 Header／rail 的真实入口做交互回归，覆盖实例复用、返回位置、Story 保存失败。施工结束运行 `npm test` 的相关定向批次、类型检查和文档检查，再按三个验收步骤做宽屏鼠标走查。
- 默认目录验收后，再评估自定义层级需要的分组规则与路径存放位置。那一阶段只需增加新的目录投影，验证重复引用同一实体时两条路径能各自定位到同一个定义。真实表单接入等用户确认后另立交付。

## 交付与验收结果

- 由 6.2 Sol 子 Agent 实施。世界目录、实体链接、顶部和高级 rail 入口接入现有 Workspace 外壳。目录节点 key 与实体引用独立，首版开放一条世界浏览实例。经典模式也能用返回按钮退出。
- 主 Agent 用实际本地浏览器从大厅页顶部打开，走完 Init → Area → Spot → 所属 Area。经典模式重复开入口保留当前选择，直接关闭返回大厅。
- 浏览器中从 Story 高级模式打开世界，选择阿比多斯咖啡角后返回 Story，确认「星野的天台邀约」仍为当前文档。再进世界确认实例 ID 仍是 2、实例条仅一个世界条目、原 Spot 与 Area 展开状态保留。分别从大厅和设置进入，在 rail 往返后退出，均回到原页面。
- Scene/Workspace 定向回归 3 文件、64 例通过，包含世界目录 5 例以及 Story Workspace 和路由回归。用例验证 Story 保存拒绝时留在原工作区、不分配世界实例，以及世界树滚动位置在 rail 往返后恢复。摘要见 `.test-artifacts/task-0381-regressions-summary.json`。
- 主 Agent 复跑 Runtime Editor 全目录、Workspace 生命周期、星图导航共 16 文件、163 例，全部通过。两批覆盖有重叠。摘要见 `.test-artifacts/task-0381-acceptance-summary.json`。类型、架构、文档与差异空白检查通过。
- 现有实现为只读浏览原型。自定义目录配置与实际编辑表单属于后续交付。
