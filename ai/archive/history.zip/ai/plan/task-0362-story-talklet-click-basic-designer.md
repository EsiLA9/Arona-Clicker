# Task 0362：完成 Talklet / Click 基础内容设计器

状态：已完成 — 2026-11-06；基础设计器与自动化验收完成，按用户许可跳过浏览器人工验收。

## 目标与范围

- 目标：围绕真实 Talklet / Click StoryNode 完成基础内容设计、预览、校验与保存闭环，使作者能直接编辑正文与交互，不必进入嵌套的动作对象。
- 本 Task 可独立验收；高级演出由 [[ai/plan/task-0363-story-talklet-click-performance-designer]] 承接，Operation 内容迁出由 [[ai/plan/task-0364-story-operation-display-content-migration]] 承接。
- 沿用现有三栏、统一 Story / Entry 浏览目标、节点身份和编辑态 Mod 写入路径，不新建另一套编辑器或草稿模型。
- 不恢复 Button result、Choice sharedActions / option result、自动老师回复或旧 stages 推进语义；不包含分页、工具台整体重做、富文本、语音或动画编排。

## 交付内容与验收

- [x] Talklet：对话 / 旁白、唯一正文、角色引用与临时显示名、对话图片、左右侧 / 旁白对齐、头像覆盖及显隐、适用时的输入 / 思考节奏均有直接编辑入口。
- [x] Click：单按钮文案及按击次数；Choice 有序选项、出现条件、marks 与现有后续节点关联；EntryCard 文案 / 对齐 / 目标 / owner / continuation，以及现有到地点接续入口均形成完整闭环。不增加已退役的作者模式。
- [x] 普通字段平铺、必要分组适量；按击次数不再同时要求“启用”和“配置”两次操作，随机增量不多套一层容器。保留未配置、显式 0、有效值和无效草稿之间的区别。
- [x] 可选字段可恢复省略态；类型与分支切换保留作者输入，未完成数值不静默改成默认值，隐藏分支不错误发布。
- [x] 正文原位编辑、右栏表单和中栏预览使用同一草稿值；选项排序、节点改名 / 复制 / 导航、保存重载后保持对应身份。
- [x] 建立可独立挂载的基础属性区域；0363 再接入真实可用的“基础｜演出”Switch，本阶段不预建空白演出页。切换编辑页的共同约束是保留同一节点与同一份正文。
- [x] 普通输入、选项编辑与刷新保留有效控件、焦点 / 光标和无关栏滚动；修复范围内的行为测试通过，更新受影响视觉约定与机制说明。

## 事实与决定

| 问题 | 已核实事实或用户裁定 | 实施边界 |
| --- | --- | --- |
| 当前数据 | `story-node.ts` 区分 Talklet 的 content / presentation / pacing 与 Click interaction；单按钮 result 已移除 | 从当前契约核实覆盖，不按 0348 的旧字段矩阵恢复退役功能 |
| 基础与高级 | 用户接受围绕节点实体设计，以及“基础｜演出”编辑页切换 | 基础排版与头像继续可直接编辑；定位与样式覆写由 0363 接入，不重复维护字段 |
| 现有能力 | `property-fields.ts` 已有多数表单，`view.ts` 已复用实际气泡 / Click 外观 | 补齐并整理已有实现，不以重建全部表单作为目标 |
| 既有任务 | [[ai/plan/task-0348-story-talklet-click-authoring-coverage]] 留有字段覆盖与 ID 历史；[[ai/plan/task-0355-story-editor-theme-position-and-flow-tools]] 留有主题 / 预览工具工作 | 本 Task 接管本轮基础设计器范围；既有任务其他工作与验收不自动标为完成 |

## 当前进度

- [x] 按会话调研建立范围、依赖和验收要求。
- [x] 施工前对照当前源码列出字段的编辑、默认、预览、保存与错误反馈缺口，复用已完成能力。
- [x] 完成缺口与基础属性区域，验证后记录实际改动和结果。
- 实施结果：基础属性区已独立挂载；按击次数与适用节奏直接编辑；清空省略、角色临时名、右侧切回默认的节奏恢复及可选对象缓存恢复已修正。
- 下一步：归档本 Task，0363 在该基础区旁接入真实演出页；0364 保持后续独立迁出范围。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-node.ts` | 有效作者字段与分支 | 已复核，无合同或 Schema 字段修改 |
| `src/ui/story-editor/property-fields.ts`、`property-model.ts` | 表单、可选 / 分支缓存及稳定行身份 | 已修改，复用现有路径 / rowId / 草稿缓存 |
| `src/ui/story-editor/view.ts`、`controller.ts`、`inline-text.ts`、`dom.ts` | 预览、事件、原位编辑与局部 DOM 协调 | controller 已修改；view / inline-text / dom 只复核并复用，未在本任务改动 |
| `src/ui/story-editor/model.ts`、`persistence.ts`、`authoring-model.ts`、`identity.ts` | 草稿投影、持久化、包归属与身份 | 已核对；model 仅保留临时名及支持移除角色，其余现有身份 / Mod / 持久化路径不变 |
| `tests/ui/story-editor-properties.test.ts`、`story-editor-properties-acceptance.test.ts`、`story-editor-inline-text.test.ts`、`story-editor-workspace.test.ts` | 字段行为、草稿、DOM 连续性与导航 | 已运行，连同模型、作者 API、复制和身份共 8 文件 / 122 项通过 |
| [[runtime-editor-and-project-checks]]、[[story-chat-and-theme-presentation]]、`ui-style/patterns.md` | 当前机制与 UI 复用规范 | 机制说明与 patterns 已同步；未改动高级渲染机制 |

## 字段复核与实际改动

| 基础能力 | 处理结果 |
| --- | --- |
| Talklet 正文、对话 / 旁白、对齐及头像策略 | 复用现有唯一正文、预览和分支缓存；图片 / 头像清空省略，角色选择保留临时名并可移除角色引用 |
| 输入 / 思考节奏 | 适用时直接填写；原文字校验，0 显式关闭；右侧切回默认恢复休眠输入 |
| Button 文案与按击工作量 | 去除启用 / 初始化的双重操作与随机增量嵌套；两个直接输入，全空省略，缺 base 不发布 |
| Choice 候选 / 条件 / marks / 后续关联 | 复用稳定行、有序项、条件树与标记绑定；条件创建和恢复合为一次操作，恢复不覆盖缓存 |
| EntryCard / areaContinue | 复用 active/card、owner、目标、对齐、文案和续播地点；续接缓存恢复保留 areaId / returnFlags；可选标题清空省略 |
| 基础区域与刷新 | 导出 `renderStoryNodeBasicProperties()`，仅增加一个稳定语义 section，无新滚动宿主；复用 region 协调及控件 key |

## 验证与结果

| 检查 | 实际结果 | 后续要求 |
| --- | --- | --- |
| 文档 / 差异检查 | `npm run check:docs` 127 页、0 错误通过；任务范围 `git diff --check` 通过 | 完成后按工作流归档，最终路径再次检查 |
| 实现行为 | `npm test -- tests/ui/story-editor-properties.test.ts tests/ui/story-editor-properties-acceptance.test.ts tests/ui/story-editor-model.test.ts tests/ui/story-editor-inline-text.test.ts tests/ui/story-editor-node-clipboard.test.ts tests/ui/story-editor-identity.test.ts tests/ui/story-editor-workspace.test.ts tests/ui/story-editor-authoring.test.ts --maxWorkers=1 --minWorkers=1`：8 文件 / 122 项通过 | 完整输出 `.test-artifacts/0362-ui-full.log`（运行器同时写 latest.log）；临时使用 8GB Node 堆，无配置修改 |
| 回归证据 | 先复现基础区缺失、节奏无法直接编辑及角色切换丢失临时名，再完成修复；新增 4 个综合用例 | 按击 0 / 缺基础次数 / 全清空；焦点 / 光标 / 无关栏滚动；无效节奏休眠恢复；图片 / 头像 / 标题省略；条件和续接关闭、重载、恢复 |
| 类型检查 | `npx tsc --noEmit --pretty false` 未通过：Area Reveal 在途改动和旧 infinite-board 测试报错；本任务修改的 Story 编辑器及测试无报错 | `.test-artifacts/0362-types.log`，不修改其他任务代码 |
| 地图只读复核 | 直接影响的 9 条路径已集中检查，5 条已映射路径报告旧依据变化，4 条未关联；owner 分页完整 | 未改图、刷新或写 freshness |
| 浏览器人工验收 | 未执行，沿用用户允许环境不佳时跳过的约定 | DOM 交互与保存行为已有自动化证据，视觉仍未人工确认 |

## 剩余工作与交接

- 已读取 UI 领域包、frontend-design skill / 项目覆盖协议、测试与任务工作流；复用现有 UI 和本地草稿状态，无 Runtime / Schema 变动。
- 高级定位、局部样式、定点清理仍由 0363 承接；Operation 内容仍由 0364 迁出。已有 Button result / Choice 通用结果保持退役。
