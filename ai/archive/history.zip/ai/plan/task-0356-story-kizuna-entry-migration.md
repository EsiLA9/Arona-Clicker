# Task：Story 关联羁绊数据转为剧情入口表达

状态：完成 — Story 编辑与正式内置内容已迁至 StoryEntry 剧情入口；旧格式仅保留运行兼容。

## 目标与范围

- 目标：全面把 Story 内容中作者使用的关联羁绊结构迁移为剧情入口（StoryEntry）表达；Story 编辑器不再提供关联羁绊模式。
- 范围与明确非目标：保留旧 `StoryEntry.kizuna`、`kizunaCard` 及其运行机制作为兼容机制；不删除旧存档/数据合同，不改变其运行语义。新编辑流程使用剧情入口卡选择具体 StoryEntry；地点继续保留原有语义。
- 验收：编辑器不出现关联羁绊模式；新入口能选择 StoryEntry；旧数据仍可投影/播放；相关测试与文档通过。

## 当前进度

- [x] 核实编辑器、合同、运行时中 `kizuna` / `entryCard` / `areaContinue` 的职责。
- [x] 移除编辑器创建 `kizunaCard` 和配置 Entry.kizuna 的作者入口；剧情入口卡现有 StoryEntry 选择保留。
- [x] 将旧绑定的数据迁移到新剧情入口表达，并在保留返回父游标等旧运行语义的前提下对齐目标引用。
- [x] 更新编辑器测试与机制文档；新旧运行路径回归通过。
- [x] 迁移全部正式内置 Story 内容与生成 base-pack JSON。
- 正在进行：无。
- 下一步：无。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-entry.ts` | StoryEntry 旧羁绊绑定 | 保留兼容读取与运行 |
| `src/data-services/contracts/story-node-actions.ts` | StoryEntryCard 与 continuation 合同 | 已加入入口续接字段 |
| `src/data-services/authoring/story-definition-projection.ts` | 入口续接投影与引用校验 | 已修改 |
| `src/data-services/validation/story-continuations.ts` | 一层子故事、目标、Area 校验 | 已兼容新 continuation 卡 |
| `src/ui/story-editor/property-fields.ts` | Click 编辑器选择项 | 已移除 kizunaCard 选项 |
| `src/ui/story-editor/authoring-view.ts` | StoryEntry 羁绊作者表单 | 已移除羁绊字段 seed 与专用表单 |
| `src/ui/story-editor/controller.ts` | 羁绊接续模式输入处理 | 已移除旧编辑器事件分支 |
| `src/ui/story-editor/property-model.ts` / `persistence.ts` | Click 草稿正文与校验 | 已停止将旧 kizunaCard 当作可编辑正文字段 |
| `src/arona-clicker/content/character/affection-content.ts`、`story/story-shiroko.ts`、`story/story-hoshino.ts`、`story/story-conversation-walls.ts` | 内置 Story 子故事入口与 Entry 绑定 | 已改为显式 StoryEntry card.continuation |
| `src/arona-clicker/content/base-pack/content.json` | 生成的 bundled datapack | 已同步 TypeScript source |
| `docs/docs-830/07-tooling/runtime-editor-and-project-checks.md`、`ui-style/patterns.md` | 机制与 UI 约定 | 已更新编辑器兼容边界 |
| `src/arona-clicker/services/story/story-service.ts` | 旧运行机制 | 已核对，保留 |
| `tests/ui/story-editor-properties-acceptance.test.ts` | 编辑器入口测试 | 待修改 |
| `tests/ui/story-editor-authoring.test.ts` | 作者表单测试 | 待修改 |
| `tests/engine/story-continuation.test.ts` | 新旧机制父子续接、Area 与 flags 回归 | 已新增新结构用例并通过 |
| `tests/engine/shiroko-story-samples.test.ts` | 内置迁移实际播放 | 已通过 |

## 事实与决定

| 问题 / 决定 | 已核实事实及源码、测试或文档依据 | 待解决问题 |
| --- | --- | --- |
| 旧羁绊数据 | `StoryEntry.kizuna` 保存 `entryId`、可选赴约 Area 与回传标记；StoryService 有对应子故事接续流程 | 保留为兼容机制 |
| 新作者表达 | `entryCard.card.request` 指向 Active StoryEntry；可选 `card.continuation` 承载赴约 Area / flags 白名单 | continuation 对象存在即使用父子游标语义 |
| 迁移兼容边界 | 旧 `Entry.kizuna` / `kizunaCard` 保留在合同与运行时，正式内置内容已迁出 | 旧测试夹具只用于兼容回归 |

## 验证与结果

| 检查对象与方式 / 命令 | 实际结果 | 失败后的排查与处理 / 未执行原因 |
| --- | --- | --- |
| `npm test -- --run tests/ui/story-editor-properties-acceptance.test.ts tests/ui/story-editor-authoring.test.ts --silent --reporter=dot` | 2 文件 / 14 项通过 | — |
| `npm test -- --run tests/engine/story-continuation.test.ts tests/ui/story-continuation.test.ts tests/ui/story-ending-navigation.test.ts tests/engine/shiroko-story-samples.test.ts --silent --reporter=dot` | 4 文件 / 36 项通过 | 旧数据仍走兼容机制 |
| `npm run check:docs` | 123 Markdown，0 错误 | — |
| `node scripts/sync-base-datapack-bundle.mjs --check` | 47 个 Story 与 TypeScript source 一致 | — |
| 全量 `npm test` | 370 / 371 文件，3693 / 3695 项通过；唯一失败文件为 `tests/prototypes/infinite-board.test.ts` 的 2 项用例 | 原型测试的节点 schema 与 addEdge 调用仍按旧签名；未触及该原型 |
| `npx tsc --noEmit` | 本次 Story 文件零诊断 | 仍报告 `tests/prototypes/infinite-board.test.ts` 的 8 处旧类型/参数错误 |
| `git diff --check` | 通过 | 只有工作区 CRLF/LF 提示 |

- 当前结果：编辑器新建入口只使用 StoryEntry card；旧作者控件和交互选项隐藏。正式内置内容已全部改用显式目标入口卡，续接、地点赴约和 flags 随卡保存。运行时支持新格式并保留旧格式兼容。测试、文档、base-pack 同步均已核对。

## 剩余工作与交接

- 无。全量检查中仅有既存 Infinite Board 原型测试/类型错误，与 Story 迁移无关。
