# Task：测试文件价值与源码可测试性审计

状态：调查完成 — ST-01 至 ST-11 已回收，FinalOutline 已收口；只读审计，未运行测试

## 目标与范围

- 目标：只读审查仓库测试文件的必要性、实际价值、覆盖完备性及对应生产代码的可测试接口；形成带证据、可用于决定后续工作的总览与行动顺序。
- 范围：当前 `tests/` 与 `tools/datapack-editor/` 下的 396 个 `.test.ts` 文件；必要的生产源码、共享 fixtures / mocks / setup、Vitest 配置与测试输出入口。
- 明确非目标：不修改测试、生产代码或架构；不因审查自动新增测试、删除测试或启动重构；不把历史测试失败自动认定为当前缺陷或产品要求。
- 验收：每个测试文件恰好归属一个 SubTask；每个 SubTask 提交逐文件 SubOutcome；主 Agent 核对覆盖清单、合并重复与矛盾结论后完成 FinalOutline；每项 Finding 附具体路径、位置、证据、影响与建议；调查过程不修改代码。

## 当前进度

- [x] 读取 `AGENTS.md`、`ai/guide/task-workflow.md` 与 Task 模板，确认使用现有 Task 文件和活动索引。
- [x] 清点当前测试文件：396 个 `.test.ts`，分布见下表；据现有目录划分互斥 SubTasks。
- [x] 开始审查并建立逐文件到生产源码的索引；切片按当前 396 个测试文件复核。
- [x] 完成 11 个 SubTasks 并回收 SubOutcomes。
- [x] 主 Agent 核对清单、整合跨模块结论并写入 FinalOutline。
- 已完成：ST-01 至 ST-11 均有逐文件 SubOutcome；总审查完成，未运行测试。
- 后续如实施建议，另建实施 Task；本 Task 不修改代码或测试。

## 测试文件清单与切片

目录扫描计数：

| 顶层范围 | 文件数 | 分配位置 |
| --- | ---: | --- |
| `tests/engine/` | 201 | ST-01 至 ST-04 |
| `tests/data/` | 49 | ST-05 至 ST-06 |
| `tests/ui/` | 131 | ST-07 至 ST-09 |
| `tools/datapack-editor/` | 10 | ST-10 |
| `tests/prototypes/`、`tests/tooling/` | 5 | ST-11 |
| **总计** | **396** | **ST-01 至 ST-11，互斥且完整** |

## SubTasks

所有范围均指对应目录中的 `*.test.ts`；同一模块的非测试 fixture、helper、mock 随目录所有者审查。跨目录被引用的文件可只读查阅，但不改变其唯一审查归属。启动时逐文件生成清单并复核数量。

| ID | 唯一负责范围 | 文件数 | 状态 / 负责人 |
| --- | --- | ---: | --- |
| ST-01 | `tests/engine/story/`、`tests/engine/gameplay-b/`；含该范围共享剧情 / 地图 fixtures | 66 | 已完成 / `audit_engine_story_gameplay` |
| ST-02 | `tests/engine/area-map/`、`tests/engine/operation/`、`tests/engine/progression/`、`tests/engine/world/` | 40 | 已完成 / `audit_engine_story_gameplay` |
| ST-03 | `tests/engine/character/`、`tests/engine/theme/`、`tests/engine/runtime-content/` | 50 | 已完成 / `audit_engine_story_gameplay` |
| ST-04 | `tests/engine/core/`、`tests/engine/def-factory/` | 45 | 已完成 / `audit_engine_story_gameplay` |
| ST-05 | `tests/data/datapack/`、`tests/data/persistence/`、`tests/data/area-map/` | 22 | 已完成 / `audit_data_storage_map` |
| ST-06 | `tests/data/runtime-content/`、`tests/data/operation/`、`tests/data/story/`、`tests/data/gameplay-b/` | 27 | 已完成 / `audit_data_storage_map` |
| ST-07 | `tests/ui/story/`、`tests/ui/gameplay-b/`、`tests/ui/components/`；含目录内共享 UI fixtures / helpers | 47 | 已完成 / `audit_ui_story_gameplay` |
| ST-08 | `tests/ui/area-map/`、`tests/ui/workspace/`、`tests/ui/runtime-editor/` | 37 | 已完成 / `audit_ui_story_gameplay` |
| ST-09 | `tests/ui/theme/`、`tests/ui/controller/`、`tests/ui/core/`、`tests/ui/interaction/`、`tests/ui/startup/`、`tests/ui/character/`、`tests/ui/commerce/` | 47 | 已完成 / `audit_ui_story_gameplay` |
| ST-10 | `tools/datapack-editor/model/`、`schema/`、`ui/`、`validate/` 下测试及其直接共享设施 | 10 | 已完成 / `audit_data_storage_map` |
| ST-11 | `tests/prototypes/`、`tests/tooling/` 共 5 个测试；`tests/setup.ts`、`vitest.config.ts`、`scripts/run-tests.mjs`、`scripts/test-output-summary.mjs` 等共享测试入口 | 5 个测试 + 入口设施 | 已完成 / 主 Agent |

分工规则：SubTask 以目录切片为主要单位、测试文件为最小单位；若启动时发现目录计数或文件位置变化，先更新互斥清单再派发。最多按当时可用的并发槽位运行独立 SubTasks；主 Agent 负责清单、跨切片问题、证据复核和收口，不重复逐文件审查已完成的切片。

## SubOutcomes

每个 SubTask 完成后由主 Agent 在此记录其交付；每份结果至少包含：

1. 审查范围：逐文件路径及关联生产代码路径。
2. 逐文件结论：必要性、实际价值、完备性、源码接口情况；建议保留 / 调整 / 合并 / 删除候选及理由。
3. Findings：优先级、路径与代码位置、证据、影响及建议；无问题文件也保留简要结论。
4. 覆盖缺口：区分单文件断言缺口与模块级风险缺口。
5. 跨模块问题与未确认事项：列出协同核对对象及缺少的证据，不将推测写成事实。

### ST-01 — Engine Story 与 Gameplay B

- **范围**：`tests/engine/story/` 29 个测试、`tests/engine/gameplay-b/` 37 个测试，另审 4 个共享 fixtures/helpers。逐文件证据与代码关联来自 Luna MAX SubOutcome；未运行测试、未修改文件。
- **逐文件结论（Story）**：
  - `hoshino-story-spaces.test.ts:27` — 保留：内置多空间剧情/存档隔离，真实 Runtime。
  - `shiroko-story-samples.test.ts:34` — 保留：子调用、Area 接取、标记返回与重读隔离，真实 StoryService。
  - `story-authoring.test.ts:18` — 保留：作者事务、预检、预览、重命名、持久化失败，Runtime/Pack API。
  - `story-choice-deferred-operations.test.ts:18` — 保留：Choice marks、延迟动作、恢复与部分提交，Player/Mock Host。
  - `story-continuation.test.ts:41` — 保留：父子会话、返回标记、保存/取消/重读/失败恢复，真实服务集成。
  - `story-cursor-preflight.integration.test.ts:10` — 保留：坏快照不污染当前游标，恢复根 Choice/insert 归属。
  - `story-definition-boundary.test.ts:6` — 保留：Registry 定义往返与未知字段拒绝。
  - `story-definition-save.test.ts:13` — 保留：GameCommands/Registry 保存及运行/包/玩家状态隔离。
  - `story-entry-fallback.test.ts:11` — 保留：冷却、地区兜底、拒绝后重试的真实投放。
  - `story-entry-split.test.ts:33` — 保留：Entry/Story 分离、引用校验、奖励归属。
  - `story-flow.test.ts:47` — 保留：Click/Transfer/insert 推进门控；stage 保留符合当前合同。
  - `story-node-action-host.admission.test.ts:63` — 保留：动作执行时重验准入与批内状态变化。
  - `story-node-action-host.test.ts:99` — 保留：EffectEngine 回执、旅行失败、呈现意图和 Entry 准入。
  - `story-node-playback.integration.test.ts:42` — 保留：播放器与领域服务集成、覆盖层、拒绝和部分提交。
  - `story-node-player.boundaries.test.ts:53` — 保留：自动转移次数 32/33、256/257 与取消/错误边界。
  - `story-node-player.result.test.ts:28` — 保留：Operation 回执、结果顺序和恢复合同。
  - `story-node-player.snapshot.test.ts:27` — 保留：检查点恢复、坏快照拒绝和同步动作存档。
  - `story-node-player.test.ts:75` — 保留：Player 控制流、localFlags、Choice、ticket、insert/goto。
  - `story-node-presentation-host.test.ts:65` — 保留：主题/覆盖层呈现归属、清理和恢复隔离。
  - `story-node-presentation-lifecycle.test.ts:48` — 保留：临时呈现按 run/owner 清理，不误删其他 scope。
  - `story-node-save.integration.test.ts:24` — 保留：正式节点存档切换、多 owner 与坏格式原子拒绝。
  - `story-playback-coordinator.test.ts:19` — 保留：计时、输出、队列、交接、失败不重发奖励；覆盖较广，可按生命周期拆分。
  - `story-playback-snapshot.test.ts:11` — 保留：延迟启动因果、队列上限和坏快照准入。
  - `story-replay.test.ts:75` — 保留：重读分支门控与奖励状态隔离。
  - `story-reward-receipts.test.ts:26` — 保留：通知失败时回执保留已提交前缀且不重复调用旧接口。
  - `story-rewards.test.ts:17` — 保留：条件奖励分支、兜底与链内访问条件。
  - `story-run-flags.integration.test.ts:57` — 保留：初始/局部标记贯通命令、存档、owner 隔离。
  - `story-run-flags.test.ts:19` — 保留：局部字典、Choice 门控、拷贝/恢复与错误输入。
  - `story-service-node.integration.test.ts:28` — 保留：Service 重入、owner/token 隔离、结算/奖励/存档。
- **逐文件结论（Gameplay B）**：
  - `gameplay-b-actual-amount-threshold-example.test.ts:14` — 保留：按实际 HP 损失触发阈值（护盾不等于请求伤害）。
  - `gameplay-b-ag1-order.test.ts:18` — 保留：确定性来源排序、平手、输入不变和边界。
  - `gameplay-b-ag1-source-adapter.test.ts:98` — 保留：Party/Enemy/Ability/Item 来源适配及伪造 CardRef。
  - `gameplay-b-basic-map-p0-p3.test.ts:113` — 保留：真实 MapRun 的用户级 P0–P3 纵向路径。
  - `gameplay-b-damage-applied-resource-example.test.ts:14` — 保留：实际收件人/HP 损失与后续资源读取。
  - `gameplay-b-damage-protection-example.test.ts:14` — 保留：DamageProtection、Shield 顺序、v6 恢复与到期收益。
  - `gameplay-b-editor-authoring-workflow.test.ts:169` — 迁移候选：Editor/PackParser/Scene Runtime 集成有价值，但不是 Gameplay B MapRun，建议迁至 Editor/Pack 集成组。
  - `gameplay-b-effect-card-prepare.test.ts:10` — 保留：CardRef 准备/消费时点、Owner 卡与成本分离。
  - `gameplay-b-effect-example.test.ts:65` — 保留：Status/Shield/Modifier/Revive 作者示例和真实回执/恢复。
  - `gameplay-b-effect-legacy-goldens.test.ts:37` — 保留：E1 兼容行为；legacy 默认合同当前仍有效。
  - `gameplay-b-effect-lifecycle.test.ts:94` — 保留：Encounter 局部状态生命周期、静态/动态边界。
  - `gameplay-b-effect-planner.test.ts:61` — 保留/拆分候选：纯规划器边界有效、语义很多；1939 行单一大 describe 增加维护成本。
  - `gameplay-b-effect-program-commit.test.ts:115` — 保留：Planner 安装与跨 owner 原子提交、失败零写入。
  - `gameplay-b-effect-program.test.ts:59` — 保留：预览与来源计划、成本预检、resolver 复核。
  - `gameplay-b-effect-projection.test.ts:160` — 保留：声明效果只读投影与 PlayerCommand 不扣费。
  - `gameplay-b-effect-receipt-boundaries.test.ts:88` — 保留：Receipt 恢复信任边界，拒绝伪造来源/金额/轨迹。
  - `gameplay-b-effect-receipt.test.ts:104` — 保留：回执重算、HP/Status/资源链与篡改拒绝。
  - `gameplay-b-effect-rng.test.ts:18` — 保留：持久 RNG 固定向量、拒绝抽样和游标边界。
  - `gameplay-b-effect-save-resume.test.ts:163` — 保留：E1/E2、Status/Tag/Facts 和损坏快照恢复。
  - `gameplay-b-enemy-defeated-reward-example.test.ts:15` — 保留：实际击杀来源与到期反馈。
  - `gameplay-b-event-runtime-integration.test.ts:91` — 迁移候选：覆盖 Operation Runtime 公开入口、Run 隔离和存档；不属 MapRun，应迁至 Operation 集成目录。
  - `gameplay-b-heal-applied-resource-example.test.ts:24` — 保留：治疗封顶、满血及预算原子拒绝。
  - `gameplay-b-map-ag1-commit.test.ts:132` — 保留/拆分候选：AG-1 原子提交边界广，1444 行适合按来源/状态/事务分组。
  - `gameplay-b-map-ag1-restore.test.ts:186` — 保留/拆分候选：多版本回执、篡改拒绝与终局恢复，974 行可按回执类型分组。
  - `gameplay-b-map-cards.test.ts:65` — 保留：CardRef 身份、准备/交换/折扣/重试/恢复。
  - `gameplay-b-map-id.test.ts:5` — 保留：稳定 `map` Entity ID 前缀的小型格式合同。
  - `gameplay-b-map-relations.test.ts:79` — 保留：实际目标与声明效果关系投影、来源隔离/替换/恢复。
  - `gameplay-b-map-resolver.test.ts:16` — 保留：Spot 引用解析到 Map，未知 ID 不落入 Operation。
  - `gameplay-b-map-run.test.ts:658` — 保留/优先拆分候选：MapRun 主服务合同覆盖广，3409 行含多个领域，应按行为域拆分。
  - `gameplay-b-map-runtime-integration.test.ts:81` — 保留：GameCommands/Runtime 只读投影、敌方行动和提交。
  - `gameplay-b-map-save-resume.test.ts:63` — 保留：MapRun 存档版本、Facts、队伍身份和活动快照恢复。
  - `gameplay-b-map-source-transactions.test.ts:188` — 保留：Ability/Item 跨 PlayerState 与 Run 的原子事务。
  - `gameplay-b-maprun-fact-gated-pools.test.ts:92` — 保留：候选池冻结/实时读取时点、存档与伪造快照边界。
  - `gameplay-b-maprun-status-example.test.ts:55` — 保留：Status 跨节点/商店、退出和失败清理。
  - `gameplay-b-prepared-tag-combo-example.test.ts:37` — 保留：Party 准备标签与自然/玩家行动组合及回执。
  - `gameplay-b-status-damage-reward-example.test.ts:16` — 保留：命中时 Status 快照、回执恢复和回调预算。
  - `gameplay-b-status-expiry-reward-example.test.ts:47` — 保留：自然到期与主动移除/消耗的区别、顺序/预算/击倒。
- **共享 fixture 结论**：
  - `story-test-fixtures.ts:34-60` — 保留并调整：多 Story 集成复用，但 `finishStory` 对 failed/无 token/无计时器/输入失败静默返回；可能吞掉失败，建议让 fixture 明确失败。第 18 行注释描述函数与位置不符。
  - `legacy-story-datapack.ts:13-44` — 保留：历史 FollowUp/tail/card 兼容样例仍有当前文档合同支撑。
  - `gameplay-b-effect-test-fixtures.ts:32-71` — 保留：确定性 Map/Owner fixtures；`draftToken(game, runId)` 未使用 `runId`，是小清理项。
  - `gameplay-b-map-test-fixtures.ts:24-49` — 保留并澄清：fixture 过滤 Action 引用时会删除整个 Encounter，不只是坏引用；当前调用可解释，注释需避免误读。
- **Findings**：P2 — Story `finishStory` helper 对 failed/缺输入静默返回，可能让调用测试误报流程完成（fixture 34–60 行）。P2 — 66 文件内未见 E2 AST 在非 AG-1 Map 上必须拒绝的 Registry 负向断言；实现/合同位于 `src/data-services/validation/gameplay-map-effect-context.ts:178-180` 与 `docs/docs-830/05-domains/gameplay-maprun-effects-and-facts.md:7`。P3 — 两个 Gameplay B 路径内文件实际覆盖 Editor/PackParser 和 Operation Runtime，可迁移以改善职责发现；四个超大 MapRun 文件可按行为组拆分，但不是删除候选。
- **覆盖缺口**：E2→AG-1 负向 Registry 合同测试在此切片内缺失；UI 与 Schema 覆盖属其他切片，需总审计交叉确认。
- **跨模块 / 未确认**：Story 与 Gameplay B 测试大量跨 Runtime、Registry、保存和 Presenter；要与 ST-06/ST-07 的下游覆盖核对，不重复要求 UI 验收。没有目录外证据确认 E2 负向合同是否在其他数据测试中覆盖。

### ST-08 — UI Area Map、Workspace 与 Runtime Editor

- **范围**：37 个测试文件（AreaMap 11、Workspace 13、Runtime Editor 13）；三目录无独立共享 helper；对照只读 View、Controller/Runtime 命令和机制文档。未运行测试、未修改文件。
- **逐文件结论（Area Map）**：
  - `area-map-camera.test.ts:5` — 保留：缩放锚点、边界、拖动阈值与坐标归一化。
  - `area-map-controller.test.ts:28` — 保留：真实 UIController 区域地图开关、地图册、保密/旅行权限及会话清理。
  - `area-map-dom.test.ts:11` — 保留：投影更新保留 Frame/节点/滚动区 DOM 身份。
  - `area-map-session.test.ts:6` — 保留：地图浏览历史、相机恢复、删除后的路由回退。
  - `area-map-workspace.test.ts:10` — 保留：只读 View、转义、旅行动作不写玩家状态。
  - `map-dom-updates.test.ts:13` — 保留：按 key 局部 DOM 更新保留焦点/滚动/卡片与浮层清理。
  - `map-flow-adapter.test.ts:123` — 保留/拆分候选：Run Flow 的 Receipt、效果解释、移动终局与幂等；跨多个 Flow 生命周期组。
  - `map-location-card-render.test.ts:10` — 保留：地点卡 Talklet 宿主与普通 Flow 的身份分离；73–74 行重复同一负向断言。
  - `map-relation-interaction.test.ts:23` — 保留/拆分候选：关系来源、地点选择/目标编辑、键鼠/拖拽、版本变化及清理。
  - `map-relation-presentation.test.ts:29` — 保留：按 scope 呈现关系身份且只改属性不替换节点，与交互测试不重复。
  - `map-shell-layout.test.ts:15` — 保留：结构/CSS 选择器合同；happy-dom 不证明浏览器几何；70–76 行重复 ordinaryGap 断言。
- **逐文件结论（Workspace）**：
  - `content-columns.test.ts:16` — 保留：真实列 owner、阅读位置、刷新与语义列局部更新。
  - `datapack-workspace-order.test.ts:40` — 保留：包排序、依赖冲突诊断及启用 fallback 的纯模型路径。
  - `datapack-workspace-state.test.ts:52` — 保留/按状态所有者拆分候选：Datapack 草稿排序与 Runtime Editor 草稿状态并列于一文件。
  - `inventory-workspace.test.ts:22` — 保留：库存 UI 过滤/排序不改库存，使用动作才写状态。
  - `operation-workspace.test.ts:88` — 保留：真实 Operation Runtime View 到 Workspace renderer 的映射烟测。
  - `selector-graph-navigation.test.ts:16` — 保留：星图路由状态机、过渡锁、取消/卸载、焦点和投影尺寸。
  - `service-workspace.test.ts:20` — 保留：服务工作区包管理、记录转义/空态、冲突和 Host 投影。
  - `topbar-settings-workspace.test.ts:29` — 保留/按入口拆分候选：迷你入口、Init/Area 创建、World Apply、设置导航及 Spot 编辑；多条入口流程较集中。
  - `workspace-columns.test.ts:20` — 保留：多列实例、排序/宽度、绑定去重、token 失效和滚动/焦点恢复。
  - `workspace-frame.test.ts:13` — 保留：Frame 列顺序、Host 元数据、ARIA、Tabs 与 overlay 壳层合同。
  - `workspace-lifecycle.test.ts:13` — 保留：跨工作区根节点身份、局部刷新、事件投影和 AreaHero 故事交付。
  - `workspace-router.test.ts:28` — 保留：互斥路由、runId、单层返回、旧字符串兼容和 Surface token。
  - `workspace-structure.test.ts:59` — 保留：多个 Workspace Frame/CSS selector 结构；happy-dom 结果不等同实际视觉。
- **逐文件结论（Runtime Editor）**：
  - `runtime-editor-codex-details.test.ts:34` — 保留：只读详情、未知字段、引用来源和输入不可变。
  - `runtime-editor-codex-dom-updates.test.ts:5` — 保留：Codex 局部 DOM patch、锚点/节点身份和缺 Pane 恢复。
  - `runtime-editor-codex-integration.test.ts:18` — 保留/未来分组：只读图鉴入口、筛选、详情、关系跳转和局部刷新；不要求编辑态包。
  - `runtime-editor-codex-shell.test.ts:43` — 保留：三栏壳层、ARIA、导航/筛选/空态；CSS 断言非视觉验收。
  - `runtime-editor-definition-descriptor.test.ts:9` — 保留：Policy descriptor、opaque 字段保留和 Apply 能力缺口。
  - `runtime-editor-definition-diagnostics.test.ts:28` — 保留：诊断排序/去重、三方 diff 等纯函数。
  - `runtime-editor-definition.test.ts:36` — 保留：Init/Area/AreaMap 表单和作者草稿；不证明 Apply 到 Registry。
  - `runtime-editor-dsl-safety.test.ts:61` — 保留：未知 DSL fail-closed、深度/数量限制和原样读回。
  - `runtime-editor-form.test.ts:81` — 保留/未来按字段组拆分：Policy 表单、多集合、条件/效果子编辑器与草稿。
  - `runtime-editor-launcher.test.ts:7` — 保留：Launcher 注册/排序/卸载的唯一小型单测。
  - `runtime-editor-pack-export.test.ts:27` — 保留：草稿编译、ZIP 导出/回读、依赖、AreaMap 与无损拒绝。
  - `runtime-editor-payment-actions.test.ts:15` — 保留：嵌套支付编辑与 Apply 失败时草稿保留。
  - `runtime-editor-persistence.test.ts:26` — **调整候选**：草稿/Applied 隔离、防抖和离开清理有效；schemaVersion=999 时删除唯一原始草稿的断言（64–80 行）有数据丢失风险，见 P1。
- **Findings**：P1 — 不支持的 Runtime Editor 草稿版本/损坏 envelope 被 `load()` 判为无效后调用 `removeStoredDraft()`（`src/ui/runtime-editor/persistence.ts:71-77,122-140`）；测试明确把 version 999 后存储键变空当作预期（`runtime-editor-persistence.test.ts:64-80`）。较新版本数据被旧版读取时可能丢失唯一草稿。项目 Story Editor 机制已有“保留原存储、只读浏览、避免覆盖”的数据保护约定（`docs/docs-830/07-tooling/runtime-editor-and-project-checks.md:76`）；建议评估改成保留原文/备份，并修正该断言。
- **P2** — AreaMap Runtime Editor 表单测试只验证字段进入 RuntimeModDraft，当前切片没看到 Apply 按钮写 Registry/失败保留的完整 UI 绑定（`runtime-editor-definition.test.ts:139-159`; 实际 Apply `src/ui/runtime-editor/actions.ts:1180-1201`）；需对照 Data/Engine 事务测试后再定是否补 UI 用例。
- **P2** — `area-map/` 目录混入 MapRun Flow/关系交互测试：`map-flow-adapter.test.ts:123` 使用 `MapRunWorkspaceView`/`MapFlowModel`，`map-relation-interaction.test.ts:23` 使用 Gameplay MapRun 契约；AreaMap 文档明确 MapRun 独立（`docs/docs-830/05-domains/area-map-overview.md:5`）。测试仍有价值，不是重复项；未来目录整理时可与 ST-07 Gameplay B 对齐。
- **P2** — happy-dom CSS 与手动 RAF 只能保护 DOM/状态/规则，不证明真实浏览器几何/动画；将此限制保留在验收记录，不需要删除结构测试。P3：两处重复普通 Flow 属性和 ordinaryGap 断言可精简。
- **覆盖缺口**：Runtime Editor AreaMap Apply UI 成功/失败路径需与 ST-05/ST-06 核对；AreaMap 公共投影、旅行命令和 Registry 形状由其它层负责，不重复要求此 UI 目录承担。
- **跨模块/未确认**：AreaMap Controller 连接 Query、Travel、Story gate、Workspace 路由；MapRun Flow/关系交互与 ST-07 共享 Run View / Receipt。底层完整性需与 Data/Engine SubOutcomes 整合。未运行测试、未做浏览器人工验收。

### ST-03 — Engine Character、Theme 与 Runtime Content

- **范围**：50 个测试：Character 21、Theme 15、Runtime Content 14；审查对应 Engine/Runtime/Registry 服务与领域文档。未运行测试、未修改文件。
- **逐文件结论（Character）**：
  - `affection-system.test.ts:155` — 保留：经验/等级上限、星级锁和跨级剧情门槛；复用 Story fixture。
  - `character-availability.test.ts:70` — 保留：限定池成员并入/排除与加载引用失败。
  - `character-cultivation-query.test.ts:12` — 保留：只读养成查询、拥有状态与突破条件。
  - `character-memory.test.ts:35` — 保留：历史最高与当前值分离、角色统计聚合。
  - `character-persist.test.ts:47` — 保留：角色容器 Global/Init 归属和存档读写。
  - `character-profile.test.ts:14` — 保留：声明、玩家覆写、调用点覆写三层 profile 优先级。
  - `character-progression-def.test.ts:45` — 保留：成长内容引用与 Registry 校验边界。
  - `character-system.test.ts:63` — 保留：原型/Variant 身份和旧协议拒绝。
  - `cultivate-system.test.ts:70` — 保留：经验溢出、突破、扣款、事件和统计。
  - `gacha-service.test.ts:80` — 保留：货币、UP/保底、重复奖励、余额中止和确定 RNG。
  - `passive-pool.test.ts:53` — 保留/拆分候选：池权重/冷却合同有效，但 913 行包含大量 Story/Area delivery 场景。
  - `roster-system.test.ts:76` — 保留：Variant 隔离、首次获得来源和原型统计。
  - `variant-training-content.test.ts:51` — 保留：训练内容来源及构筑参数受信合同。
  - `variant-training-main-runtime.test.ts:39` — 保留：正式训练 Spot 准入、冲突、顺序和存档绑定。
  - `variant-training-runtime.test.ts:18` — 保留：独立训练不污染普通 MapRun/PlayerState，且随 Init 清理。
  - `variant-training-scenario.test.ts:55` — 保留：固定构筑快照、确认/恢复与 JSON 篡改边界。
  - `variant-training-service.test.ts:49` — 保留：训练 token、冻结构筑、Init 变化和恢复拒绝。
  - `variant-training-spot.test.ts:8` — 保留：训练使用有效正式 Spot；训练文档将其列为正式入口。
  - `variant-translation-rules.test.ts:73` — 保留：纯规则阈值、数值溢出、闭合字段/不可变副本。
  - `variant-translation-runtime.test.ts:58` — 保留：当前拥有角色、旧 token 失效及 Init 往返。
  - `variant-translation-service.test.ts:161` — 保留：精确 Variant、授权来源、确认/恢复与零写入。
- **逐文件结论（Theme）**：
  - `avatar-renderer.test.ts:8` — 保留：多色模型头像 SVG 的纯渲染输出。
  - `color-derive.test.ts:26` — 保留/去重候选：主题 token、暗亮背景和对比度；与 `color-system` 有局部纯派生重复。
  - `color-equipment-system.test.ts:81` — 保留：装备解锁/装备状态、幂等、换装与事件。
  - `color-framework.test.ts:23` — 保留：HSL 与 WCAG 对比度/混合的基础算法边界。
  - `color-ingame.test.ts:14` — 保留：Variant 解锁色彩组并产出 tokens 的真实内容链路。
  - `color-system.test.ts:87` — 保留：全局颜色组选择/用户主题状态、实体挂靠；与 `color-derive` 纯函数断言有重复，可只在一个文件保留派生矩阵。
  - `entity-presentation-service.test.ts:50` — 保留：呈现选项默认值、不可用回退、Init 清理。
  - `entity-theme.test.ts:20` — 保留：实体主题槽和全局主题层不混用。
  - `pics.test.ts:20` — 保留：Pic ID/包内图/直连 URL 解析与 Registry 检查。
  - `theme-content-editor-service.test.ts:58` — 保留：作者主题预览/保存/冲突 revision 事务。
  - `theme-runtime.test.ts:17` — 保留/拆分候选：主题层叠/Owner 清理有价值，634 行跨多个层级。
  - `theme-showcase.test.ts:12` — 保留：默认 Theme showcase 是实际示例 Init 内容流程。
  - `theme-tree.test.ts:14` — 保留：ThemeDef 与 ColorGroup 对 tokens 的回退/部分覆盖纯映射。
  - `user-theme-layer-service.test.ts:21` — 保留：按 target/ID 修改主题层，Preview 不落盘。
  - `user-theme-service.test.ts:9` — 保留：能力开关、危险值拒绝、revision 和颜色上限。
- **逐文件结论（Runtime Content）**：
  - `arona-runtime-pack.test.ts:33` — 保留：包记录、启用集、Registry 一致及复制/恢复。
  - `registry.test.ts:233` — 保留/拆分候选：Registry 跨域引用、合并、清理、Tag/Extra 有效；971 行可按定义域拆分。
  - `runtime-content-browser-published-content.test.ts:5` — 保留：默认发布包内容引用可解析。
  - `runtime-content-browser-rules.test.ts:35` — 保留：浏览器规则随 Registry revision 更新及快照清理。
  - `runtime-content-coordinator.test.ts:41` — 保留：Spot 草稿版本、支付字段和 Registry 提交/回滚一致。
  - `runtime-hot-content.test.ts:25` — 保留：热 CRUD、失败 revision、Spot 状态清理与 Affector 生效。
  - `runtime-spot-field-authoring.test.ts:34` — 保留：编辑字段经校验后消费者即时生效。
  - `runtime-world-hot-crud.test.ts:48` — 保留/拆分候选：Init/Area/AreaMap 跨引用原子热改，357 行含多类资源。
  - `shop-service.test.ts:48` — 保留：动态价格、限购、触发器和交易预览不扣款。
  - `spot-content-service.test.ts:22` — 保留：作者快捷动作产出单 mutation 并处理 revision。
  - `spot-functionality.test.ts:30` — 保留：Spot 基础产出与条件功能 Affector/Tag/Enhancement 叠加。
  - `spot-payment.test.ts:89` — 保留：多方案必须明确选择、失败不得部分扣款。
  - `spot-reveal.test.ts:18` — 迁移候选：价值为 Spot reveal tooltip 显示投影，直接调用 UI tooltip 选择器。
  - `spot-tag.test.ts:15` — 保留：动态 Tag 索引、层级/子标签与 Enhancement 联动。
- **Findings**：P2 — `character/affection-system.test.ts:19,292` 与 `passive-pool.test.ts:1,214` 依赖 ST-01 已发现会静默吞掉 Story 失败的 `finishStory` helper；应让 helper 对 failed/缺 token 显式失败。P3 — `passive-pool.test.ts` 混合池抽取与 Story/Area delivery；按场景拆分便于失败定位。P3 — `color-derive.test.ts:26-117` 与 `color-system.test.ts:87-125` 部分重复 `deriveThemeTokens/resolveTheme` 派生断言；可集中纯函数测试，保留状态集成测试。P3 — `runtime-content/spot-reveal.test.ts:7-8` 直接调用 UI tooltip，建议迁 UI。未发现其他高优先级领域缺口。
- **跨模块/未确认**：角色/Theme/Runtime Content 大多有稳定服务或纯函数接口，不需要因测试而额外暴露生产 API。训练 Spot 与 showcase 已由领域文档说明为默认内容/正式入口；未按名称推测成“测试专用”。目录外 UI 点击路径和浏览器视觉未检查。

### ST-04 — Engine Core 与 Def Factory

- **范围**：`tests/engine/core/` 33 个、`def-factory/` 12 个，共 45 个测试；目录内无共享 fixture，部分 Core 测试复用 Base Datapack / Story fixture。只读，未运行测试。
- **逐文件结论（Core）**：
  - `achievement-view.test.ts:59` — 保留：成就视图当前/历史 Init 投影和不可变结果。
  - `affector-engine.test.ts:24` — 保留：Affector Latent/Active 生命周期、重检/卸载/连接。
  - `affector-reconcile.test.ts:74` — 保留：状态替换/存档后的 Affector 重新挂载与一次性/perTick 区分。
  - `affector-text.test.ts:34` — 保留：Effect/Value/Extra/Pack 描述纯格式化。
  - `anonymous-affector-trigger.test.ts:66` — 保留：匿名 ID、内联 Pack 的挂载/去重/恢复。
  - `base-onboarding-spot.test.ts:13` — 保留：默认新手 Spot 奖励领取、重复补偿及跨 Init 保留。
  - `chat-flow-service.test.ts:65` — 保留：聊天演出请求与 Story/UI 事件的透传/清理/顺序；复用会吞失败的 Story helper。
  - `condition-system.test.ts:26` — 保留：AND/OR、短路、Extra、Tag 和地图收录条件求值。
  - `dev-log.test.ts:4` — 保留：诊断日志容量、顺序、verbose 和 JSON 导出。
  - `effect-engine.test.ts:29` — 保留：Effect 经写入端口分发、常见状态写入和顺序。
  - `effect-receipts.test.ts:12` — 保留：同步观察者异常时真实提交前缀/no-op 回执。
  - `engine-contracts.test.ts:32` — 保留：通用 Engine 用最小 Port 组合，验证分层解耦。
  - `event-bus.test.ts:8` — 保留：同步派发、过滤、嵌套 flush 和订阅回收。
  - `event-driven-reactor.test.ts:39` — 保留：依赖索引、轮询降级与 Extra/Tag/Map 依赖重算。
  - `extra.test.ts:37` — 保留：Extra 解析/路径/合并、深度和类型边界。
  - `game-instance.test.ts:35` — 保留/拆分候选：多子系统整合路径有效，1406 行跨领域可按业务模块拆。
  - `game-num-hot-spot.test.ts:32` — 保留：Spot create/replace/delete 对 GameNum 子树缓存失效。
  - `game-num-invalidation.test.ts:121` — 保留：资源/Spot/Extra/Enhancement/Affector 变更的精确依赖失效。
  - `game-num-snapshot.test.ts:116` — 保留但调整说明：层级/聚合/flows/缓存有实际期望值；“双路径对拍”已不再比较两种实现，见 Finding。
  - `game-num.test.ts:23` — 保留：GameNum 生产树基础求值、缓存、Tag 效果和溯源。
  - `map-stage-initialization.test.ts:1` — 迁移候选：测试 `MapRunService` 的 partySetup/AG-1/恢复，不属 generic core。
  - `runtime-operation-observation.test.ts:1` — 保留/归类候选：Operation Runtime Observation 的公开命令边界/防写查询。
  - `schale-office-theme-enhancement.test.ts:11` — 保留：默认主题强化应用/恢复的真实内容链路。
  - `session-service.test.ts:8` — 保留：离线补算与普通停启时间戳语义。
  - `state-mutation-service.test.ts:23` — 保留：资源、AreaMap、Milestone、Effect 写入口及事件/进度联动。
  - `stats.test.ts:15` — 保留：Global/Init/Run 统计归属、收集与存档。
  - `tag-ref.test.ts:4` — 保留：TagRef 与 Entity ID 命名空间区分的轻量纯值合同。
  - `tag-residue.test.ts:6` — 保留：禁用包 Tag override 保留为 residue、清理和隔离。
  - `tag-stats.test.ts:89` — 保留：声明统计/玩家收集统计、父 Tag、重建与条件联动。
  - `tick-system.test.ts:77` — 保留：统一 Tick 结算、跳过未升级 Spot 和恢复结算。
  - `trigger-kind.test.ts:15` — 保留：新增事件 kind 的 Trigger 映射、Variant 过滤和真实培养链。
  - `trigger-system.test.ts:15` — 保留：注册/once/撤销索引、重入和 Tag 变化；复用 Story helper。
  - `value-system.test.ts:27` — 保留：Value 只读求值与 Extra 类型/资源/Spot source；算子由 GameNum 另测。
- **逐文件结论（Def factory）**：
  - `area.test.ts:12` — 保留：Area builder 必填字段、可选字段省略及旅行/揭示声明。
  - `character-drop-curve.test.ts:12` — 保留：Character/DropTable/CultivateCurve builder 的默认字面量/追加/可选项。
  - `color-group.test.ts:12` — 保留：ColorGroup 主色位、主题覆盖和解锁条件。
  - `enhancement.test.ts:12` — 保留：Enhancement 默认/required/affector/Extra builder 字段。
  - `init.test.ts:15` — 保留：Init 字段替换/追加、默认内容等价和可选项。
  - `item.test.ts:12` — 保留：Item 最小值、类别和可选字段构造。
  - `pool-pack.test.ts:15` — 保留：PassivePool 与 AffectorPack 声明构造。
  - `spot.test.ts:18` — 保留：复杂 Spot 功能、支付、地图/训练入口与省略规则。
  - `story-entry.test.ts:16` — 保留：Active/Passive Entry 激活/奖励/冷却/标题字段构造。
  - `story.test.ts:6` — 保留：Story builder 节点模型、结构验证和输入隔离。
  - `trigger.test.ts:16` — 保留：Trigger `once` 默认值、事件 `on` 必填与追加语义。
  - `variant-gacha-chat.test.ts:16` — 保留：Variant/GachaPool featured/pity/关闭条件构造。
- **Findings**：P2 — `game-num-snapshot.test.ts:245-253` 名称/注释称 `childMulMap` 与 `aggregateZone` 双路径对拍，但生产 `zoneValue()` 唯一路径已直接调用 `aggregateZone()`（`game-num-eval.ts:105-117,165-168`）；对拍断言不独立，文件其他直接数值断言仍有效。建议更新描述/删除无效对拍部分。P2 — `chat-flow-service.test.ts:14,160` 与 `trigger-system.test.ts:15,28` 复用 Story `finishStory`，失败会被静默吞掉（由 ST-01 交叉确认）。P3 — 12 个 Def factory 测试未覆盖 `CharaProfileBuilder.build()`、`ColorEquipmentBuilder.build()`、`GearBuilder.tier()/build()`（源码 `chara-profile.ts:36-47`、`color-equipment.ts:27-35`、`gear.ts:35-52`）；目录外覆盖未核实。P3 — `map-stage-initialization`、`runtime-operation-observation` 属于 MapRun/Operation；Def factory 同时包含产品 Builder 与 Engine TriggerBuilder，目录边界不明显。P3 — `game-instance.test.ts` 1406 行、`game-num-snapshot.test.ts` 428 行可在后续按合同拆分，行为有价值。
- **覆盖缺口/跨模块/未确认**：Core 主要机制行为合同充分；Def factory 测试验证对象构造，与 Registry 跨引用校验职责不同。Story helper 问题由 ST-01 确认；MapRun/Operation 两个文件应与 ST-01/ST-02 对齐目录归属。三个未覆盖 builder 是否已有其它层合同测试未核实。

### ST-09 — UI Theme、Controller、Core、Interaction、Startup、Character 与 Commerce

- **范围**：47 个测试文件：Theme 16、Controller 9、Core 8、Interaction 7、Startup 4、Character 1、Commerce 2。没有这些目录内专用共享 helper；聊天测试使用范围外 Story fixture。只读、未运行测试。
- **逐文件结论（Theme，16）**：
  - `background-color.test.ts:20` — 保留：颜色解析、图层合成、缓存/作用域及文字阈值（纯函数）。
  - `background-service.test.ts:18` — 保留：资源回退、过滤、层顺序和 body host 的 DOM 输出。
  - `header-brand-color.test.ts:10` — 保留：真实 Controller 切换后底色投影与 DOM 身份保留。
  - `header-theme-selection.test.ts:7` — 保留：主题菜单默认项与旧控件不再输出；不覆盖选择写入流程。
  - `presentation-service.test.ts:12` — 保留：父子 host、状态/层级、资源转义、装饰和文字模式。
  - `presentation-text-color-css.test.ts:11` — 保留，谨慎维护：静态 CSS/组件源码合同，不证明浏览器 cascade。
  - `selector-label-contrast.test.ts:11` — 保留：真实 DOM 中亮暗标签文字色和焦点更新。
  - `selector-scene-background.test.ts:5` — 保留：背景渐入/快切、解码和卸载取消异步回归。
  - `selector-theme.test.ts:21` — 保留：真实 Init/GlobalEnhancement 主题投影和回退色。
  - `theme-layer-value.test.ts:4` — 保留：渐变 parser/serializer、行编辑、非法值保留。
  - `theme-palette.test.ts:15` — 保留：色板上限、缺色回退、节点优先级、作用域继承。
  - `theme-tree.test.ts:20` — 保留：纯主题树、回退、来源和 CSS 变量清理。
  - `user-theme-editor-decoration.test.ts:7` — 保留：主题装饰字段渲染/继承状态，不测 Controller 写回。
  - `user-theme-editor-layer-order.test.ts:20` — 保留：层级 DOM 顺序及跨系统层排序。
  - `user-theme-editor-overview.test.ts:7` — 保留：摘要信息与编辑分区跳转目标。
  - `user-theme-layer-editor-dialog.test.ts:18` — 保留，未来可按 Manager/表单拆：预览/取消/保存/删/排序/渐变/非法值，829 行。
- **逐文件结论（Controller，9）**：
  - `context.test.ts:12` — 保留：UIContext 主题优先级、宿主回退和区域隔离纯投影。
  - `controller-events.test.ts:9` — 保留：真实 Controller 事件来源到局部刷新范围。
  - `controller-global-enhancement.test.ts:14` — 保留：统一画布、强化购买局部刷新和星图导航。
  - `controller-init-select.test.ts:14` — 保留/调整构造方式：完整 Init 选择流程；部分场景直接设置 `pendingRestart`（测试 40/101/167/301，源码 `controller.ts:326`）。
  - `controller-tab-linkage.test.ts:13` — 保留：Contacts/Story 选择与工作区中栏联动。
  - `controller-theme-cleanup.test.ts:5` — 保留：相邻 CSS 变量删除时不漏删并保留用户变量。
  - `flow-entry.test.ts:37` — 保留：流条目追加/替换、隔离、类型化绑定和转义纯模型。
  - `ui-host-registry.test.ts:5` — 保留并补齐：父链/循环/重复/未知 owner；非法 level/service/state 和重复 service 注册分支缺断言。
  - `ui-update-dispatcher.test.ts:23` — 保留：Surface generation、请求失效/合并和列实例隔离。
- **逐文件结论（Core，8）**：
  - `area-achievement-demo.test.ts:31` — 保留：真实 demo 数据包→Runtime→进度/完成 UI 集成。
  - `chat-notice-order.test.ts:18` — 保留：Runtime 旅行/剧情/延迟奖励输出到 ChatStream 的先后次序。
  - `chat-typing.test.ts:5` — 保留：ChatStream 瞬态 typing 投影与 reset 不推进 Runtime。
  - `condition-presentation.test.ts:7` — 保留：条件结果说明文本、HTML 转义及纯文本 fallback。
  - `inventory-view.test.ts:23` — 保留：库存筛选/排序/数量的纯查询投影。
  - `operation-card-relation.test.ts:6` — 保留/加强候选：关系端口几何/重叠选择；只检查 SVG `M/C` 存在，不验证控制点数值。
  - `variant-training-panel.test.ts:84` — 保留：训练 Panel 通过 Port fake 验证状态流程，与正式 Spot 测试互补。
  - `variant-training-spot-entry.test.ts:11` — 保留：正式 Spot 的真实 Map/Controller 流程、拒绝和恢复。
- **逐文件结论（Interaction，7）**：
  - `card-host.test.ts:18` — 保留：DOM 卡片实例身份、保留属性防伪。
  - `focus.test.ts:5` — 保留：焦点身份恢复；结构变化时不猜测。
  - `foreground-interaction.test.ts:14` — 保留：被动浏览/旅行/故事/待确认动作准入策略纯测试；各入口接线由 Controller tests 承担。
  - `modal.test.ts:12` — 保留：Modal shell、标题转义、dismissable 和 Escape；backdrop click 未覆盖。
  - `popovers.test.ts:7` — 保留：Popover 生命周期、延迟、定位、滚动/缩放和高度约束。
  - `scroll.test.ts:57` — 保留：假 Observer 下贴底、锚点恢复、实例隔离和 FlowScroll 状态模型。
  - `toast.test.ts:5` — 保留：收起/展开 ARIA 和弹窗遮挡边界。
- **逐文件结论（Startup，4）**：
  - `development-datapack-loader.test.ts:8` — 保留：ZIP/目录 loader、身份、失败隔离与进度；注入资源读取边界可测性好。
  - `startup-content.test.ts:5` — 保留：启动声明数格式化；测试语义与“本批声明数”文档一致。
  - `startup-phase.test.ts:4` — 保留：异步启动编排/异常中断纯测试；让出绘制不是浏览器实绘证明。
  - `startup-shell.test.ts:49` — 保留，测试 seam 可考虑调整：入口 HTML 内联脚本做存储/耗时/失败诊断/恢复 DOM 回归；实现耦合源 HTML。
- **逐文件结论（Character / Commerce）**：
  - `character-cultivation.test.ts:8` — 保留：真实 Runtime 的培养/好感上限、事件刷新和突破流程。
  - `shop-modal.test.ts:10` — 保留：Shop Workspace/Controller 购物车、刷新、tooltip 与失败结算 UI 生命周期。
  - `spot-payment-modal.test.ts:10` — 保留并补路径：目前验证 unlock 多方案选中；同一接口 upgrade/取消/禁用选项缺测。
- **Findings**：P2 — `ui-host-registry.test.ts:42-59` 未覆盖 `invalid-level`、`invalid-service`、非法 state、重复 service 注册（源码 `ui-host-registry.ts:48-54,75-84`）。P2 — `spot-payment-modal.test.ts:29-71` 只验证 unlock 传入 paymentOptionId，升级/取消/禁用选项路径未测（`controller-actions-inventory.ts:65-100`）。P2 — 直接设置 Controller `pendingRestart` 构造场景使部分测试依赖内部状态（`controller-init-select.test.ts:40,101,167,301`；`controller.ts:326`），可用公开状态/命令构造。P3 — CSS 字符串/内联 startup shell 测试与实现耦合但守护具体契约；浏览器 cascade/布局/动画仍须独立验收。P3 — `operation-card-relation.test.ts:14-20` 不验证 SVG 曲线控制点几何属性。
- **覆盖缺口/跨模块/未确认**：主题链从色彩纯函数、theme tree、背景/Presentation renderer 到 Context/Controller 有分层测试，不建议合并。Chat notice 与 typing 分别测 Runtime 投递排序和 ChatStream 投影。Shop/Character 测试关注 UI/命令接线，领域写入/原子性仍由 Engine/Data tests 负责。实际浏览器视觉、动画、原生输入及目录外 fixtures 未在本切片核实。

### ST-11 — 原型、工程测试与共享入口

- **范围**：`tests/prototypes/infinite-board.test.ts`；`tests/tooling/archive-docs.test.ts`、`startup-assets.test.ts`、`wiki-link-format.test.ts`、`test-output-summary.test.ts`；`tests/setup.ts`、`vitest.config.ts`、`scripts/run-tests.mjs`、`scripts/test-output-summary.mjs`。
- **逐文件结论**：
  - `tests/prototypes/infinite-board.test.ts`：当前不构成有效回归基线。必要性仅在原型 API 继续开发时成立；现有 `addEdge` 需要 5 个参数且依赖 `elementTypeId` / 端口规则，而测试仍用 3 参数调用并构造缺类型节点（测试 8–15、34–40 行；实现 `prototypes/infinite-board/src/model.ts` 31–48、101–139 行）。`task-0361` 第 183 行也记录该文件为旧 API / fixture 问题。建议列为过时测试，待原型恢复维护时按当前合同重写或暂时隔离；不能将它当作本产品服务目标。
  - `tests/tooling/archive-docs.test.ts`：保留。测试 CLI 的只读检查、归档后读取、UTF-8/二进制完整性、重复拒绝、活动索引 / 越界路径拒绝、损坏包 / 锁 / 临时文件 / 符号链接场景（26–110 行）；直接防护任务数据丢失与路径越权。发现 P2 并发窗口：实现先检查所有源文件与打包快照一致，再逐项删除（`scripts/archive-docs.mjs` 71–75 行），源文件可在该批量检查与对应 `unlinkSync` 之间变化；归档锁仅锁 ZIP，不锁源文件。当前测试没有覆盖该竞争窗口。建议评估是否需要原子化源文件移除或更强同步策略。
  - `tests/tooling/startup-assets.test.ts`：保留。通过真实 Vite middleware 转换验证关键模块 preload 顺序、portal 不携带游戏 preload，以及主入口只装配单个 CSS 模块并保留早/晚样式（17–38 行）；这是启动产物/装配集成测试，不是浏览器性能或视觉验收。覆盖具体配置输出但不验证浏览器请求时序和最终生产 bundle；边界应保持明确。
  - `tests/tooling/wiki-link-format.test.ts`：保留。覆盖整 Vault 重名消歧、anchor/alias、代码/注释/fence 保护、归档目录排除、格式化幂等和 CLI 检查 / 写入 / 歧义失败（28–91 行）；能捕获文档维护工具对链接语义的破坏。当前没有大 Vault 性能场景，按仓库规模不是明显缺口。
  - `tests/tooling/test-output-summary.test.ts`：保留。针对纯解析函数验证通过、失败、跳过、未归类数量及错误/失败文件摘要（4–26 行）；小型工具合同测试。只有 2 个解析样例，未覆盖 ANSI 色码、suite-level import failure、失败截断上限等变体，可视后续 parser 复杂度决定是否补例。
- **共享设施结论**：`vitest.config.ts` 使用递归 include 覆盖 `tests/**/*.test.ts` 与 `tools/**/*.test.ts`，并统一 Node 环境和 `tests/setup.ts`（4–8 行）；当前测试文件组织方式能被完整发现。`tests/setup.ts` 提供轻量 `localStorage` shim，仅在运行环境未提供时安装（1–12 行）；接口狭窄但有意，适合多数 Node 测试，存储状态在单测试文件内不自动清空，调用方应自行隔离。`scripts/run-tests.mjs` 持久化完整日志并生成摘要；文本解析集中于 `test-output-summary.mjs`，专有测试覆盖主要计数路径。未发现为测试暴露的生产接口。
- **Findings**：P2 — 归档源文件批量校验后逐项删除之间存在未锁定竞争窗口，理论上并发更改的源文件可能被删除；证据见 `scripts/archive-docs.mjs` 71–75 行。P2 — 无限棋盘测试与当前原型签名/数据模型不兼容，历史 Task 已记为已知陈旧项；它会增加全量类型/测试噪声，但不属于当前产品模块回归。
- **覆盖缺口**：归档 CLI 缺少源内容在提交后删除前改变的并发竞态测试；摘要 parser 目前没有覆盖 suite-level failure 与截断上限。其他测试能覆盖各工具最重要的纯逻辑/边界合同；未发现需要单纯为覆盖率扩张的缺口。
- **跨模块问题**：ST-11 只有 runner / tooling，与其他切片的生产模块无直接交叉；全量测试的 Worker 崩溃根因超出这些测试的独立证据，留待主 Agent结合失败报告统一分析。
- **未确认**：没有运行测试；关于 archive 竞争窗口的可触发性及平台级 rename/unlink 语义未做实机并发验证；原型项目是否还计划维护不明确，故仅建议标记过时，不建议本 Task 删除。

### ST-07 — UI Story、Gameplay B 与组件

- **范围**：`tests/ui/story/`、`gameplay-b/`、`components/` 共 47 个测试及 2 个目录内 helper；逐文件审查了 Renderer、Controller、ReadModel、Story/Map Runtime 命令边界。未运行测试、未修改文件。
- **逐文件结论**：
  - `components/chat-image.test.ts:11` — 保留：头像/图片 URL 投影、缺图降级。
  - `components/chat-text.test.ts:13` — 保留：聊天条目统一渲染、overlay/template、稳定键、转义；DOM class 断言有维护成本。
  - `components/contacts.test.ts:87` — 保留，未来可拆：联系人/会话/羁绊/gacha 多个 RenderModel；`U-06` 是预留接口而非产品验收。
  - `components/entity-presentation.test.ts:44` — 保留：锁定信息遮罩与呈现选项；未测点击后 Controller 命令。
  - `components/global-enhancement-select.test.ts:24` — 保留：强化状态投影；不覆盖点击购买/撤回路径。
  - `components/init-select.test.ts:19` — 保留：排序、TILT 格式、伪装/未揭示回退。
  - `components/story-gate.test.ts:12` — 保留：标题、ARIA、转义与横幅渲染；交互另由 UI Story gate 测。
  - `components/tooltip.test.ts:58` — 保留：Stat/Condition/Spot/Map 说明投影；不执行条件求值，边界明确。
  - `gameplay-b-basic-map-p0-p3.test.ts:200` — 保留：真实 Runtime 的 P0–P3 MapRun 用户流程。
  - `gameplay-b-effect-workspace.test.ts:74` — 保留：只读 Workspace View 与真实回执边界。
  - `gameplay-b-map-vertical-slice.test.ts:108` — 保留：默认 Datapack 至 Map UI/战斗/胜利的端到端式验收；固定 RNG 不宣称分布覆盖。
  - `gameplay-b-map-workspace.test.ts:27` — 保留，未来按行为组拆分：卡牌/命令/目标/回合/终局/焦点滚动，近 2100 行但涵盖多项实际状态合同。
  - `gameplay-b-quick-test-console.test.ts:15` — 保留：命令 allowlist、拒绝危险输入及无部分写入。
  - `contacts-story-workspace.test.ts:9` — 保留：Workspace Host/owner、刷新与返回路由状态。
  - `controller-story-movement-lock.test.ts:20` — 保留：故事播放锁定跨结束阶段及无中间解锁闪烁。
  - `story-consecutive-choice.test.ts:9` — 保留：连续 Choice 历史、旧 token 拒绝和不自动推进。
  - `story-continuation.test.ts:41` — 保留：父子故事/Area 邀请、存档与场景恢复。
  - `story-editor-authoring.test.ts:16` — 保留：作者字段编辑、验证/应用/重载和结构化值。
  - `story-editor-entry-activation.test.ts:12` — 保留：Entry activation 分支与非法变化不污染草稿。
  - `story-editor-entry-migration.test.ts:22` — 保留：草稿备份、旧字段转换、幂等和不可迁移输入保全。
  - `story-editor-flag-catalog.test.ts:23` — 保留：跨 Entry/Transfer Flag 来源、作用域与拒绝边界。
  - `story-editor-flag-navi.test.ts:13` — 保留：Flag 搜索、回填、焦点/滚动和来源导航。
  - `story-editor-identity.test.ts:11` — 保留：Mod 选择、ID 归属、Pack 原子保存/失败回滚。
  - `story-editor-inline-text.test.ts:12` — 保留：正文原位编辑、选区/IME 合成事件、粘贴/撤销；happy-dom 不代表真实浏览器 IME。
  - `story-editor-inspector-tabs.test.ts:13` — 保留：Inspector 身份/滚动记忆和 Flag 投放拒绝边界。
  - `story-editor-model.test.ts:24` — 保留：纯 Model 的 ID、分支、复制、恢复、存储失败保留。
  - `story-editor-node-clipboard.test.ts:14` — 保留：不可变节点快照、复制/跨 Story 粘贴、菜单失效关闭。
  - `story-editor-properties-acceptance.test.ts:22` — 保留：作者草稿分支、原始值恢复及删除清理。
  - `story-editor-properties-model.test.ts:24` — 保留：属性 Model 的条件缓存、稳定行身份与投影。
  - `story-editor-properties.test.ts:19` — 保留，未来按字段组拆分：大量属性分支/诊断/定位/提交校验；900 行级别但职责仍是属性编辑面板。
  - `story-editor-reference-navi.test.ts:14` — 保留：引用回填与来源浏览分离、字段失效保护。
  - `story-editor-relations-model.test.ts:16` — 保留：调用关系发现、循环/缺失目标及源草稿不变。
  - `story-editor-required-flag-dropdown.test.ts:16` — 保留：Flag 候选过滤、作用域和刷新后重验。
  - `story-editor-scene.test.ts:11` — 保留：起始场景/移动目标/空 Story 渲染。
  - `story-editor-theme.test.ts:14` — 保留：编辑器主题状态与游戏状态隔离。
  - `story-editor-workspace.test.ts:19` — 保留，未来按生命周期拆分：路由/保存/发布/巨量节点与 CSS 装配混在一文件；happy-dom computed style 不等于浏览器视觉验收。
  - `story-ending-navigation.test.ts:47` — 保留：普通/子故事/Area continuation/重读结束后的路由转换。
  - `story-gate.test.ts:19` — 保留：确认/取消/遮罩/重读/横幅的 Controller 行为；与纯渲染测试不重复。
  - `story-history-resume.test.ts:15` — 保留：恢复后消息不重复、Runtime 权威和不自动推进。
  - `story-node-card-routing.test.ts:22` — 保留：卡片确认携带等待 token，拒绝旧来源。
  - `story-node-delivery.test.ts:5` — 保留：ChatStream 的 owner/epoch/prune/上限投影。
  - `story-node-input.test.ts:15` — 保留：Choice/card/click token 门控与隔离预览。
  - `story-node-notice-routing.test.ts:13` — 保留：移动/奖励通知的 owner、保存前 flush、恢复去重。
  - `story-node-routing.test.ts:7` — 保留：背景/overlay owner 投影与过期 run 清理。
  - `story-performance.test.ts:8` — 保留：样式文本转义、定位仅投影一次和输入按钮约束。
  - `story-space-history.test.ts:34` — 保留：Story 场景/地点历史、续播、存档与失败路径。
  - `story-speaker.test.ts:17` — 保留：角色身份/临时名/头像跨编辑器和持久化隔离。
- **目录 helper**：`story-editor-test-helpers.ts:5-16` 保留并标注其注入式 Pack fixture 不覆盖真实 PackManager（身份测试有真实 Runtime 路径）；`story-playback-fixtures.ts:5-17` 为 ChatStream 提供最小只读 Reader，保留。
- **Findings**：P2 — `gameplay-b-map-workspace.test.ts`（约 2100 行）、`story-editor-properties.test.ts`、`story-editor-workspace.test.ts` 均跨多个行为组；建议后续按职责拆分，不删行为。P2 — 自动化主要验证 DOM/合成事件，真实浏览器视觉、原生 IME/剪贴板/拖拽不由这些测试证明。P3 — `story-editor-test-helpers` 注入 Pack stub，需与真实 identity integration test 配对理解。P3 — 某些测试绑定 class/data hooks，改 DOM 时需区分语义接口和包装结构。
- **覆盖缺口**：若需证明 selector/gacha/entity presentation 的完整点击命令路径，需与 ST-08/ST-09 对齐；此切片只覆盖渲染和局部 Controller；真实浏览器行为未作为自动化证据。
- **跨模块/未确认**：Story/Map UI 多处使用真实 Runtime，应与 ST-01/ST-06 互补而非要求重复；未查目录外测试。用户目标/授权不由 test 名或 `P0–P3` 标签单独证明。

### ST-05 — Data Datapack、Persistence 与 Area Map

- **范围**：22 个测试，分别为 Datapack 13、Persistence 2、Area Map 7；审查直接 Data Services 合同和相关文档。只读，未运行测试。
- **逐文件结论**：
  - `datapack/addition-test-pack.test.ts:25` — 保留：真实扩展包解析、多表/跨包引用；手动 FILES 清单新增内容时需同步。
  - `datapack/archive-writer.test.ts:11` — 保留：ZIP 稳定输出、二进制内容和路径安全边界。
  - `datapack/base-datapack-folder-export.test.ts:15` — 保留：完整导出/解析/资源字节/重复导出；遗漏删除字段后复用目录的用例，见 P2。
  - `datapack/bundled-base-pack.test.ts:8` — 保留：运行时 Base bundle 资源路径和标准包解析。
  - `datapack/fragment-parser.test.ts:4` — 保留：fragment 合并、单例、extras、列表和路径错误；通用循环不需逐表重复。
  - `datapack/pack-editing-state.test.ts:19` — 保留：编辑态副本身份及导出状态，与 Pane 选择测试职责相邻但不同。
  - `datapack/pack-manager.test.ts:14` — 保留：默认包选择、来源对账、依赖、Runtime 回滚与快照恢复；缺持久化写失败恢复断言。
  - `datapack/pack-manifest.test.ts:4` — 保留：Manifest 形状/默认值；缺色彩字段合法/非法分支。
  - `datapack/pack-pane-selection.test.ts:35` — 保留：Pane 选择投影、Apply 失败回滚和导出快照；持久化失败路径见 P2。
  - `datapack/pack-parser.test.ts:14` — 保留：Manifest、图片、ZIP/fragment 入口；缺多 fragment metadata 冲突测试。
  - `datapack/pack-source.test.ts:5` — 保留：ZipPackSource 条目筛选与字节读取；Folder source 由导出/bundle 路径覆盖。
  - `datapack/pack-storage.test.ts:14` — 保留：JSON/IndexedDB 保存事务、备份与中止；嵌套损坏快照缺口见 P1。
  - `datapack/zip-loader.test.ts:48` — 保留：无 Manifest 低层 ZIP loader，与高层 `parsePack()` 契约不同。
  - `persistence/storage-adapter.test.ts:4` — 保留但价值偏低：主要验证薄适配器委托；Map adapter 项接近类型 smoke test。
  - `persistence/storage-save-version.test.ts:5` — 保留：存档版本门槛、旧数据不改写和 SaveSystem 导入导出。
  - `area-map/area-achievement-demo.test.ts:45` — 保留：示例包区域访问、里程碑、奖励、恢复与 ZIP 应用；业务模拟手工合并 fragment，未让同场景通过 ZIP parser 走完全管线。
  - `area-map/area-map-authoring.test.ts:9` — 保留：Area `navigationMapId` 作者字段和 Registry 引用；未直接测试 AreaMap policy 本身。
  - `area-map/area-map-demo.test.ts:4` — 保留：生产 `parsePack()` 加载演示 JSON 和 Registry 引用。
  - `area-map/area-map-pack.test.ts:7` — 保留：ZIP fragment、循环地图引用、显式空表/缺省区别。
  - `area-map/area-map-registry.test.ts:11` — 保留：AreaMap shape、跨包引用、所有权和批量回滚；回滚只测新建回空，缺 replace 旧定义恢复。
  - `area-map/default-area-maps.test.ts:6` — 保留：Base source 与发布包一致、默认图入口和拓扑投影。
  - `area-map/spot-map-entry-label.test.ts:28` — 保留但需改名或补 UI 断言：文件名说“内置标签”，当前断言只保证作者字段缺省（57 行）；fallback 文案在 UI `map-entry.ts:28`。
- **Findings**：P1 — 嵌套损坏的 pack snapshot 可通过浅层 `isSnapshot` 检查，迁移时读 `pack.datapack` 抛错（`pack-storage.ts:5,52`）；现有测试只测缺顶层字段（`pack-storage.test.ts:52`）。P2 — PackManager 先改内存/Runtime 再持久化，存储抛错可能留下一致性差异（`pack-manager.ts:447,472`；存储接口 `pack-storage.ts:43`）；测试只模拟 Runtime reload 失败。P2 — 高层包解析只比较首个合并 metadata 与 Manifest，后续 fragment 的冲突值可能被忽略（`fragment-parser.ts:83,114`; `pack-parser.ts:67`），现有测试只有单 fragment 冲突。P2 — Base 导出在复用目录时只删根 `content.json`，不清旧 `content/*.json`（`scripts/base-datapack-export.mjs:23,35,45`），当前测试只相同内容重复导出（`base-datapack-folder-export.test.ts:46`）。
- **覆盖缺口**：Manifest `color` 校验分支、PackManager 持久化失败回滚、IndexedDB 成功写/清除直接用例、多 fragment metadata 冲突、AreaMap replace 后 rollback、移除字段后复用 Base 输出目录。`area-map-authoring.test.ts` 未覆盖 AreaMap policy；真实旅行/收录/揭示应由其他层负责，不在此切片要求重复。
- **跨模块/未确认**：Area Map 行为需与 Engine/UI 切片整合判断；zip-loader 内的 `DATAPACK_LIST_FIELDS` 与 barrel export 字段清单存在定义关系需主 Agent核对（当前运行委托 `parseFragment()`，未证明产生行为影响）。未检查其他层是否已覆盖上述业务路径。

### ST-02 — Engine Area Map、Operation、Progression 与 World

- **范围**：40 个测试文件：Area Map 5、Operation 15、Progression 6、World 14；目录内无共享 fixture 文件。只读审查，未运行测试。
- **逐文件结论（Area Map）**：
  - `area-map-commands.test.ts:10` — 保留：地图打开与收录是不同合同，覆盖自动/显式收录、重开和存档。
  - `area-map-fast-travel.test.ts:12` — 保留：地图导航不替代真实路线，覆盖 transit/visited/mapDirect/入口门槛/交通源移除。
  - `area-map-query.test.ts:28` — 保留：只读投影的隐藏信息脱敏、知识记忆和动作许可边界。
  - `area-map-runtime.test.ts:5` — 保留：批量准入失败不覆盖运行态地图、位置和 generation。
  - `area-map-travel.test.ts:19` — 保留：旅行预览与提交分离，覆盖 mapDirect、实时入口条件和进入效果。
- **逐文件结论（Operation）**：
  - `operation-card-candidate-resolver.test.ts:101` — 保留：候选池、过滤、Strategy 与独立随机游标。
  - `operation-combination-resolver.test.ts:95` — 保留：Combination 稳定排序、Actor 占用、Wait/Intent 排除。
  - `operation-intervention-preview.test.ts:157` — 保留：干预草稿受手牌/目标/费用/计划版本约束且失败无写入。
  - `operation-observation.test.ts:22` — 保留：诊断摘要有界且安全；序号/容量是有意固定的存储合同。
  - `operation-participant-admission.test.ts:99` — 保留：Run 前检查 Actor/Profile/资源/目标引用；768 行围绕准入合同。
  - `operation-plan-preparation.test.ts:154` — 保留：PreparedBeat 纯规划、费用共享、目标回退和输入快照不变。
  - `operation-player-scene-deck.test.ts:42` — 保留：Run 内 SceneCard 身份、抽弃牌生命周期。
  - `operation-resolution-planner.test.ts:195` — 保留：结算先规划，覆盖效果聚合、干预、组合/技能与不变性。
  - `operation-runtime-service.test.ts:237` — 保留/拆分候选：定义校验、Run/Scene/恢复边界有效但集中在 1737 行，建议按职责拆分。
  - `operation-scene-actions.test.ts:149` — 保留：SceneAction/SceneCard 批次费用、Skip、恢复和目标范围。
  - `operation-scene-character-actions.test.ts:185` — 保留：Scene Character Hand 与 Player 操作费用/自动规划次序。
  - `operation-tactical-rng.test.ts:88` — 保留：随机游标重放、拒绝抽样和顺序；持久随机算法的固定向量有合同价值。
  - `operation-target-selection.test.ts:38` — 保留：Actor 关系、存活/位置、过滤器和目标偏好。
  - `operation-view-projector.test.ts:81` — 保留：Scene/Hand/Offer 只读投影不得变成状态来源。
  - `student-operation-runtime.test.ts:101` — 保留：Profile 定义与 Run 快照、坏初始化原子拒绝。
- **逐文件结论（Progression）**：
  - `enhancement-pyroxene-cheat.test.ts:12` — 调整候选：测试 tick 机制有价值，但“测试专用”免费强化进入 Base 默认内容（详见 P1）；建议本地测试定义替代产品内容。
  - `enhancement-reveal.test.ts:19` — 迁移候选：验证可见性 tooltip 投影，调用 UI 组件，应归 UI 测试。
  - `enhancement-scope.test.ts:14` — 保留：Init 强化购买/移除/重购的作用域和 View。
  - `gear-system.test.ts:73` — 保留：装备槽、升级成本/上限、效果替换与成长状态链。
  - `global-enhancement.test.ts:18` — 保留：全局强化购买/移除/不可逆及 Lobby→Init 生命周期。
  - `loot-system.test.ts:27` — 调整候选：单次抽取/条件/数量有测；`rollTable()` 表级条件、保底、重复抽取与权重多候选路径缺测（P2）。
- **逐文件结论（World）**：
  - `entity-reveal.test.ts:19` — 迁移候选：验收真实解锁后的 tooltip 显示，直接调用 UI 选择器，偏 UI 层。
  - `information-reveal-adapter.test.ts:17` — 保留：Watch 注册后重验条件并安全提交/撤回，含重入与注册失败。
  - `information-reveal-domain.test.ts:22` — 保留：七类信息目标 Watch 派生、门槛、循环和作用域。
  - `information-reveal-hot-content.test.ts:29` — 保留：热内容 Watch 刷新及 apply rollback/stale submit。
  - `information-reveal-lifecycle.test.ts:17` — 保留：Watch 随 Init/Area、热定义和离开 Init 重建。
  - `information-reveal-progress.test.ts:7` — 保留：持久事实与运行 Watch 分离，状态写入目标验证。
  - `information-reveal-save-rebuild.test.ts:13` — 保留：读档/reset 后重建 Watch 且无旧注册。
  - `init-global-lifecycle.test.ts:12` — 保留：Init 快照中 Global 状态与本地对象隔离，真实游标重建集成。
  - `milestone-adapter.test.ts:30` — 保留：Milestone 精确来源、Init 统计和不支持条件叶子的 Adapter/domain 边界。
  - `milestone-runtime.test.ts:20` — 保留：完成事实与 Listener 副作用、重入、一次性回执和失败不重试。
  - `per-init-fields.test.ts:41` — 保留：字段归属与 InitSnapshot 键集合同步，固定全集有防漏价值。
  - `reveal.test.ts:19` — 保留：Engine existence/unlock 门槛分离、OR/默认过滤。
  - `visibility-hot-spot.test.ts:57` — 保留：热 CRUD 后反向索引与缓存重算。
  - `world-tilt.test.ts:4` — 保留：版本解析、拒绝格式和 15 位比较精度。
- **Findings**：P1 — `enhancement-pyroxene-cheat.test.ts:28-38` 声称测试专用的免费 +2500/tick 强化由 `src/arona-clicker/content/progression/enhancements.ts:26` 定义并进入 `baseDatapackSource`（`.../base-datapack-source.ts:81-93`）；发布 Base JSON 含同一条目，且 `default-datapack.ts:2-5` 从发布 JSON 装载。需按数据安全/产品完整性风险处理，不把它归咎于测试随机虚构。P2 — `loot-system.test.ts:27-103` 未覆盖源码 `loot-system.ts:25-32` 的 `rollTable()` 表级 gate/guaranteed drop/多次抽取聚合，且无多合法候选权重测试。P3 — `progression/enhancement-reveal.test.ts:19` 与 `world/entity-reveal.test.ts:19` 直接验证 Tooltip UI，迁至 UI 子目录候选；测试价值有效。P3 — `operation-runtime-service.test.ts` 1737 行定义校验与运行期混合，可按生命周期拆分。
- **覆盖缺口**：Area Map Registry shape/跨包合同是否覆盖留待 ST-05；Achievement View 投影是否由其他测试承担待 ST-09/总审查核实。Loot table 的多候选权重、表级 gate 和保底是本切片明确缺口。
- **跨模块/未确认**：`world/init-global-lifecycle.test.ts` 复用 Story fixture，是预期的真实游标集成；Data/UI Story 覆盖需与 ST-01、ST-05、ST-07 对齐。默认包内“测试专用”强化的运行时可达 UI 面需再核当前组件路径，子 Agent已确认其进入 default pack，但本切片未评价普通玩家是否可见。

### ST-06 — Data Runtime Content、Operation、Story 与 Gameplay B

- **范围**：27 个测试文件；审查 Registry、Definition/Authoring、Story projection/identity 和 Gameplay B 数据合同。另审 Story authoring fixture `tests/data/story/story-node-authoring.fixtures.ts:4`；由 authoring 与 acceptance 两个测试共用声明样例，未发现重复/陈旧样例；其注释明确不模拟播放。未运行测试、未修改文件。
- **逐文件结论（Runtime Content，11）**：
  - `shop-registry.test.ts:28` — 保留：Shop 装载、结构化提案/缺少引用/重复 ID 与 Section 校验。
  - `runtime-content-reference-rules.test.ts:13` — 保留：typed reference 路径、联合类型、候选集合、循环与 accessor 安全。
  - `runtime-content-operation-references.test.ts:14` — 保留：Operation 全局/局部引用、池/Profile/Card Pool 与安全遍历；与 browser 组合缺口另列。
  - `runtime-content-browser.test.ts:53` — 保留：loaded-only 目录、引用诊断、克隆隔离、revision cache 和 getter/cycle 安全。
  - `registry-spot-mutation.test.ts:47` — 保留：Spot create/replace/delete/suspend/resume、所有权、receipt 回滚及覆盖索引清理。
  - `entity-presentation.test.ts:26` — 保留：默认/局部主题、条件门控和完整内容加载后的引用校验。
  - `definition-resolution.test.ts:34` — 保留：来源层 shadow/suspend/resume/delete/fallback 和 Definition Delta。
  - `definition-reference-resolution.test.ts:44` — 保留：required/optional 对 resolved/suspended/missing 及 symbol source 的区分。
  - `definition-diagnostics.test.ts:35` — 保留：optional warning、required/suspended error 和身份去重。
  - `content-policy.test.ts:84` — 保留但需更新静态键清单：覆盖授权、字段消费者/失效、输入校验、Def 构建/Registry；`areaMaps` 漏列造成断言冲突，见 F1。
  - `content-policy-world-module.test.ts:9` — 保留：World Policy 稳定投影、能力与源策略不变。
- **逐文件结论（Operation）**：
  - `spot-operation-entry.test.ts:6` — 保留：Spot 统一 Operation 入口的缺失/未知关卡引用拒绝与局部失败不写入。
- **逐文件结论（Story，10）**：
  - `story-definition-acceptance.test.ts:11` — 保留：内置 Story 全量 detached projection 往返和字典/零值/深条件边界。
  - `story-continuation-authoring.test.ts:14` — 保留：continuation gate、scene movement 和隐藏控制字段拒绝；不覆盖跨文档 Transfer 图。
  - `story-choice-content-migration.test.ts:4` — 保留：内置 Choice marks/消费者、持久分支门控与顶层 Transfer 合同。
  - `migrate-story-content.test.ts:7` — 保留：离线旧 Choice/click/work/state/presentation 迁移及不支持输入显式报告；缺输出语法解析，见 F4。
  - `story-entry-activation.test.ts:10` — 保留：Entry 激活配置、identity 路径和 catalog 投影。
  - `story-definition-projection.test.ts:11` — 保留：完整重建、空占位/错误保留、目录引用、循环/深层 Extra 等安全投影。
  - `story-identity.test.ts:20` — 保留：包内身份引用/guard、冲突拒绝、缓存身份转换与持久化 reload。
  - `story-node-authoring.test.ts:7` — 保留：声明式节点样例结构校验；不模拟播放是明确边界。
  - `story-performance.test.ts:6` — 保留：性能字段投影、Click 模板限制、目标有效性与 Avatar 引用。
  - `story-node-structure.test.ts:51` — 保留：单文档节点/阶段/Choice 结构与输入不变；跨文档 mark 所有权缺口见 F2。
- **逐文件结论（Gameplay B，5）**：
  - `gameplay-b-effect-example.test.ts:32` — 保留：可选 bundle、真实 CardRef、顺序活动与 MapRun 的集成样例，不宣称 Effect 穷举。
  - `gameplay-b-effect-normalization.test.ts:9` — 保留：Action→Effect Program 归一化、顺序/分支/来源元数据、限制和旧数组拒绝。
  - `gameplay-b-effect-registry.test.ts:57` — 保留：AG-1/E1 上下文、Status/资源/Pool/Fact/loopTarget 和自定义 resolver 复核。
  - `gameplay-b-effect-syntax.test.ts:11` — 保留：闭合 AST、字段/操作拒绝、深度/数量上限和 hostile tree。
  - `gameplay-b-map-registry.test.ts:400` — 保留：Map/MapRun gate、引用/合并、Pool、Enemy/Action Registry 校验主干。
- **Findings**：F1（测试 fixture 漂移）`content-policy.test.ts:20-54,93-101` 的手写 `DATAPACK_CONTENT_KEYS` 漏 `areaMaps`，而 `AREA_MAP_CONTENT_POLICY` 已注册且进入 `CONTENT_POLICIES`（`src/data-services/authoring/content-policies.ts:253-279,449-455`），故当前“unknown 必须为空”断言与已注册政策集合冲突；建议从 Datapack/政策来源派生键清单。F2（P2）本组未见 Registry 级跨 Story Transfer 可达重复 Choice-mark owner 测试：单文档结构在 `story-node-structure.test.ts:106` 有测，图级冲突由 `story-continuations.ts:8,13` → `registry-validate.ts:1491` 执行；建议补多文档 Registry 场景。F3（P2）Operation 引用收集器单测与 Browser 单测分离，但 Browser 汇总结果没有 Operation 引用集成断言（`runtime-content-browser.ts:478`、Operation 收集入口 `runtime-content-operation-references.ts:339`）；建议补小型组合用例。F4（P3）迁移器只对生成文本字符串作断言（`migrate-story-content.test.ts:8,186`），未解析/编译语法；建议为代表性输出加语法 parse 检查。
- **覆盖缺口/边界**：上述 Story 多文档图级 mark 冲突和 Browser+Operation 引用组合是本组确定缺口；区域/Story 播放执行不由本组多数 authoring/projection 测试承担。AreaMap Policy 缺少直接政策测试见 ST-05，不能因 Editor 可编辑而误以为 Registry/authoring 合同已全覆盖。
- **跨模块/未确认**：Story 主要测作者投影/Identity、Gameplay B 按语法→归一化→Registry→一个 Runtime 样例分层，不能把静态校验用例当执行覆盖。Operation 引用解析需要与 browser query 合并。迁移输出是否在其他构建流程被语法解析未确认；本结论只覆盖指定 27 个文件。

### ST-10 — 独立 Datapack Editor

- **范围**：`tools/datapack-editor/model/`、`schema/`、`ui/`、`validate/` 全部 10 个测试；直接审查 Editor Model、Schema 合并、校验、ZIP I/O 与导航接口。未修改代码、未运行测试。
- **逐文件结论**：
  - `model/editor-model.test.ts:35` — 保留：Model 装载/导出、CRUD、undo/redo、订阅和嵌套写入；缺空 record 表写入用例。
  - `schema/datapack.schema.test.ts:10` — 保留：Divider、tagged reference、TagRef 合同。
  - `schema/engine-schema.sync.test.ts:19` — 保留：引擎类型→生成 Schema→Editor `TABLES` 同步主合同。
  - `schema/tags-dump.test.ts:4` — 删除候选或改为断言：仅打印 tags Schema。
  - `schema/tags-field-kinds.test.ts:5` — 调整候选：字段 kind / 校验结果主要只打印，缺可失败断言。
  - `schema/tags-model.test.ts:6` — 合并/收窄候选：部分重复 Model 的空表新增；校验只检查不抛错，不检查 issues。
  - `ui/io.test.ts:29` — 保留：ZIP/PackParser 往返六张 Operation 表、manifest 和嵌套未知 JSON；不覆盖浏览器 JSON / 剪贴板等入口。
  - `ui/navi.test.ts:30` — 保留：导航候选、文本、解析、订阅事件等纯接口，DOM 接线由边界外负责。
  - `validate/extra.test.ts:12` — 保留并修订：覆盖 Extra 递归形状、类型、ID 和资源特例，但当前编辑器规则与 Engine 契约冲突（F1、F2）。
  - `validate/operation-authoring.test.ts:152` — 保留：六张 Operation 表、嵌套引用、局部关系、PackParser 往返；“real/actual PB24”命名对应本地合成 `makePack()`（L27），建议准确标示。
- **Findings**：P1 — `validate/extra.ts:15,39-40` 接受 `num` / `null` 并拒绝 Engine `ExtraValue` 合法的 `float`；相应用例 `extra.test.ts:13-24` 固化了不一致行为。引擎合同见 `src/engine/contracts/extra.ts:5-11`。P1 — 空 record 写入丢失：`EditorModel.recordOf()` 在表未装载时返回临时 `{}`（`editor-model.ts:128-130`），`setRecordKey()` 修改后不写回 `data`（L233-236）；UI 新增 record key 调用该入口（`ui/main.ts:244-246`）。现有测试只用已有 `extras` 数据（`editor-model.test.ts:146-153`）。P2 — Editor Extra 缺 Engine 深度 32 限制及 dict key 非空/不得含 `/` 的验证（`src/engine/extra/extra-core.ts:9,30`；`extra-validate.ts:13-16,38-43`；Editor `extra.ts:76,85`）。P2 — Operation local validator 的 Actor/Participant 对应、known Fact、held Item、重复 Purchase Fact 等独立分支缺直接负例（`validate/index.ts:419-487`）。P3 — tags dump/field-kind 测试日志没有实质断言，`tags-model` 部分重复 `editor-model` 默认行行为（上述逐文件结论）。
- **覆盖缺口 / 源码接口**：除以上问题外，ZIP helper 未覆盖 JSON/剪贴板/文件选择器取消及失败；导航纯接口易测但没有 `main.ts` 切表/高亮的 DOM 集成。Model/校验均有可直接调用的边界，未发现为测试而扩展不必要公开 API。测试没有共同导入的独立 fixture；`operation-authoring.test.ts` 的 `makePack()` 是本文件合成数据。空字符串是否为必填错误需作者合同证据，当前不判缺陷。

## FinalOutline

### 完整性与总体评价

清点基线为 396 个 `.test.ts`，由 ST-01…ST-11 按目录互斥分配；各切片均回收逐文件结论，且共享 Vitest 配置、setup、runner 和 parser 由 ST-11 检视。没有执行测试，因此本审计评价的是测试设计与源码接口，不是当前测试通过状态。总体上 Engine/Data 的多数测试验证真实业务合同、状态转换、存档/恢复、失败原子性与跨层协作；UI 测试普遍分层验证投影、DOM 和 Controller 行为；编辑器 Schema/Model/Data I/O 也有清楚边界。大量测试有实质价值，不能以重复关键词、文件大小或“测试是预期目标”直接判冗余。

主要薄弱点是少量**可执行合同与当前源码/内容事实不一致**、少数无断言/日志型测试，以及少量高风险失败/组合路径未被直接验证。生产代码本身通常提供了可测入口（纯函数、服务、注入资源/存储、Registry、Controller/DOM host）；本轮没有证据支持广泛增设 public API 或整体重构。测试读取私有状态的具体例子，应按局部测试 seam 处理，而不是推广成普遍源码可测试性缺陷。

### 按优先级排序的总 Findings

1. **P1 — 默认产品内容含测试专用免费强化（可能的业务合同 / 内容发布风险）**：`tests/engine/progression/enhancement-pyroxene-cheat.test.ts:28-38` 所用条目在 `src/arona-clicker/content/progression/enhancements.ts:26` 定义、由 `base-datapack-source.ts:81-93` 纳入 Base，发布 JSON `src/arona-clicker/content/base-pack/content.json:8406-8418` 也有该项。`EnhancementService.purchaseEnhancement()` 允许空 price（`src/arona-clicker/services/progression/enhancement-service.ts:41-69`）。必须由产品内容所有者确认是否预期；若只是测试设施，应改为测试本地数据。普通 UI 的实际可发现性尚未证实。
2. **P1 — Runtime Editor 对未知版本草稿执行删除**：`src/ui/runtime-editor/persistence.ts:71-77,122-140` 在无效 / 不支持版本时移除草稿，`tests/ui/runtime-editor/runtime-editor-persistence.test.ts:64-80` 将 schemaVersion 999 清除作为预期；但文档要求保留原存储并允许只读浏览（`docs/docs-830/07-tooling/runtime-editor-and-project-checks.md:76`）。这是明确的数据保全合同冲突，建议先确认现行产品语义，再将源码和测试统一到保留未知数据的策略。
3. **P1 — Editor Extra 与 Engine Extra 类型不一致；另有 P2 深度/key 校验缺口**：Editor 把 `num` / `null` 当合法并拒绝 `float`，与 `src/engine/contracts/extra.ts:5-11` 不一致；Engine 另有深度与 dict key 约束未由 Editor 镜像。依据 ST-10 `extra.ts` 和 `extra.test.ts`。建议以共享合同为准校准 validator 和测试，不以测试中自定义标签反推产品契约。
4. **P1 — Editor 空 record 表新增键不会持久化到 Model**：`tools/datapack-editor/model/editor-model.ts:128-130,233-236` 与 UI 调用 `tools/datapack-editor/ui/main.ts:244-246`；测试只用已有记录表。建议先补行为回归并修 Model 写路径，确保新增→导出→撤销/重做合同。
5. **P2 — Story 测试 helper 会把播放失败伪装成完成**：`tests/engine/story/story-test-fixtures.ts:44-58` 的 `finishStory` 对失败 / 缺 token 等情况静默返回，多个 Engine/Core 测试复用（ST-01/03/04 交叉发现）。建议改为显式失败或返回可断言结果；这是测试可信度问题，不是 Story Runtime 测试覆盖数量不足。
6. **P2 — Data 包存储、管理器及分片解析的高风险负例不足**：浅层快照校验可能让 `packs:[null]` 进入迁移并崩溃（`src/data-services/datapack/pack-storage.ts:5,52`）；PackManager 持久化失败路径可能留下内存/Runtime 不一致（`pack-manager.ts:447,472`）；多 fragment metadata 只以合并首段信息作判断（`fragment-parser.ts:83,114`、`pack-parser.ts:67`）。测试应分别验证恶意/损坏快照拒绝、保存失败原子性和多分片冲突，不把相关三个发现合并成一个实现改动。
7. **P2 — Registry / Browser 组合合同缺口**：缺 Story 多文档 Transfer 可达的重复 Choice-mark owner 场景（`src/data-services/story/story-continuations.ts:8,13`、`registry-validate.ts:1491`）；Operation 引用收集器与 Runtime Content Browser 分别有单测，但浏览器聚合组合没有断言（`runtime-content-browser.ts:478`、`runtime-content-operation-references.ts:339`）。建议小型组合测试覆盖真正跨边界合同。
8. **P2 — Engine Loot `rollTable()` 行为未完整验证**：`tests/engine/core/loot-system.test.ts:27-103` 缺表级 gate、保底、多次 roll 聚合和多候选权重，而源码 `src/arona-clicker/services/economy/loot-system.ts:25-32` 支持这些路径。建议按玩家可见掉落合同补代表性场景。
9. **P2 — Base Datapack 导出复用目录会保留旧分片**：`scripts/base-datapack-export.mjs:23,35,45` 只清理根文件，现有测试重复相同输入（`tests/data/datapack/base-datapack-folder-export.test.ts:46`）。验证输出目录从多分片转为单/不同分片时没有陈旧文件。
10. **P2 — 文档归档有批次检查与删除之间的竞争窗口**：`scripts/archive-docs.mjs:71-75` 先比较所有源文件与归档快照，再逐项删除；源文件在检查后变化仍可能被移除。`tests/tooling/archive-docs.test.ts` 覆盖损坏包与路径安全但不覆盖此窗口。按文档任务数据安全要求决定是否需要锁定/原子提交策略及回归验证。
11. **P2 — UI 若干重要命令/校验分支未直接断言**：UIHost registry 的非法 level/service/state 与重复注册（`ui-host-registry.ts:48-54,75-84`）、Spot payment 的 upgrade/cancel/disabled options（`controller-actions-inventory.ts:65-100`）缺测试；属于有限补例，不意味着需增加 UI 框架或浏览器自动化。
12. **P2 — Editor Operation validator 的独立局部规则缺负例**：Actor/Participant、known Fact、held Item 和重复 Purchase Fact（`tools/datapack-editor/validate/index.ts:419-487`）。宜跟随 Editor Extra 合同修正一起补齐负例。
13. **P2 — 静态测试期望列表漂移**：`tests/data/runtime-content/content-policy.test.ts:20-54,93-101` 手写 key 集合遗漏已注册的 `areaMaps`（`src/data-services/authoring/content-policies.ts:253-279,449-455`）。建议从政策注册表派生 keys，避免 fixture 与系统事实失步。
14. **P2 — 测试名称/接口与源码当前行为脱节**：`tests/engine/core/game-num-snapshot.test.ts:245-253` 声称双路径对拍，但当前源码只有一条 `aggregateZone` 路径（`game-num-eval.ts:105-117,165-168`）；`tests/prototypes/infinite-board.test.ts` 调用旧签名，且 Task 0361 已记录旧 API / fixture 类型错误。前者保留有效数值合同、删除无效对拍部分；后者若原型未恢复，标记隔离/过时，不当作现产品目标。

### 建议行动与后续任务切分

- **先裁定业务合同（高收益、低改动前置）**：确认免费测试强化是否能进入默认内容；确认未知 Runtime Editor 草稿的保全政策；确认 Extra 的 `num/null/float` 是否应严格遵循 Engine `ExtraValue`。这三项会决定源码与测试的正确方向，不能只按现有断言自动改成一致。
- **数据安全 / 原子性回归（独立高优先任务）**：覆盖未知版本草稿保留、PackManager 持久化失败、分片解析冲突、Base 导出陈旧文件和归档源竞争窗口；先明确对应合同，再各自做最小实现修正与回归测试。
- **Datapack Editor 合同修正**：修空 record key 持久化；与 Engine 对齐 Extra 类型/深度/key 规则；补 Operation local validator 缺失负例；把 tags 打印型测试改为断言并合并重复行为。依赖 Extra 合同裁定。
- **可靠性与重点缺口补测**：Story helper 显式报告播放失败；补 Loot table、Story Registry graph 与 Browser+Operation 组合；补 UIHost 与 Spot payment 分支。可拆成 Engine、Data、UI 三个小任务。
- **低优先整理**：重标/迁移 `enhancement-reveal`、`entity-reveal` 等目录职责错位测试；梳理超大测试文件时按行为合同保留断言；删除纯日志用例。测试文件大小或目录错位本身不构成删除理由。
- **源码可测试性结论**：优先复用已有公开领域服务、纯 Model、资源/存储注入和 DOM host。对直接设置私有 `pendingRestart` 的 UI 场景，可先判断真实用户路径是否可简洁构造；若不能，再设计窄而语义化的测试边界，不直接导出内部状态。

### 限制与未确认

本审计是静态代码与测试阅读，没有执行测试、浏览器验收、性能测量或并发复现实验；因此不报告当前运行通过率，也不证明竞态可稳定触发。没有对 396 个测试进行全仓逐行语法级统计，逐文件结论来自互斥目录切片及其报告。默认强化的普通玩家可见性、原型是否继续维护、空字符串作者语义及部分缺口是否由其他层覆盖，仍需按具体后续任务核实。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `AGENTS.md`、`ai/guide/task-workflow.md`、`ai/guide/templates/execution-task.md` | 项目分流、Task 字段与分派 / 收尾规范 | 已核对 |
| `ai/guide/conventions/testing.md`、`vitest.config.ts`、`package.json` | 测试层组织、发现规则与命令 | 已核对 |
| `tests/`、`tools/datapack-editor/` | 396 个测试文件及共享设施 | 已按互斥目录切片审查，逐文件结论见 SubOutcomes |
| 各测试直接引用的 `src/`、`scripts/`、`prototypes/` | 对应生产行为与源码可测试接口 | 已按各切片直接关联范围审查；目录外覆盖只在明确标注时确认 |

## 事实与决定

| 问题 / 决定 | 已核实事实及依据 | 待解决问题 |
| --- | --- | --- |
| Task 的记录方式 | 项目要求 Task 记录于 `ai/plan/task-<编号>-<主题>.md`，并登记到 `ai/plan/00-index.md`；依据 `ai/guide/task-workflow.md` | 无 |
| 当前测试范围 | 目录扫描得到 201 engine、49 data、131 ui、10 独立 Datapack Editor、5 prototype / tooling，总计 396 个 `.test.ts` | 启动时复核清单是否有变化 |
| 审查限制 | 本 Task 授权只读调查和总结，不授权修改代码或架构 | 无 |

## 验证与结果

| 检查对象与方式 / 命令 | 实际结果 | 失败后的排查与处理 / 未执行原因 |
| --- | --- | --- |
| Task / SubTask 计划与测试目录计数 | 11 个互斥 SubTask 覆盖 396 个测试文件；11 个 SubOutcomes 已回收 | 完整性按目录计数及 SubTask 路径边界核对；未运行测试 |

- 当前结果：ST-01 至 ST-11 的 SubOutcomes 和 FinalOutline 已完成。未运行测试；本 Task 为只读审计。

## 剩余工作与交接

- 后续如实施建议，应另建实施 Task 并先裁定报告中标注的业务合同问题。
- 本 Task 未修改生产代码或测试；文档验证按项目 `check:docs` 流程执行。
