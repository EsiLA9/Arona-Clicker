# Task 0358：Choice 收敛为选项与选择记录服务

状态：完成 — 主 Agent 与三个 Luna MAX 已交付实现、独立审查和整合验收；相关 71 文件 / 681 项回归通过（2026-11-06）。

## 目标与范围

- 目标：Choice 只承担选项展示、出现条件、接收一次选择和记录选择结果；移除整组共同动作及单个选项的通用动作执行能力。编辑者不再为一次选择维护 set/remove、动作类型、任意值和动作顺序。
- 用户已确认：删除 `sharedActions`；选项不再内嵌业务效果或 Transfer；保留选项文案、出现条件、选择标记及关联后续节点；保留将后续 StoryNode 拖到选项上建立绑定的服务；成功选择后由运行时固定替换本组选项的旧选择标记。
- 范围：Choice 合同、作者投影与校验、播放器、相关只读投影、游戏内 Story 编辑器、Flag 查询与绑定、内置内容、Schema 生成及对应测试和机制说明。
- 非目标：不重构所有 Click 类型，不删除 Operation 的普通 localFlag 动作，不改变普通 `requiresFlag` 的存在判断，不为 Choice 增加另一套独立选择历史或持久状态，不增加业务动作插件系统，不改无关的 StoryEntry、主题与演出机制。
- 本 Task 取代 Task 0341 的 Choice `result.actions` / `sharedActions` 实现方案及 Task 0357 中“继续接受旧 Choice 通用结果”的对应边界；其他已完成能力继续保留。旧 Task 是历史依据，不按旧要求把通用动作重新引入 Choice。

## 需求来源与已核实事实

用户反馈 `p6-choice` 顶部显示两段“局部标记（按顺序）→ 行为类型 → 局部标记操作 → 名称 → 执行影响 → 上移下移删除”，含义完全不清晰；随后要求“移除 Choice 的该功能，只保留选项系列服务”，并确认以下实施方向。

| 问题 | 当前事实与依据 | 本任务决定 |
| --- | --- | --- |
| 顶部两个局部标记是什么 | `src/arona-clicker/content/story/story-schale-main.ts` 中 `p6-choice.sharedActions` 移除 `schale-welcome-p6-option1/2`；成功选择时先清除，再运行选中 option 的 set | 删除作者共同动作合同与编辑区域；选择替换成为固定运行规则，不再保留隐藏的通用动作列表 |
| 选项仍能执行什么 | `StoryChoiceOption.result` 使用通用 `StoryNodeResult`，可装任意 StoryAction 与 transfer；新作者 UI 已限制 localFlag，但正式合同与 Runtime 仍支持旧格式 | Choice 专用合同不再使用通用结果；业务效果、移动、演出与转移由后续独立节点承担；Button 等其他消费者保留自身合同 |
| 如何影响后文 | 当前 option localFlag set 与后续节点 `requiresFlag` 配对，编辑器支持拖放、反查、解除与级联改名 | 保留这套编辑服务与局部标记消费者；把提供方改为声明式选择标记 |
| 清理发生在何时 | `StoryNodePlayer.submit` 先复核候选条件，再按 shared/option 动作顺序提交 | 仅成功接纳本次选择时替换本组标记；显示、查询、悬停、失败提交、重复旧 token 不改表 |
| condition 是否隐藏选项 | 当前 `condition` 产生可选候选；`renderChoiceCard` 保留不可用项并显示 LOCKED | 新模型明确表达出现条件，不满足时隐藏；不得把旧“禁用”条件无说明地当成语义完全相同的字段改名 |
| 局部条件读取哪张表 | 普通 Condition 的 flag 目标读取持久 flags；`requiresFlag` 读取 Entry 局部 Map，false/0/null 也视为存在 | 明确区分两类条件来源；不得暗改普通 flag 的含义。具体复用或扩展方式由执行者核实并记录 |

`p6-choice` 的预期关系：

| 选项 | 选择标记 | 后续节点 |
| --- | --- | --- |
| 从整理办公室开始 | `schale-welcome-p6-option1` | `p6-option1-op` 写持久 `welcome_choice = office` |
| 先查看生产设备 | `schale-welcome-p6-option2` | `p6-option2-op` 写持久 `welcome_choice = production` |

这两个选项目前均无条件，应继续同时出现；公共 `p7-body` 和后续奖励保持原顺序与效果。

## 实施边界与建议

### 合同与运行时

1. 保留现有 `click / choice` 分类。选项保留稳定 `id`、`text`，用 Choice 专用字段声明出现条件和选择标记；推荐类似 `showWhen` 与 `marks: readonly string[]`，最终命名、类型和空值规则由执行者结合现有合同确定并记录。多个标记用于兼容现有一个选项关联多个独立 pair 的服务，不引入任意值或清理动作配置。
2. 删除 Choice 的 `sharedActions` 与 option 通用 `result` 使用点；共享的 `StoryNodeResult` 若仍由 Button 使用，应保留。不要通过隐藏 UI、保留任意 actions 执行器的方式宣称完成职责收敛。
3. 成功提交选择时，清除本组所有已声明选择标记，再为选中项的标记写入 `true`。只操作本组声明的名称；不得清除 Entry 全表或其他 Choice 的标记。校验应防止不同选择组产生会互相清理的归属冲突，同时允许普通后续节点读取这些标记。
4. 标记仍使用既有 Entry 局部 Map，沿用 goto/insert、父子显式回传、重播及存档生命周期；不增加玩家持久 flags 写入。选项可没有选择标记，此时只完成一次选择并继续。
5. 显示条件由运行时权威计算，提交时再次验证候选与 token。复用现有条件计算能力；若支持局部标记条件，必须显式表达来源并保持基础层依赖边界。
6. 空选项配置、全部选项隐藏、等待期间条件变化后的零候选需要有明确行为，不能卡死或由 UI 查询偷偷推进。先核对现有等待点与表现流程，记录规则并测试；建议到达时零候选跳过该选择节点，重要说明由前置 Talklet 承担。该建议尚未形成完整生命周期设计，不把等待期间的自动推进当作已裁定事实。
7. 单次提交应在任何清理前完成可验证的检查；失败保持 token 和局部表，成功重复提交不再写入。后续 Operation 独立预检与提交，不声称整条分支原子回滚。

### 编辑器

- 移除整组“局部标记（按顺序）”以及 Choice 内的通用动作控件、任意值、动作排序和重复影响说明。
- 单个选项围绕文案、出现条件、选择标记、关联后续节点组织；避免同时展开每个选项全部递归表单。复用现有选项预览、Flag Navi 与条件编辑能力，先提供简短 DOM / 更新边界草图再施工。
- 保留拖入后续节点、一个选项关联多个节点、复用读取条件、解除、级联改名、节点反查、稳定选项身份与复制粘贴；生成名沿用当前约定，不重写既有手工 ID。
- 绑定仍应拒绝跨草稿、过期选项、已有不同 `requiresFlag`、较早节点和确定不可达目标；重复绑定幂等。解除某个 pair 不得破坏同项其他 pair 或其他选择组。
- 更新 Flag 表、局部标记 Navi、合法候选过滤、关系组查询、关系扫描和作者工具，使其识别新声明式提供方，保留 Entry 导入询问与作用域隔离。
- 普通编辑只改草稿；沿用 keyed DOM、区域刷新和现有拖放协议，保留焦点、光标与滚动，不触发播放或隐式保存。

### 内容与旧数据

- 核对并转换内置标准模式：选项 set true → 选择标记声明；与这些标记对应的共同 remove → 固定替换规则；原节点 ID、选项 ID、目标 `requiresFlag` 与分支顺序保持稳定。
- 旧 sharedActions / result 中若有任意值、其他标记维护、业务动作或转移，不能直接丢字段、猜测归属或宣称机械转换无损。逐类报告路径及处理结果；业务效果与跳转通过独立节点表达，并验证预检时机和分支顺序。
- 外部包、本地草稿的旧结构须明确诊断；禁止投影时静默丢弃后保存覆盖。若提供可转换的标准模式，应是显式、可核对的内容转换，不新增通用旧合同执行兼容层。
- 作者内容转换与活动会话快照分开处理。运行中定义改变沿用内容指纹/游标失配与 Entry 重启策略；按架构约定不编写旧活动存档迁移层。
- 内置包导出与 Schema 通过现有生成流程同步；不手工编辑生成 Schema，不修改 dist、web-dist、src/ui/dist 或 node_modules。

## 当前进度

- [x] 用户确认职责收敛与保留选项绑定的方向。
- [x] 核对 `p6-choice`、Choice 合同、属性渲染与播放器提交入口，建立交接边界。
- [x] 执行者认领并核对调用方；专用合同、条件及零候选规则见下方实施设计。
- [x] 修改合同、投影、校验、Runtime 与相关只读输出；核心定向 232 项及扩大 engine/data/Schema 345 项通过。
- [x] 修改编辑器、Flag 服务和内置内容，完成 Schema / 基础包同步。
- [x] 完成回归、类型与静态检查并记录既有类型错误；更新机制说明、风格记录和本 Task。
- 当前结果：实现与独立审查完成；engine/data/Schema、全部 Story UI 和完整 workspace 分组回归通过。未做浏览器实操，未修改旧活动存档兼容策略。
- 下一步：按工作流归档本 Task；无待实施代码或待修复的本任务失败。

## 实施设计与分工

- 合同统一为 option `id/text/showWhen?/requiresFlag?/marks?`；`showWhen` 复用现有持久条件组，`requiresFlag` 显式检查 Entry 局部标记存在，两者同时满足才出现。普通 Condition flag 不改变含义。
- 零候选：到达时跳过 Choice 并清除本组 marks，避免旧路由残留；等待期间条件变化为零时显示既有继续按钮，由显式提交空选项跳过并清理。查询不推进；有候选时空提交仍拒绝。
- `/root/choice_core`（Luna MAX）：合同、作者投影、校验、Runtime、engine / 核心 data 测试。
- `/root/choice_editor`（Luna MAX）：Story 编辑器、Flag 查询 / Navi / 拖放 / 草稿与复制、对应 UI 测试和风格记录。
- `/root/choice_content`（Luna MAX）：内置 Story、迁移工具与其余 data / 非编辑器 UI fixtures。
- 主 Agent：运行态 Choice 卡过滤（编辑预览与完成记录保持各自语义）、Schema 与基包生成、文档、整合验证和审查；所有 Agent 共享目录，按文件归属施工，不覆盖彼此修改。

## 相关文件与资料

文件表用于定位，不是修改白名单；执行者需要查全调用方、fixtures、导出与校验入口。

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-node.ts`、`src/data-services/contracts/story-node-actions.ts` | Choice / 通用结果 / localFlag 合同边界 | 已修改 Choice 合同；通用动作合同保留 |
| `src/data-services/authoring/story-definition-projection.ts`、`src/data-services/validation/story-node-structure.ts` | 作者投影、旧字段诊断与结构校验 | 已修改并通过 data 回归；旧字段明确诊断 |
| `src/data-services/authoring/story-authoring.ts` | Entry 条件借助 Choice 的内部校验调用方 | 已将临时 condition 改为 showWhen，作者事务 / 试玩回归通过 |
| `src/data-services/validation/story-continuations.ts`、`src/data-services/registry/runtime-content-reference-rules.ts` | 结果与动作扫描、引用路径 | 已修改；Transfer 可达与父子回传冲突回归通过 |
| `src/arona-clicker/services/story/story-node-player.ts`、`story-node-session.ts`（同目录） | 接纳选择、局部表、候选与页面投影 | Player 已修改并通过回归；Session 复用原标签投影 |
| `src/arona-clicker/services/story/story-service.ts`、`src/arona-clicker/contracts/runtime/story-node-playback.ts` | 提交守卫与 Runtime 视图 | 服务已修改并通过回归；沿用现有输入与存档接口 |
| `src/ui/story-editor/property-fields.ts`、`property-model.ts`、`model.ts`、`controller.ts`（同目录） | 删除旧控件、绑定事务、行与分支缓存 | 属性 / 模型 / Controller 已适配；通用属性缓存机制保留 |
| `src/ui/story-editor/flag-catalog.ts`、`flag-catalog-view.ts`、`flag-fields.ts`、`local-flag-navi.ts`、`required-flag-dropdown.ts`、`flag-table-binding.ts`（同目录） | 提供方扫描、Navi、Flag 表与局部条件 | 目录扫描已适配；Navi / 下拉 / Flag 表沿用同一数据来源 |
| `src/ui/story-editor/relations-model.ts`、`persistence.ts`、`node-clipboard.ts`、`view.ts`（同目录） | 关系、草稿恢复、复制与预览绑定 | view 已修改；通用引用 / 草稿 / 复制机制核对保留，冲突显式报告 |
| `src/ui/components/story/story.ts` | 运行态候选隐藏、编辑态预览及选项绑定宿主 | 已修改；隐藏候选保留原索引，预览和完成记录独立处理，UI 回归通过 |
| `src/arona-clicker/content/story/story-schale-main.ts`、其他内置 Story 与 `src/arona-clicker/content/base-pack/content.json` | p6 样例和内置 Choice 转换 / 导出 | 9 个内置 Choice 已转换；Runtime JSON 已由脚本同步，分片导出通过 |
| `scripts/migrate-story-content.mjs`、`tests/data/migrate-story-content.test.ts` | 离线旧内容迁移工具的合同输出 | 已改为 marks 门控独立节点；条件语义变化 / 不支持动作保留原文并报告，回归通过 |
| `scripts/gen-engine-schema.mjs`、`tools/datapack-editor/schema/editor-extras.ts`、`tools/datapack-editor/schema/engine-schema.sync.test.ts` | 生成协议、字段语义与同步测试 | 已修改生成器 / 语义与同步测试；生成协议已同步并通过 |
| `tests/data/story-choice-content-migration.test.ts`、`story-definition-projection.test.ts`、`story-node-structure.test.ts`（同目录） | 内容转换与边界诊断 | 已更新并通过扩大 data 回归 |
| `tests/engine/story-choice-deferred-operations.test.ts`、`story-run-flags.test.ts`、`story-node-player.result.test.ts`、`story-node-player.snapshot.test.ts`（同目录） | 重入、隔离、结果执行、存档恢复与重播 | 已更新并通过扩大 engine 回归 |
| `tests/ui/story-editor-workspace.test.ts`、`story-editor-properties.test.ts`、`story-editor-model.test.ts`、`story-editor-flag-catalog.test.ts`、`story-editor-required-flag-dropdown.test.ts`、`story-editor-node-clipboard.test.ts`、`story-consecutive-choice.test.ts`（同目录） | 选项编辑与拖放、Flag 查询、复制及连续输入 | 相关 UI 30 文件 / 225 项、workspace 完整 39 项均通过 |
| [[story-and-effects]]、[[runtime-editor-and-project-checks]]、`ui-style/patterns.md` | 当前机制与 UI 约定 | 机制说明与风格记录已更新；文档检查通过 |
| [[ai/guide/conventions/architecture-discipline]]、[[ai/guide/conventions/testing]]、[[ai/guide/context-packs/ui-presentation]]、[[ai/guide/frontend-design-project-overlay]] | 状态、验证、UI 与刷新边界 | 已按影响读取并执行；UI 沿用现有视觉约定与局部刷新 |

## 验收条件

- [ ] `p6-choice` 不再显示整组局部标记动作区；各选项也没有通用行为类型、set/remove、任意值、动作排序或内嵌 Transfer 控件。
- [ ] 正式 Choice 合同、作者投影和 Runtime 不再把 `sharedActions` 或通用 option result 当成正常可执行 Choice 功能；Button、独立 Operation 和 Transfer 原能力不受损。
- [ ] p6 两个选项均正常出现；选择办公室只触发 office 分支，选择设备只触发 production 分支；公共后文与奖励保留。
- [ ] 同一 Entry 内再次经过同一 Choice，旧分支失效；其他 Choice、普通局部标记与持久 flags 不被清理；无标记选项也能正常继续。
- [ ] 条件不满足的选项隐藏，伪造或过期提交被拒绝；零候选与等待期条件变化均有明确、经测试的行为，不从 UI 查询推进。
- [ ] 失败提交不改局部表、不消费有效 token；成功提交与读档恢复不重复执行选择替换、Operation 或奖励；重播保持局部路由且不写持久效果。
- [ ] 拖放、重复绑定、多个 pair、解除、级联改名、冲突拒绝、复制粘贴、Flag 表、Navi 和相关 Entry 作用域全部适配新提供方。
- [ ] 旧标准内容转换保留关联；不支持的旧动作按具体路径诊断；加载 / 投影 / 保存不静默丢数据，不新增旧活动存档迁移层。
- [ ] 生成 Schema、补充语义、内置导出和 fixtures 与合同一致；文档解释新职责和活动会话失配边界。
- [ ] 编辑过程保留无关 DOM、焦点与滚动；没有隐式播放、世界状态修改或包保存。

## 验证与结果

所有测试通过 `npm test -- <相关测试路径或过滤>` 运行，完整输出归入 `.test-artifacts/latest.log`；不要把日志放在仓库根。优先按上表运行直接相关的行为回归，再按新增失败和未覆盖风险扩大范围；不得复用历史通过数量作为本次结果。

实现后还需运行 Schema 同步测试、`npx tsc --noEmit --pretty false`、`npm run check:architecture`、`npm run check:docs`、`git diff --check`，根据构建影响运行相关构建。既有错误与本任务引入的问题分别记录；浏览器自动验收可按用户此前许可跳过，不能声称已做视觉验收。

| 检查对象 | 实际结果 | 说明 |
| --- | --- | --- |
| 本次交接文档与索引 | 通过 | `npm run check:docs` 扫描 123 个 Markdown，0 错误；`git diff --check` 通过 |
| Choice 实现与行为回归 | 通过 | 去重合计 71 文件 / 681 项：engine/data/Schema 39 文件 345 项，额外 GameInstance 72 项，Story UI 30 文件 225 项，workspace 39 项；以下定向结果与之有重叠，不重复累计 |
| 类型 / Schema / 架构 / 构建 | 本任务通过；全局类型有既有错误 | 最终类型检查只剩 tests/prototypes/infinite-board.test.ts 的 8 项既有错误，完整输出 .test-artifacts/0358-types.log；Schema / 架构 / 文档检查及最终构建通过 |
| engine/data/Schema 扩大回归 | 通过 | 单 worker，39 文件 / 345 项；完整输出 `.test-artifacts/0358-engine-data-all.log` |
| 核心首次审查与回归 | 通过 | 17 文件 / 232 项，`.test-artifacts/0358-core.log`；修复作者条件内部调用方、迁移后的守卫与演出顺序测试 |
| Story UI 扩大回归 | 通过 | 30 文件 / 225 项，`.test-artifacts/0358-ui-all.log` |
| workspace 全部回归 | 通过 | 15 + 12 + 12 = 39 项，三个互不重叠标题组；`.test-artifacts/0358-workspace-1.log`、`0358-workspace-2.log`、`0358-workspace-3.log` |
| 编辑器重点与独立审查 | 通过 | 5 文件 66 项与支持 4 文件 23 项（均包含在扩大 UI 中）；修复过期解绑、共用标记说明、休眠缓存、普通 JSON 误扫和 Overlay 回传名漏扫，独立审查无剩余直接问题 |
| 浏览器实操 | 未执行 | 按用户此前许可跳过，不声称完成视觉验收 |
| Runtime UI / Schema 初轮 | 通过 | 2 文件 / 32 项；隐藏候选保留原索引、预览与历史、专用合同生成协议 |
| 生产构建与基础包 | 通过 | 构建输出 `.test-artifacts/0358-build`；Runtime bundle 与 46 个 Story 源一致，分片导出 `.test-artifacts/0358-base-pack`；最终构建复核通过（34.21 秒） |

## 剩余工作与交接

- 执行者：主 Agent 与上述三个 Luna MAX 子 Agent；最终整合验收由主 Agent 负责。
- 工作区基线：建档前 `git status --short` 无输出；施工开始时仅有本 Task 和活动索引的未提交建档改动。各 Agent 按文件归属施工，未覆盖无关修改，未创建提交。
- 字段与零候选规则已按实施设计落地；通用动作仅保留在 Button / Operation。独立 Transfer 的分支守卫发生在到达时，失败后显式重启，未恢复旧 Choice 原子事务。
- 收尾由 Luna MAX 对 63 个直接路径作 GALHCG changed 只读复核：25 content_changed、38 unreferenced_path；owner 分页续读至 complete，44 个 Evidence 检查完整。52 条保存的 Evidence 因旧 mtime/size 基线不一致标 stale；metadata_changed / time_baseline_missing 均为 0。未刷新、改图或写 freshness；未把无映射视为实现不存在。完整报告 `.test-artifacts/0358-map-review.json`。
- 机制与风格记录已维护；本 Task 完成后按 [[ai/guide/task-workflow]] 归档，活动索引保留完成摘要。
