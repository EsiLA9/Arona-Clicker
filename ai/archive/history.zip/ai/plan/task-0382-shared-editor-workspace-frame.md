# Task：提取 Story 共用栏位框架并修复世界编辑器布局

状态：已完成

## 当前依据与交付

Story／StoryEntry 在 `src/ui/story-editor/view.ts` 的 `baseColumn` 中统一了栏位轨道、panel surface、标题栏和滚动规则。同文件的 `createStoryEditorFrame` 已让这两种实体共享工作框架。世界编辑器调用了相同的外壳和通用 Frame，但 `renderWorldBrowser` 自己拼栏位，没接入 Editor 的轨道变量、面板样式和标题组件。共享外壳仍暴露固定的三种视图与两条分隔线。

真实浏览器复现：世界双栏的实际轨道约 616／616 px，左分隔线在 297 px。选「三栏」仍只有两块面板，却出现右分隔线。选「专注正文」时左栏被移出 Frame，中栏仍置于网格第 2 列，出现约 300 px 的隐式空轨道。

交付为一套从 Story／StoryEntry 现行装配提取的共享 Editor 栏位契约。Story、StoryEntry 和世界编辑器均通过它组装。世界首版提供目录与只读摘要，支持双栏和专注两个视图。现有世界实例、目录链接和 Story 切换保留。右栏内容与表单是后续功能。

## 1. 从 Story／StoryEntry 提取共享栏位构造

- 在 `src/ui/workspace/` 新建 `editor-workspace-frame.ts`，或在现有 `editor-workspace.ts` 放同一组小函数。提供 `createEditorWorkspaceColumn(ctx, spec)` 及共享 Frame 装配入口。调用方提供 `slot`、栏 key、hostId、owner、bindingKey、themeScope、标题与内容，必要时提供 titlebar 的返回或尾部控件、滚动模式、overlay、footer 和后续绑定。共享构造设置 Editor 轨道变量、`surface: 'panel'`、栏位基础样式，并委托 `renderWorkspaceTitlebar`、`renderWorkspaceFrame`。经典模式的宽度 fallback 以 Story 现在的布局为准。
- 由同一栏位配置派生视图和轨道。左／中／右对应目录、主内容、详情；有右栏才提供 `three`，有左栏才提供 `browse`，`focus` 显示中栏。经典模式显示已声明栏位。临时目录和试播沿用 Story 现有三栏策略。先迁移 Story 的常规 Story 和 Entry 分支，原 `baseColumn` 可保留为薄的领域适配，只负责 Story 的 host、绑定身份与特殊类名。核对试播 Frame 独立构造，保留它的列义和滚动。
- 在 `src/ui/css/story-editor.css` 找到共用的外壳、panel 几何、栏缝与轨道规则，迁到共用 Editor 样式或明确改为共享语义选择器。外壳宽度、标题样式和间距两边吃同一份规则。复用原主题变量，正文、试播、故事目录等业务样式仍留在 Story 域。若拆 CSS，核对顶部两个入口和 rail 直接切换时共用样式先于渲染就绪，且只装载一次。

## 2. 让视图、网格和分隔线使用同一份配置

- 在 `src/ui/workspace/editor-workspace.ts` 扩展 `EditorWorkspaceChrome` 或传入共享布局投影，使 `editorWorkspaceViewAttributes`、工具栏下拉菜单、分隔线和拖宽判断使用同一有效视图。按现有结构保留可复用 DOM。无对应栏位的分隔线不出现。拖宽用当前可见边栏数计算上限，写入的 `--editor-left-width`／`--editor-right-width` 必须被同一实际轨道消费。
- 用 Story 的在位折叠策略保持已挂载栏位，以零宽显式轨道容纳隐藏栏位。专注时中栏占满可用区。若共享实现改为只保留可见列，就同步把中栏放到现有轨道，不能保留固定第二列定位。选择一种策略贯穿渲染和增量更新。Story 的 keyed 更新路径继续使用同一布局投影，保留原 frame、选中状态、滚动和焦点，避免初次渲染与局部刷新各有一套视图判断。
- 把 `src/ui/runtime-editor/world-browser.ts` 的目录、摘要改用共享构造，接上对应标题、表面和滚动。世界默认双栏，专注时主栏铺满。若会话已有非法 `three` 值，归一到 `browse`。世界选择视图的事件入口使用同一合法值集合。右栏缺席时不渲染可操作的右分隔线。世界树和实体摘要继续由现有投影、详情与链接处理。

## 3. 将主题和顶部工具栏折叠归入同一编辑器外观会话

目前 `StoryEditorTheme.setInitial()` 会在 Story 打开时重新采样主题，`controller-theme.ts` 与 `workspace-renderer.ts` 分别特判 Story。世界编辑器未接这条主题链。顶部工具栏已有 `EditorWorkspacePreferences.ribbon`、存储和拖动逻辑，直接沿用。

- 按编辑器工作类型持有一份外观会话，包含已提交主题和现有顶部工具栏折叠偏好。共享构造／激活入口负责取回该会话。Story 和 StoryEntry 属于同一个工作类型，世界属于另一个。实例快照只记录实体与浏览位置。两个编辑器共用框架，可有各自偏好。沿用已有按工作类型保存 ribbon 的键和 compact／expanded 值，旧偏好可读。顶部栏拖动只更新该编辑器的折叠偏好，同一 editor 的实例切换、模式切换和临时视图结束从会话恢复。
- 从原 Story 专用主题类提取通用主题解析和选择逻辑到共享 Editor Workspace 外观层 `src/ui/workspace/editor-workspace-appearance.ts`，保留既有场景、色组和自定义主题功能。首次创建编辑器外观会话时只采样一次进入来源主题。星图入口使用当时的 `SelectorPage.currentTheme()`，正常运行入口使用当时的运行主题投影。该会话存活期间，实体、实例、预览路由、rail、重新进入和运行主题事件均不重新采样或覆盖已提交主题。会话按 UIController 生命周期管理，现有 ribbon 偏好继续持久化，主题按本轮会话保留。
- 明确写入口。把 Story 的 `.story-editor-scene-card` 双击和已有应用色组／自定义主题接到共享显式主题意图，例如 `applyEditorTheme(intent)`。有 `area-hero` 的语义场景才接兼容的双击入口，若世界摘要当前没有该组件，本轮只留意图入口，不为主题增加虚构控件。单击链接、选中实体、恢复实例均只改变浏览状态。显式预览保留临时层，结束时恢复会话中已提交的主题。
- 延续现有主题树与背景服务投影。由统一入口读取「当前活动编辑器的有效主题」，供 `src/ui/controller/controller-theme.ts`、`src/ui/workspace/workspace-renderer.ts` 和 Header 使用。Header 接共享主题接口，移除对 Story 专有类型的依赖。顶部、画布、各栏和状态栏在同一次更新消费同一份主题。主题更新走现有变量与背景宿主的局部刷新路径，保留输入、焦点、滚动和实例。

## 4. 固定可读的浅色兜底主题

- 在共享外观层定义一个完整的「编辑器默认」主题。沿用 `theme-tree.ts` 和项目的浅色 canvas、panel-light、ink、muted 角色，显式填充画布、面板、正文、次要文字及强调色等必需 token。画布采用浅色纯色，背景层为空，顶部栏、rail 和状态栏沿用同一组可读角色。一套定义供经典与高级、Story 与世界共用。部分主题自然缺少可选 token 时，用同一套角色补齐，属于正常解析。
- 共享解析入口负责判定故障并整份切换。解析或投影抛错、必需角色补齐后仍无效，或明确选中的主题来源已失效时，用同一份完整兜底投影替换有效主题。单张可选图片或装饰层无法解析时沿用背景服务跳过该层。首次没有可采样的外部主题属于默认启动，直接使用默认主题。有效主题与 toast 由同一处决定，业务视图和 Header 只消费结果。
- 故障切换时清除上一主题注入的变量及背景图层，仍使用原 Editor Workspace 结构。通过现有 ToastService 显示一次「编辑器主题加载失败，已切换到默认主题」。同一故障期间的多次重绘不重复提示或重试。下次显式应用主题通过后恢复正常，并清除该故障状态。故障注入测试覆盖一次提示、失效背景清除和显式恢复。

## 5. 分阶段验收

1. **先验 Story／StoryEntry 迁移**。在宽屏同一窗口对照改前、改后，分别打开 Story 和 Entry。经典与高级的标题、面板内边距、三栏比例和栏缝保持一致。Story 高级模式的两侧拖宽和双击复位继续可用。切换正文、Entry、试播和目录管理后，既有滚动、焦点、导航和返回仍工作。
2. **再验世界模式矩阵**。从顶部首次进入经典模式，检查面板和标题沿用同一风格。切高级双栏，左分隔线位于真实栏缝，拖动时测实际目录宽度和摘要起点同步变化，双击恢复。下拉仅有双栏、专注。切专注后摘要占满 Frame，确认没有左侧空轨道或可见分隔线。回双栏恢复原宽度与目录滚动。
3. **最后验两个入口与复用**。从 Story 高级 rail 切到世界，选中 Spot，再切回 Story 与世界。分别核对实体选择、实例 ID 及实际栏宽，并检查 Story 草稿保存失败仍留在 Story。记录同一浏览器宽度下 `gridTemplateColumns`、可见栏边界与分隔线坐标。浏览器几何验证通过才把布局列为已验收。
4. **验收外观稳定性**。在 Story 同一界面设置顶部栏紧凑，并用场景卡双击应用可辨识的主题。依次切 Story／Entry、切实例、进出试播／目录管理、经典／高级往返，再通过 rail 进入世界返回。Story 的有效主题和 ribbon 状态恢复为原值。世界连续选择 Init／Area／Spot 时主题稳定。切换运行主题后编辑器保留原主题。明确双击另一场景卡时，同一编辑器各区域一起更新。
5. **验收兜底**。分别在经典和高级打开编辑器，注入一次主题解析失败。检查实际画布为浅色、正文可读、旧背景层移除，toast 只出现一次。重复刷新、切实例仍保持默认外观与原折叠偏好。随后显式选中可用主题，确认退出兜底。不带可选 token 的正常主题补齐后仍可用，且没有故障 toast。
6. 在现有 `tests/ui/story/story-editor-workspace.test.ts` 和 `tests/ui/runtime-editor/runtime-editor-world-browser.test.ts` 加针对性断言，覆盖可用视图、栏轨道配置、可操作分隔线，与世界旧视图归一。补充 `tests/ui/story/story-editor-theme.test.ts` 和世界入口回归，覆盖会话主题、ribbon 隔离、故障去重与恢复。同步编辑器机制页和 UI 风格约定里「重新进入更新打开时主题」的旧口径。运行这些测试及 Workspace Frame／router 的定向回归、类型、架构、文档与差异空白检查。DOM 单测负责结构契约，真实 CSS 几何由上面浏览器步骤核对。

## 当前进展

- 已完成：共享栏位和编辑器外观会话已落地，宽屏 Chromium 验收与定向回归通过。

## 验收记录

- Chromium 1440 × 1000 实测，Story 和 Entry 的高级三栏轨道均为 300／771／320 px，经典模式的栏宽一致。Story 两侧分隔线真实鼠标拖宽 80 px 后均能双击复位。核对试播、目录管理返回、实例切换和保存失败拦截。
- 世界编辑器可从顶部和 rail 进入。高级双栏为 300／1091 px，左分隔线贴合 6 px 栏缝。真实拖宽 88 px 后摘要同步移动，双击复位。专注为 0／1430 px，摘要填满工作区。回双栏目录滚动恢复到 93 px。rail 往返保留 Spot 和实例 ID。
- Story／Entry 的主题和 ribbon 跨实例、视图与重进保留。实际拖动顶部栏保存了 compact。世界拥有独立偏好，浏览实体保持主题。切换运行主题不覆盖已应用的编辑器主题，显式场景双击更新主题。
- 经典和高级的故障兜底画布实测为纯色 rgb(244, 245, 246)，标题前景为 rgb(35, 38, 41)。旧背景与注入变量清除，故障去重，显式选择恢复。已提交主题在后续渲染投影抛错时也直接切换兜底，反复刷新无重试。
- 主 Agent 定向测试 19 文件 250 项全部通过。类型、架构、文档和差异空白检查通过。Chromium 证据见 .test-artifacts 下的 task-0382-geometry-before.json、task-0382-geometry-after.json、task-0382-theme-browser.json、task-0382-live-projection.json 和 task-0382-ribbon.json。

## SubTasks

| ID | 范围 | 负责人 | 状态 |
| --- | --- | --- | --- |
| ST-01 | 实现共享栏位、外观会话和浅色兜底，补回归测试与机制文档 | 6.2 Sol | 已完成 |

## SubOutcomes

- ST-01：交付共享栏位构造、按工作类型持有的外观会话及浅色故障兜底，更新机制文档和相关回归。扩大测试通过 694 项，唯一失败是顶部品牌文字色测试，同样在独立基线 5e594dd3 复现。基线输出保存在 .test-artifacts/task-0382-header-brand-baseline.log。
