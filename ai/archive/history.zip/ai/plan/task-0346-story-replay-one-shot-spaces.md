# Task：Story 重读使用独立一次性播放空间

状态：已完成 — Runtime 与 UI 已按 replayId 隔离一次性重播空间。

## 目标与范围

- 目标：可重读的 StoryEntry 无论对应 owner 是否已有 Active/Passive 故事，都能启动独立重读；重读输出、输入与表现资源不覆盖该 owner 的普通故事。正常结束后回到故事页并显示本次重读内容。
- 范围：StoryService 会话寻址、StoryPlaybackCoordinator 队列与输出、StoryNode 来源/事件、Runtime 读取与推进契约、UI Entry 类型路由与专属临时流、相应机制文档。
- 约束：owner 仍表达原全局/角色语义；重读使用唯一 `replayId` 做播放身份。重读是一次性内存会话，不写普通故事游标/聊天历史/存档。保持当前重读的完成规则：不记录已完成状态、不结算完成奖励；节点内世界效果沿用现有 replay 行为，另作风险核对，不在本任务扩大语义变更。
- 非目标：改写数据包或 StoryEntry 定义、增加可配置重读策略、改变普通故事的 owner 准入和打断规则。
- 验收：同 owner 的普通故事播放期间仍可启动重读；两者可分别继续/选择/加速/取消；重读输出和清理不影响普通输出；重读正常结束后只由其 replayId 返回故事页；会话重置可清理所有重读，保存不持久化一次性重读。

## 当前进度

- [x] 调查并确认现行重读被 `sessions[ownerKey(owner)]` 与 Coordinator owner 单槽阻止；Passive `schale_tea` 已现场复现。
- [x] 建立唯一 replayId 的 Runtime 临时会话/播放队列和显式查询、推进、取消 API。
- [x] 接入主界面/通讯录及故事页的隔离流；结束路由仅认对应 replayId。
- [x] 更新重读机制说明与事件目录。
- [x] 做类型、架构和文档静态检查；自动化测试未执行。
- 已修正延迟交接路径：重播启动后按 replayId 查询结果，避免误读同 owner 的普通故事。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/arona-clicker/services/story/story-service.ts` | Session 准入、Owner 查询、重读及结束 | 已修改 |
| `src/arona-clicker/services/story/story-playback-coordinator.ts` | Owner-keyed barrier / outputs / intents | 已修改为 channel key |
| `src/arona-clicker/contracts/runtime/story-node-playback.ts` | StoryNodeSource 运行身份 | 已添加 replayId |
| `src/engine/types/events.ts`、`src/arona-clicker/contracts/runtime/event-catalog.ts` | Playback / start / end 事件携带 replayId | 已同步 |
| `src/arona-clicker/contracts/story/story-query.ts`、`src/arona-clicker/contracts/runtime/runtime.ts` | 重读专用读取/命令契约 | 已添加 |
| `src/ui/controller/controller-actions-story.ts`、`controller-events.ts` | Entry 路由、重读意图与结束回跳 | 已修改 |
| `src/ui/presentation/chat-stream.ts`、`src/ui/components/shared/app-shell.ts` | 临时重读流、聊天文本及 UI 状态 | 已修改 |
| `src/ui/components/story/story-workspace.ts`、`src/ui/workspace/workspace-renderer.ts` | 回放内容渲染与流绑定 | 已修改 |
| `tests/engine/story-replay.test.ts`、`tests/engine/story-service-node.integration.test.ts` | Runtime 并发和重读边界 | 未改动；本次未执行测试 |
| `tests/ui/story-gate.test.ts`、`tests/ui/story-history-resume.test.ts` | Entry 路由、owner 流隔离和结束回跳 | 未改动；本次未执行测试 |
| `docs/docs-830/05-domains/story-and-effects.md`、`docs/docs-830/04-presentation/story-chat-and-theme-presentation.md` | 更新稳定 Runtime/UI 机制事实 | 已更新 |

## 事实与决定

| 问题 / 决定 | 已核实事实及源码、测试或文档依据 | 待解决问题 |
| --- | --- | --- |
| 重读为何被挡 | `replayStory()` 在 `story-service.ts` 检查 `sessionFor(owner)`；Runtime 仅有按 owner 的会话 Map；现场全局 `schale_tea` 在 input 阶段导致 `AlreadyActive`。 | 无 |
| 输出如何隔离 | Coordinator barriers、outputs、tokens、revision 均以 owner 为键；仅在 UI 增加临时数组不能让两个 session 并行。 | 所有异步 timer / effect / release 回调需改用 playbackId 定位。 |
| 身份拆分 | `source.owner` 保持全局/角色语义；新增唯一 replayId 作 session 与播放空间身份；普通 Story 的公开 owner API 保持不变。 | 排查演出主题激活是否需按 replayId 选择前台层。 |
| 生命周期 | 重读不进入 cursor 保存与普通聊天持久化；结束/取消时清理对应队列和临时 Presentation。 | 读档/重置时确认临时 session 必须取消。 |
| 世界效果 | 当前 replay 已跳过完成记账/奖励，但仍执行 Story 节点动作。 | 保持既有行为，并明确存在的重复世界效果风险；是否增设只读效果策略留待单独需求。 |

## 验证与结果

| 检查对象与方式 / 命令 | 实际结果 | 失败后的排查与处理 / 未执行原因 |
| --- | --- | --- |
| 现场控制台检查 `base:activestory:schale_flow_show` | Entry 存在、replayable；但全局 owner 正有 `base:passivestory:schale_tea`，page 2/3、input。 | 已确认是 Runtime 同 owner 排斥，不是 Entry 配置缺失。 |
| `npx tsc --noEmit` | 失败：仅报告 `tests/ui/workspace-lifecycle.test.ts:346` 给只读 `areaStoryDeliveries` 赋值 | 未改动既有测试；编译诊断未报告 `src/` 错误。 |
| `npm run check:architecture` | 通过 | Engine / Data Services 架构边界通过。 |
| `npm run check:docs` | 失败：6 条既有归档计划链接缺失，均不在本 Task 新文档引用内 | 未扩展修复无关旧链接。 |
| `git diff --check` | 首次发现 `ai/plan/00-index.md` 文件尾多余空行 | 已移除；需在归档前复核。 |

- 当前结果：重播会话与表现协调器按 replayId 隔离，UI 为重播提供一次性流和专用输入命令；正常结束回故事工作区，重播输出不落入普通历史与游标快照。

## 剩余工作与交接

- 代码、机制说明和静态核查已完成。GALHCG 项目身份与 StoryService / Area Hero 相关概念已只读核查；未写图、刷新或记录 freshness。
- 已知限制：Story 节点动作仍执行既有 replay 行为，因此重复播放可能再次触发节点内世界效果；非 Story 归档链接缺失导致全局 docs 检查失败。
