# Draft 0365：StoryEntry 的公共信息、历史归档与三类激活方式

状态：已实施的设计记录 — 2026-11-06 起草，2026-11-07 由 Task 0365 落地；当前合同和运行事实以源码及 Wiki 为准。

## 1. 要解决的混合职责

Entry 描述一份故事内容如何进入游戏。以下关系必须独立表达：

1. **播放哪份正文**：`storyId` 引用 StoryDef，不是归档分组，也不是角色。
2. **归入哪组历史故事**：分类／篇章／章节决定故事页、历史与重读入口的编排，不决定首次触发方式，不写完成记录。
3. **如何正式激活**：主动接取、随机抽取、好感／角色阶段，是三个互斥的作者分支。
4. **归属哪个角色通道**：`owner` 表示角色归属，与目录归属和正文起始场景不同。

因此，“所属故事”在编辑器中应使用明确标签：**正文 Story、历史归档、归属角色**。不再用一个“所属”覆盖这些关系。

## 2. 已核实依据与归档边界

| 依据 | 当前事实 | 对设计的约束 |
| --- | --- | --- |
| `contracts/story-entry.ts`、`story-entry-selection.ts` | 只有 active / passive 两类；passive 通过是否存在 `affectionRequired` / `pushAfterStory` 再隐式分流 | 好感／角色阶段必须成为显式分支，不能靠“顺便填了哪个可选字段”判别 |
| `content/story/story-hierarchy.ts` | 归档目录同时引用主动与被动 Entry；`baseStoryPageOnlyEntryIds` 另列首次地区兜底名单 | 归档不是主动入口专属；地区兜底应进入主动激活配置，退出硬编码白名单 |
| `ui/columns/authored-story-catalog.ts` | 作者归档信息藏在 `extra.storyCatalog`，与产品侧目录共同投影 | 归档配置提为显式组件，Extra 不继续承担已有核心机制 |
| `story-availability-delivery-mount.ts` | 目前名单入口满足资格后投放到首次符合条件的当前 Area | 转写现有内容时显式使用 current-area，不能全部改成固定地区或自动开播 |
| `passive-pool-system.ts` | 池独立保存成员和路径权重，Entry 自身权重参与最终抽取 | 不在 Entry 再维护一份 poolIds；成员关系保持单一来源 |
| 压缩归档中的 Task 0346 | 重读使用独立 replayId；owner 保持原全局／角色含义，重读不写普通历史／完成记录 | 历史编排、角色通道、正式激活与重读会话不能混成一个分类轴 |
| 压缩归档中的 Task 0356 | 新作者流程使用 entryCard.continuation；旧 Entry.kizuna 仅作兼容 | 不恢复旧羁绊关联作为第四类激活方式 |

归档通过 [[ai/archive/README]] 的 `list/read` 读取，未展开 Markdown。Task 0346 中的旧“重读仍执行世界效果”记录不作为现状；以当前 [[story-and-effects]] 为准。更早已删除的原始归档无法用于补证，不推断其中存在尚未找到的分类设计。

## 3. 推荐结构：组合式公共记录＋带判别字段的激活配置

不引入运行时继承类。公共记录由普通对象保存，专属配置通过 `activation.kind` 判别；类型用交叉类型组合。

| 组件／字段集合 | 内容 | 不放在这里的内容 |
| --- | --- | --- |
| 公共记录 | `id`、`storyId`、`openingTitle`、`owner`、Init 范围、公共资格条件、揭示配置、重读／起始场景策略、完成奖励及反应／后续、tags／extra | 抽取权重、好感门槛、主动地区兜底 |
| `catalog` 历史归档组件，可省略 | 分类、篇章、可选章节、可选条目排序 | 完成／已读状态、当前游标、首次地区投放、角色 owner |
| `activation`，必填且三选一 | active / random / affection 的专属字段 | 通用奖励或归档信息 |
| 被动播放行为字段集合，仅 random / affection 组合 | 既有 `interruptible`、`leaveArea`、`blocksInteraction`、`block` | 不适用于 active 的伪开关；不在本阶段重定义这些字段的行为 |

第一阶段只移动分类所需字段，不把全部公共字段再套入多层 availability / playback / completion 对象。`completionReward` 在公共记录只定义一次。`id` 使用 StoryEntryId，保持原身份；不因激活分类变化重命名现有 ID 或修改 ModId。

以下为目标形状草图，省略的公共字段仍应完整保留，不是裁剪合同的授权：

```ts
type StoryEntryCatalog = {
  category: string;
  part: string;
  chapter?: string;
  order?: number;
};

type ActiveActivation = {
  kind: 'active';
  fallback?:
    | { kind: 'current-area' }
    | { kind: 'fixed-area'; areaId: AreaId };
};

type RandomActivation = {
  kind: 'random';
  weight: number;
  repeatable: boolean;
  cooldownFrames?: number;
};

type AffectionActivation = {
  kind: 'affection';
  when:
    | { kind: 'level'; level: number }
    | { kind: 'after-story'; storyId: StoryId };
  cooldownFrames?: number;
};

type StoryEntryDef =
  | (StoryEntryCommon & { activation: ActiveActivation })
  | (StoryEntryCommon & PassiveBehavior & { activation: RandomActivation })
  | (StoryEntryCommon & PassiveBehavior & {
      owner: string;
      activation: AffectionActivation;
    });
```

`StoryEntryCommon` 中 owner 可省略；affection 分支通过组合将同一个 owner 字段收紧为必填，不另存一份触发角色。沿用当前字符串形式的角色差分 ID，由 Registry 校验实际引用，不为草案新增 ID 别名。

## 4. 三类激活的明确含义

### 主动接取 active

- 由明确请求、Init、入口卡、后续投放等渠道进入；类型本身不使故事自动开播。
- fallback 省略表示不做资格兜底投放；不代表缺少正文起始场景。
- current-area 保持现有“在首个符合条件的当前 Area 创建可接取入口”的行为；fixed-area 指定兜底接取地点。
- 固定地区必须存在；投放复用当前 Init 与地区准入校验，不跨 Init 投放、不自动旅行。资格尚未满足或暂时不允许投放时不能标记已投放。
- 地区兜底与 `StoryDef.startContext`／`travelToStartContext` 独立；一个是哪里接取，一个是播放时是否前往起始场景。
- 外部已有投放、完成状态与当前会话的防重复规则继续生效。

### 随机抽取 random

- 仅此分支参与随机池与独立候选抽取；保存基础权重、可重复正式触发、冷却。
- 不允许出现好感门槛、前置 Story 或主动 fallback。
- PassivePoolDef 保持独立实体；`children` 引用池或 random Entry，拒绝主动、好感入口被混入抽取池。
- Entry 不复制池成员关系；编辑器从池反查展示“所在池”。Entry 基础权重与池路径权重仍相乘，不把权重显示成固定概率。

### 好感／角色阶段 affection

- 角色 owner 必填，不参与随机抽取；不携带 weight、repeatable 或 fallback。
- level 表示角色达到等级后可触发的阶段；after-story 表示前置 Story 完成后的角色尾段，保留当前尾段优先的选择顺序。
- 两种 when 明确互斥，不允许旧式同时填写门槛与前置故事后依赖隐式优先级。
- 本阶段保持单次正式完成语义；replayable 仍是公共的独立重读能力。
- 将来确需“前置完成且好感达标”的组合时，可使用公共资格条件表达；不提前增加另一套条件 DSL。

## 5. 归档与存储边界

- catalog 是可选编排信息；没有归档配置仍可由合法渠道触发，有归档配置也不因此获得首次播放资格。
- 复用现有分类／篇章／章节模型，不新增一套 StoryCollection 实体或索引树。目录分组定义可保留产品名称与顺序，Entry 条目位置由 catalog 提供；不再维护两份同一条目的归属。
- 手写目录中的条目位置和 `extra.storyCatalog` 转写到 catalog；保留现有顺序、展示名、重读能力及省略字段语义。当前完成记录与已读记录仍由运行状态维护。
- 第一阶段保留 Datapack 的 `activeStories` / `passiveStories` 两个存储分区：前者只接受 active，后者只接受 random / affection。Registry 的 storyEntries 继续为聚合查询；不新增第三份权威列表。
- 原顶层 `type: active/passive` 不与 activation 双写；旧启动 API 的 active/passive 若暂时保留，仅为内部通道路由，由 activation 明确推导，不成为作者的第二个分类字段。
- 既有 `activestory` / `passivestory` ID 命名空间保持不变，不能据 ID 前缀猜好感／随机激活方式。

## 6. 本轮 Task 的边界

基础分类施工必须覆盖合同、校验／引用、运行分流、地区兜底、池、内置内容／测试夹具、Schema 与编辑器最低可用读写；不能只增加未被消费的类型。

第一阶段不同时重做奖励策略、反应 lifetime、Entry 安全改名、游标／存档结构或完整属性页视觉设计。丰富的分类表单后续复用本草案的数据边界；基础施工至少能正确选择三类并只编辑合法分支，保留 Flag／关系导航与未提交内容。

本草案起草时仅交付设计与实施 Task；后续 0365 已完成，保留本文作为分类取舍的设计记录，验收结果见 Task 归档。
