# Task 0365：StoryEntry 公共信息、历史归档与三类激活合同

状态：完成 — 2026-11-07 基础分类、运行接线、内容与 Schema 转写、编辑器读写及定向回归均完成。

## 目标与范围

- 需求：将 Entry 的正文引用、历史归档、角色归属与激活方式分开；激活方式明确为主动接取、随机抽取、好感／角色阶段三类。
- 设计依据：[[ai/plan/draft-0365-story-entry-composition]]。使用公共记录＋catalog＋activation 判别联合，通过组合收紧分支，不引入运行时继承层。
- 交付：源合同、结构／引用校验、运行消费、内置内容、Schema、编辑器基础分类读写和对应回归形成闭环；不以类型存在或仅 UI 隐藏字段代替完成。
- 非目标：重做完整属性页视觉、奖励和反应生命周期、Entry 改名、存档迁移、地区揭示／探索规则。保留既有 ID、ModId 和运行状态归属。
- 存储决定：保留 activeStories / passiveStories 两分区及 Registry 聚合查询；移除顶层作者 type 双写，用 activation 分流，必要的旧 API 路由显式派生。

## 当前进度

- [x] 核实当前合同、三条运行路径、目录投影、地区兜底白名单和池成员来源。
- [x] 读取现存压缩归档 0346 / 0356；记录原归档缺失与历史事实不等于现状的边界。
- [x] 记录公共／专属字段、组合形状、数据转写和验收范围的 draft。
- [x] S1：基础合同与非法组合回归。
- [x] S2：运行消费、引用和地区兜底接线。
- [x] S3：内置内容与所有直接调用方转写、Schema 同步。
- [x] S4：编辑器三类基础读写、归档与关联展示。
- [x] S5：定向／整合验收、说明更新与地图只读收尾。
- 当前停点：本 Task 范围内工作与只读收尾完成，进入压缩归档。
- 下一步：无；完整属性页的进一步分类美化不属于本 Task。

## 分段实施与验收

### S1：公共记录与三类配置

- 将 completionReward 等真正公共信息只定义一次；正文 storyId、归档 catalog、角色 owner 独立。
- activation.kind 为 active / random / affection；无顶层 type 双写，无启发式字段探测。
- active 支持可选 current-area / fixed-area fallback；random 保存 weight / repeatable / cooldownFrames；affection 要求 owner，when 为 level / after-story，保留冷却。
- 被动播放控制仅在 random / affection 上合法；公共奖励、重读、门槛／揭示等能力不因重组丢失。
- 编译期和导入／发布边界均拒绝错误组合：主动权重、随机好感门槛、好感缺 owner、双 when、负权重／冷却、固定地区缺引用、错误存储分区。
- 类型文件采用 StoryEntryId；owner 沿用当前字符串形式的角色差分身份，由 Registry 校验引用，不另外制造同义 ID。

### S2：运行与引用必须消费新分类

- 随机系统只筛 random；好感与尾段只筛 affection，继续保持门槛、前置完成、尾段优先、单次完成与冷却语义。
- PassivePoolDef.children 只允许池或 random Entry；反向展示从 children 派生，不另存 Entry.poolIds。
- 地区资格投放改读 active.fallback，删除 `baseStoryPageOnlyEntryIds` 作为行为来源；已有名单逐项显式转写为 current-area。
- fixed-area 只在合法 Init／地区可投放时创建可接取入口；复用现有重复投放、完成、接取与忙状态准入，不自动开播／旅行。
- 引用规则覆盖 activation.when.storyId、fixed-area.areaId 与原 Entry 引用；Story ID 改名、删除检查、关系／Flag 遍历不得遗漏新路径。
- StoryService、入口请求／卡片／continuation、FollowUp、奖励／重读、ReadModel 及 UI 路由逐项更新；active/passive 通道路由若保留必须从 activation 推导。

### S3：内容、Schema 与旧数据边界

- 先盘点旧 active / 普通 passive / 好感 passive / 尾段 passive，以及同时存在 affectionRequired 和 pushAfterStory 的异常项。异常逐项决定并记录，不静默猜测作者意图。
- 内置定义与测试夹具一次性转写；ID、引用、归档顺序、奖励、重读资格和运行行为保持。
- 将手写目录条目的归属及 extra.storyCatalog 提升为显式 catalog，保留产品分组名称／顺序；目录查询不再依赖旧 Extra 或双份条目归属。
- 核实 Schema 生成器能表达组合和 activation 判别联合；依 [[ai/guide/conventions/schema-sync]] 更新生成协议、补充元数据及同步测试，禁止手改生成 JSON。
- 不新增永久新旧双读合同，不自动清空／改写用户外部包或本地草稿；旧格式明确报具体路径并保留原数据。作者静态内容的转写与玩家存档迁移不同，后者不在本 Task 范围。

### S4：编辑器最低可用分类

- 新建 Entry 明确选择主动／随机／好感，生成合法的默认配置；不再用添加好感字段将随机入口暗中变类。
- 正文 Story、归档位置、角色归属分别命名和编辑；归档使用普通字段，不暴露 Extra 类型树。
- 当前分支只提供合法专属字段；切换前展示将移出的配置并要求显式处理，取消／保存失败保留原分支，不静默删字段。
- 池只作为关联实体与反查入口，配置仍写池的唯一 children；不在每个 Entry 下混放整个 Story 的池表单。
- 保留稳定行路径、错误输入、焦点、当前页与滚动；沿用既有 workspace 更新、Navi、关系和 Flag 卡片。
- 公共奖励／条件／高级字段第一阶段可继续使用现有结构编辑器；完整分类页美化后续另行验收，不阻断基础合同闭环。

### S5：验收矩阵与收尾

| 范围 | 必须验证的可观察行为 |
| --- | --- |
| 合同／导入 | 三类合法样例接受；跨类字段、缺少 owner／地区和错误分区拒绝；失败不部分写包 |
| 主动投放 | 无 fallback 不兜底；current-area 保持首个合格当前地区；fixed-area 正确定位；无跨 Init、重复投放、自动开播或旅行 |
| 随机／池 | 仅 random 参与；池路径权重／owner／冷却生效；主动与好感不能混入池 |
| 好感／尾段 | owner 匹配、等级排序、前置完成、尾段优先和单次完成成立；重读不消耗正式投放 |
| 归档 | 三类均可独立归档；位置变化不改变激活方式、历史状态或 owner；原目录顺序与重读能力保留 |
| 引用／编辑器 | 新路径可检查、导航、改 Story ID；三类新建／切换／保存重载正确；取消、错误输入与无关节点身份保留 |
| 整合 | 内置包可装载，生成 Schema 同步通过，类型／架构／文档检查；相关 Story、Entry、池、投放、重读与 UI 回归无新增失败 |

测试统一通过 npm test 执行；独立 JSON／日志写 `.test-artifacts/0365-*`，不依赖会被其他执行覆盖的 latest.log。先定向，整合后按实际影响扩大；不逐段重复全量。浏览器验收与未覆盖项单独记录，不把样例截图当完整运行验收。

## 相关文件与资料

| 路径或链接 | 用途 | 当前状态 |
| --- | --- | --- |
| `src/data-services/contracts/story-entry.ts`、`datapack.ts`、`passive-pool.ts` | 作者合同与存储分区 | 已按本 Task 修改／复用并定向验证 |
| `src/data-services/authoring/story-authoring.ts`、`story-identity.ts` | 发布校验、引用与 Story 改名 | 已核对，未修改 |
| `src/data-services/registry/registry.ts`、`runtime-content-reference-rules.ts` | 聚合／装载与声明引用 | 已核对并修改声明引用与 Registry 校验 |
| `src/arona-clicker/services/story/story-entry-selection.ts`、`story-service.ts` | 三类选择、启动、播放、重读与返回 | 已核对，未修改 |
| `src/arona-clicker/services/story/story-availability-delivery-mount.ts` | 地区兜底 | 已改读 activation.fallback，旧白名单已删除 |
| `src/arona-clicker/services/economy/passive-pool-system.ts` | 池遍历与权重／冷却 | 已核对，未修改 |
| `src/arona-clicker/content/story/story-hierarchy.ts`、`src/ui/columns/authored-story-catalog.ts` | 产品目录、名单与作者目录投影 | 已核对，未修改 |
| `src/ui/story-editor/authoring-model.ts`、`authoring-view.ts`、`structured-value.ts`、`controller.ts`、`relations-model.ts`、`flag-catalog.ts` | 草稿、新建、表单、引用与 Flag | 已修改基础表单／草稿／Controller；既有调用和 Flag 域算法保持 |
| `scripts/gen-engine-schema.mjs`、`tools/datapack-editor/schema/editor-extras.ts` | Schema 生成／补充元数据 | 已生成并同步，完整同步测试通过 |
| `src/data/base/` 与 `tests/` 中 Entry 定义／调用方 | 正式内容与夹具转写 | 已按源码／夹具扫描转写；一次性扫描报告见 .test-artifacts/0365-migration-report.json |
| `tests/engine/story-entry-split.test.ts`、`story-rewards.test.ts`、`passive-pool.test.ts`、`tests/ui/story-editor-authoring.test.ts` | 可复用回归入口 | 已执行；新增合同、地区兜底、池约束与编辑器切换／保存失败回归 |
| [[story-and-effects]]、[[runtime-editor-and-project-checks]] | 当前机制与保存边界 | 施工完成后按实际结果更新 |
| [[ai/plan/task-0361-reveal-area-map-implementation]]、0363（节点演出已实现并归档，机制见 [[story-and-effects]]）、[[ai/plan/task-0364-story-operation-display-content-migration]] | 并行地区／节点演出工作 | 仅协调交叉入口，不扩展本任务为相关功能施工 |

文件表用于定位和交接，不是修改白名单；未读全的调用方不能据此判定无需修改。

## 落地结果与取舍

- 公共记录以 TypeScript 接口复用字段，activation 是三类配置的判别组件；没有运行时继承类。catalog 显式维护归档，Entry 身份／ModId 和完成记录格式保持。
- random 只进入抽取，affection 只进入角色阶段／尾段；9 条旧地区兜底入口显式转写 current-area，16 个归档条目移入各自定义的 catalog。固定地区投放、无兜底、跨 Init、重复投放／重试及真实 Runtime 不开播／不旅行均有回归。
- 池成员在导入／发布时只能引用 random 或池；合并前将当前 Registry 与候选记录一起核对，阻止另一包改类后破坏已有池。运行层同样排除非 random。
- 编辑器提供三类新建与专属字段；切换先展示含义并确认，克隆候选先保存至本机，成功才提交。取消、存储异常、未修正输入、池仍关联及过期确认保留原配置。池表单按直接关系收起展示，编辑中的解除关联暂留至离开 Entry，稳定行键保留焦点和展开状态。
- 新引用路径用于 Story ID 改名和内容检查；前置故事另外显示为激活依赖，不引入调用链或局部 Flag 作用域。归档与角色归属／正文位置互不推导。
- 内置与夹具一次性转写；共享 makePack 修正为按 activation 分区，不再把被动夹具硬塞 activeStories。完成记录的 type 保持原格式，不作为 Entry 格式迁移。旧外部包／本地草稿不自动改写或清空，错误路径由既有校验／禁写处理保留。
- 共享 Schema 收尾发现 AreaMap／Area 的旧 revealTriggers 覆盖已不在当前合同中，移除这两处过期覆盖后完整同步测试通过；未改变地区运行规则。

## 验证与结果

| 检查 | 实际结果 | 证据／限制 |
| --- | --- | --- |
| 定向与整合回归 | 79 文件、842 个去重用例全部通过 | 分阶段 JSON 按文件与用例合并，以后续复验覆盖旧失败；.test-artifacts/0365-validation-summary.json |
| Schema | 生成、三类专用断言及完整同步检查通过 | .test-artifacts/0365-schema-current.log、0365-schema-whole.json |
| 构建 | 通过，7.80 秒 | npm run build -- --outDir .test-artifacts/0365-build-final；0365-build-final.log |
| 架构 | 通过 | .test-artifacts/0365-architecture.log |
| 全局类型 | 仅余无限画布原型测试 8 项既有错误，无本 Task 分类错误 | .test-artifacts/0365-types-closure.log；不修改原型代码 |
| 文档／差异空白 | 通过 | 0365-docs-final.log、0365-diff-check-final.log；按项目要求统一 LF |
| GALHCG | 95 个直接路径，只读完成 | 40 已关联、55 无直接关联；6 个路径按 owner_offset 续页至完整。0365-health.json；未改图、刷新或写 freshness |
| 浏览器与全库测试 | 未执行 | 以本 Task 的 DOM／Runtime／定向整合回归验收；未宣称全库通过 |

## 剩余工作与交接

- 本 Task 范围内无剩余施工。完整属性页视觉重组、Entry 安全改名、反应 lifetime 及玩家存档迁移保持为非目标。
- 并行节点演出／地区工作保留原有修改，没有回滚；全局类型的原型既有错误另行处理。
- 本 Task 与 draft 经 archive:docs 校验归档，活动索引同步移除；后续机制以现行 Wiki 和源码为准。
