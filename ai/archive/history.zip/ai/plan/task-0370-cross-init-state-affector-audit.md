# Task：调查跨 Init 封存、全局进度与 Affector 生效范围

状态：已完成

## 目标与验收

对照 Init 封存、全局历史／钱包和星图授权设计，确认现行状态归属、Affector 宿主与目标、奖励落点及派生工作量。交付有证据的差异表和可执行的后续任务。

## 工作项

- [x] 核对 Init 快照、钱包、历史、角色和据点、派生记录及 MapRun／Operation 的归属。
- [x] 复现双 Init 中的同标签和显式目标、Area 移动、切线、读档及同 ID 热替换，记录监听和实际写入。
- [x] 复验青辉石读写、阿比多斯奖励错线、离线结算和 inactive Init 的 GameNum 节点开销。
- [x] 提交调查报告，创建 0371 的实施顺序及回归场景。

## 当前进展

- 调查结论与证据见 [[ai/plan/report-cross-init-state-affector-audit]]。
- 后续施工见 [[ai/plan/task-0371-cross-init-state-affector-implementation]]。
